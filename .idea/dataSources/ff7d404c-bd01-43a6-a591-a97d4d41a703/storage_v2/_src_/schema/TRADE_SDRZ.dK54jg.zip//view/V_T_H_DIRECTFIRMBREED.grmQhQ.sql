CREATE VIEW V_T_H_DIRECTFIRMBREED AS
  select d.breedId breedId, --品种代码
 d.firmId firmId, --交易商代码
 a.breedname, --品种名称
 to_date( to_char(d.deletedate,'YYYY-MM-DD'),'YYYY-MM-DD') deletedate  -- 删除日期
   from t_h_directfirmbreed d, t_a_breed a
  where d.breedId = a.breedId
/

