CREATE function FN_BI_UnusedStocksNew
(
    p_commodityid varchar2,
    p_firmid varchar2,
    p_quantity number,
    p_matchId  varchar2,
    p_goodsId  number,
    p_placeId  number,
    p_StockIds varchar2    --特许服务商手动选择的仓单
)
return integer is
  /**
  * add by lyf 20160919
  * 检查卖方交易商可用持仓
  * 返回值： -1没有符合的持仓信息
  **/
  TYPE v_billids IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE v_sck IS TABLE OF VARCHAR2(200) INDEX BY BINARY_INTEGER;
  TYPE v_qty IS TABLE OF VARCHAR2(200) INDEX BY BINARY_INTEGER;
  v_cnt                  bi_stock.stockid%type; --数字变量
  v_breedid              t_commodity.breedid%type;
  v_billid               v_billids;
  v_quantity             bi_stock.quantity%type:=0;
  --v_stockids             TYPE_BILL_STOCKID;
  v_stockids             v_sck;
  v_quantitys            v_qty;
  i                      number:=1;
  --v_propertyname         bi_goodsproperty.propertyname%type;
  RET_RESULT integer:=-10;--可配仓单不存在


begin
    select breedid into v_breedid from t_commodity where commodityid=p_commodityid;

    for st in (select * from bi_stock s where s.stockid in (select regexp_substr(p_StockIds,'[^,]+',1,level) from dual
                 connect by regexp_substr(p_StockIds,'[^,]+',1,level) is not null) )  loop
         insert into t_billfrozen (id, operation, billid, operationtype, modifytime) values (SEQ_T_BILLFROZEN.NEXTVAL, p_matchId, st.Stockid, 2, sysdate);
         v_cnt:=fn_bi_frozenBill(p_commodityid,p_firmid,p_quantity,p_matchId,st.Stockid) ;
         if(v_cnt<=0)then
             return v_cnt;
         end if;
     end loop;

    return 1;
exception
    when NO_DATA_FOUND then
    --rollback;
    return -100;  --不存在相关数据
end;
/

