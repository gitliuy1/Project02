CREATE VIEW V_T_SETTTLEINTENTIONS AS
  select a.a_orderno,
       a.firmid,
       a.commodityid,
       a.tradedate,
       a.bs_flag,
       a.stockids,
       a.goodsid,
       a.placeid
  from T_setttleIntentions a
union all
select b.a_orderno,
       b.firmid,
       b.commodityid,
       b.tradedate,
       b.bs_flag,
       b.stockids,
       b.goodsid,
       b.placeid
  from T_h_setttleIntentions b
/

