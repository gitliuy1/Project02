CREATE VIEW V_FIRMTRADEFEES AS
  select m.brokerId   brokerId,
               t.firmId     firmId,
               t.clearDate  clearDate,
               t.a_TradeNo  tradeNo,
               tb.breedid   breedId,
               tb.breedname breedName,
               t.bs_Flag    bsFlag,
               t.quantity   quantity,
               t.tradeFee   tradeFee
          from T_H_Trade        t,
               Br_FirmAndBroker m,
               t_h_commodity    tc,
               t_a_breed        tb
         where t.firmId = m.firmId
           and t.commodityid = tc.commodityid
           and tc.breedid = tb.breedid
           and t.clearDate = tc.clearDate
/

