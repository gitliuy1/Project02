CREATE function FN_T_D_SettleMatch_close return number
/****
 * 到期持仓 交收申报配对 ,特许服务商和交易商，先自交收，最后撮合交收
 * 优化自交收逻辑 :在自我买卖撮合完成后，持仓进入交收数据时 直接记为完全配对数据，并同时记录配对信息
 * 不再将撮合和配对分开，分开处理，配对时从所有交收数据中再取查找对应交收数据花费时间交长（开发环境平均每条超过0.1秒） yuansr 2017 09 12
 * 返回值
 * 1 成功
 * -1  买方成交数量出错
 * -3  交收持仓数量大于可交收持仓数量
 * -4  交收抵顶数量大于可抵顶数量
 * -99  不存在相关数据
 * -100 其它错误
 *修改： 交易保证金 按持仓到期天数(到期交收 到期天数计 1 ) 所处阶段 设置参数 计算       yuansr 2016 10 30
****/
as
    v_version            varchar2(10):='1.0.0.1';
    v_ret                number(4);
    v_FL_ret             timestamp;
    v_errorcode          number;
    v_errormsg           varchar2(200);
    v_price              t_quotation.curprice%type;
    v_margin             number(15,2);  --交易保证金
    v_HoldSum            number(15);
begin

    --1.自动生成到期交收委托数据
    --买交收申报委托
    --dbms_output.put_line('1 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss'));
    for cur_holdposition_b2 in 
        (select firmid,customerid,commodityid ,sum(t.GageQty+t.HoldQty-nvl(t1.FrozenQty,0)-nvl(t2.FrozenQty,0)) qty 
           from t_holdposition t
                ,( select A_HoldNo, sum(FrozenQty) FrozenQty from T_SpecFrozenHold group by A_HoldNo ) t1
                ,( select A_HoldNo, sum(frozenqty - unfrozenqty) FrozenQty from T_S_OrderFrozenHold where bs_flag = 1
                    group by A_HoldNo ) t2
          where t.A_HoldNo = t1.A_HoldNo(+)  and t.A_HoldNo = t2.A_HoldNo(+) and t.overdat<=1 and bs_flag=1
          group by firmid,commodityid,customerid order by t.firmid
         ) 
    loop
       select Price into v_price from t_quotation where commodityid = cur_holdposition_b2.commodityid ;
       --add by lyf 20160811 增加持仓合计可用数量的查询
        select nvl(holdQty - frozenQty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_b2.customerid and CommodityID = cur_holdposition_b2.commodityID and bs_flag = 1;
       if v_HoldSum>0 then
         if v_HoldSum>=cur_holdposition_b2.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
            if cur_holdposition_b2.qty > 0 then
               v_margin := FN_T_ComputeMarginPlus(cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,1,1,cur_holdposition_b2.qty,v_price);
               v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b2.firmid,cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,cur_holdposition_b2.qty,v_price,cur_holdposition_b2.customerid,'',v_margin,1,v_price);
            end if;
         else
            v_margin := FN_T_ComputeMarginPlus(cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,1,1,v_HoldSum,v_price);
            v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b2.firmid,cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,v_HoldSum,v_price,cur_holdposition_b2.customerid,'',v_margin,1,v_price);
         end if;
       end if;
    end loop;

    --卖交收申报委托
    for cur_holdposition_s2 in 
        ( select firmid,customerid,commodityid,sum(t.GageQty+t.HoldQty-nvl(t1.FrozenQty,0)-nvl(t2.FrozenQty,0)) qty 
            from t_holdposition t 
                 ,( select A_HoldNo, sum(FrozenQty) FrozenQty from T_SpecFrozenHold group by A_HoldNo ) t1
                 ,( select A_HoldNo, sum(frozenqty - unfrozenqty) FrozenQty from T_S_OrderFrozenHold where bs_flag = 2
                     group by A_HoldNo ) t2
          where t.A_HoldNo = t1.A_HoldNo(+)  and t.A_HoldNo = t2.A_HoldNo(+)  and t.overdat<=1 and bs_flag=2 
            group by firmid,commodityid,customerid order by t.firmid
        ) 
    loop
       select Price into v_price from t_quotation where commodityid = cur_holdposition_s2.commodityid ;
       --add by lyf 20160811 增加持仓合计可用数量的查询
       select nvl(holdQty - frozenQty+gageqty-gagefrozenqty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_s2.customerid and CommodityID = cur_holdposition_s2.commodityID and bs_flag = 2;
       if v_HoldSum>0 then
           if v_HoldSum>=cur_holdposition_s2.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
              if cur_holdposition_s2.qty>0 then
                 v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s2.firmid,cur_holdposition_s2.firmid,cur_holdposition_s2.commodityid,cur_holdposition_s2.qty,v_price,cur_holdposition_s2.customerid,'',1,0,v_price);
              end if;
           else
              v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s2.firmid,cur_holdposition_s2.firmid,cur_holdposition_s2.commodityid,v_HoldSum,v_price,cur_holdposition_s2.customerid,'',1,0,v_price);
           end if;
       end if;
    end loop;
  
    --dbms_output.put_line('2 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss') );
    --2.自我撮合交收数据，并配对  (先把所有到期的委托打入交收数据，再根据交收数据明细撮合特许服务商)
    for cur_Commodity in(select CommodityID from T_Commodity where SettleWay=1 )
    loop
      --dbms_output.put_line('3 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss') ||',c='||cur_Commodity.Commodityid);
      ---优先自我配对处理 yuansr 2017 09 02
      v_ret := FN_T_D_SettleMatchOne_self(cur_Commodity.CommodityID);
      if(v_ret < 0) then
        --rollback;
        return v_ret;
      end if;
    end loop;

    --dbms_output.put_line('4 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss') );
    --3 .撮合剩余交收数据 
    for cur_Commodity in(select CommodityID from T_Commodity where SettleWay=1 )
    loop
      dbms_output.put_line('5 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss') );
      v_ret := FN_T_D_SettleMatchOne_close(cur_Commodity.CommodityID);
      if(v_ret < 0) then
        --rollback;
        return v_ret;
      end if;
    end loop;
    
    --自交收后重新交易商浮亏，让其释放转入交收的持仓对应的浮亏
    --dbms_output.put_line('6 -- >>  '|| to_char(sysdate,'yy-mm-dd hh24:mi:ss') );
    v_ret := FN_T_ReComputeFloatLoss();
    if(v_ret < 0) then
        rollback;
        return -100;
    end if;
    
    commit;

    return 1;

end;
/

