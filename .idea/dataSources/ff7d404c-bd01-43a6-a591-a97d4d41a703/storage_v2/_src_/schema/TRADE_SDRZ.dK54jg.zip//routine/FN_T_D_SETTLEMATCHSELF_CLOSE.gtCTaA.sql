CREATE function FN_T_D_SettleMatchSelf_close( p_CommodityID varchar2 --商品代码
) return number
/****
   * 某商品交收申报交易商自我配对
   * 返回值:1 =成功 ; -1=买方成交数量出错; -3=交收持仓数量大于可交收持仓数量;-4=交收抵顶数量大于可抵顶数量
   *修改：交收仅允许延期交收和到期交收，所有交收申报 委托时均冻结对应持仓，从而使用冻结持仓进行交收 yuansr 2016 10 26 ;
  ****/
 as
  v_version              varchar2(10) := '1.1.0.0';     ---交收申报委托冻结持仓明细，按冻结持仓进行交收
  v_ret                  number(4);                     ---返回值
  v_tradedAmount         number(10)   := 0;             ---成交数量
  v_closedHold_B         number(10)   := 0;             ---买方持仓交收处理数量
  v_closedHold_S         number(10)   := 0;             ---卖方持仓交收处理数量  
  v_TradeDate            date;                          ---交易日                    
  v_UnfrozenFunds        number(15, 2);                 ---解冻资金
  v_F_FrozenFunds        number(15, 2);                 ---冻结资金
  v_Status               number(2);                     ---成交情况：3=全部成交，2=部分成交
  v_num                  number(10);
  v_DelayNeedBill        number(2);                      --延期交收是否需要仓单，0：不需要； 1：需要；

  v_unCloseQty           number(10);                     --未平数量，用于中间计算
  v_OrderTradeQty        number(10);                     --成交数量，用于中间计算   
  v_selftTrade           number(2);                      --是否成交                          

begin
  --1、如果交收商品表中没有此商品则插入
  select count(*)  into v_num
    from T_SettleCommodity
   where CommodityID = p_CommodityID;
  
  if (v_num = 0) then
    select TradeDate into v_TradeDate from T_SystemStatus;
    insert into T_SettleCommodity
    select v_TradeDate, a.*
      from T_Commodity a where a.CommodityID = p_CommodityID;
  end if;

  --、查询 否需要仓单 等市场设置
  select DelayNeedBill   into v_DelayNeedBill   from T_A_Market;

  --查询交易日；
  select TradeDate into v_TradeDate from T_SystemStatus;
  
  --2 、轮询买委托(有持仓，且未成交大于0)记录（中立仓反向持仓优先撮合时有反向持仓的会员委托优先排序，不优先时只按委托号排序），根据冻结持仓进行处理
  for delayOrder_B in (select A_OrderNo   ,CommodityID    ,CustomerID   ,BS_Flag  ,(Quantity - TradeQty) NotTradeQty  ,Price    ,FrozenFunds
                              ,UnfrozenFunds  ,Quantity   ,TradeQty     ,FirmID  
                         from T_DelayOrders ,
                              (select distinct (t.FirmID) as FID    ,1 as OrderType ---查有订立持仓的交易商
                                 from T_HoldPosition t   
                                where t.BS_Flag = 1 --and t.HoldType = decode(v_NeutralMatchPriority, 1, 2, 0)  modifyby lyf 20160818 正常持仓‘1’
                                  and t.HoldType = 1  and t.CommodityID = p_CommodityID and overdat<=1
                              ) hp
                        where DelayOrderType = 3 and Status in (1, 2) and BS_Flag = 1  and CommodityID = p_CommodityID
                          and firmid = hp.FID  and Quantity >TradeQty   order by nvl(hp.OrderType, 0) desc, A_OrderNo asc
                          for update of A_OrderNo
                      )
  loop
      
      v_closedHold_B   :=0;
      v_UnfrozenFunds  :=0;
      v_unCloseQty     := delayOrder_B.NotTradeQty;--记录买委托 未成交数量
      --买方委托
      -- dbms_output.put_line('p -- >> 买 '||delayOrder_B.CommodityID||','||delayOrder_B.Price||','||delayOrder_B.BS_Flag
      --                         ||','||delayOrder_B.CustomerID||','||v_unCloseQty);
      --轮询卖委托(有持仓，且未成交大于0)记录，成交完买委托的数量
      for delayOrder_S in (select A_OrderNo  ,CommodityID   ,CustomerID   ,BS_Flag  ,(Quantity - TradeQty) NotTradeQty  ,Price  ,FrozenFunds
                                  ,UnfrozenFunds ,Quantity  ,FirmID 
                             from T_DelayOrders
                                  ,(select distinct (t.FirmID) as FID,1 as OrderType ---查有订立持仓的交易商
                                      from T_HoldPosition t
                                     where t.BS_Flag = 2 and overdat<=1   --and t.HoldType = decode(v_NeutralMatchPriority, 1, 2, 0)
                                       and t.HoldType = 1and t.CommodityID = p_CommodityID
                                  ) hp
                            where DelayOrderType = 3 and Status in (1, 2)and BS_Flag = 2 and CommodityID = p_CommodityID
                              and firmid = hp.FID  and Quantity > TradeQty
                              and customerid = delayOrder_B.Customerid --与自我配对
                            order by nvl(hp.OrderType, 0) desc, A_OrderNo asc
                              for update of A_OrderNo
                          )
      loop
          v_closedHold_S   :=0;
          v_tradedAmount   :=0; ---成交初始化为0
          v_UnfrozenFunds  :=0;
          v_selftTrade     :=1;
          if (delayOrder_S.NotTradeQty <= v_unCloseQty ) then
              --卖委托全部成交
              v_tradedAmount := delayOrder_S.NotTradeQty;
              v_Status        := 3;
              v_UnfrozenFunds := delayOrder_S.FrozenFunds - delayOrder_S.UnfrozenFunds;
          else
              --卖委托部分成交
              v_tradedAmount  := v_unCloseQty;
              v_Status        := 2;
              v_UnfrozenFunds := delayOrder_S.FrozenFunds * v_tradedAmount / delayOrder_S.Quantity;
          end if;
          /*dbms_output.put_line('v_tradedAmount  -- > '||v_tradedAmount);*/
          update T_DelayOrders
             set Status = v_Status   ,TradeQty = TradeQty + v_tradedAmount   ,UnfrozenFunds = UnfrozenFunds + v_UnfrozenFunds
           where A_OrderNo = delayOrder_S.A_OrderNo;
          --更新冻结资金
          v_F_FrozenFunds := FN_F_UpdateFrozenFunds(delayOrder_S.FirmID,  -v_UnfrozenFunds,   '15');
          if (v_DelayNeedBill = 1) then
            v_ret := FN_T_D_TradeBill(delayOrder_S.FirmID,  delayOrder_S.CommodityID, v_tradedAmount);
          end if;
          --自交收卖方持仓交收，涉及持仓明细，持仓合计，资金 （无 货款、交收保证金）
          v_ret := FN_T_D_SettleOneSelf_close( delayOrder_S.CommodityID, delayOrder_S.Price,   delayOrder_S.BS_Flag,  delayOrder_S.CustomerID ,v_tradedAmount
                                           ,  0 ,delayOrder_S.a_Orderno ,null   );
          v_unCloseQty  :=v_unCloseQty-v_tradedAmount ;
          exit when v_unCloseQty = 0;
      end loop;

      v_OrderTradeQty := delayOrder_B.NotTradeQty - v_unCloseQty;---计算成交数量
      if (v_unCloseQty = 0) then
        --全部成交
        v_Status        := 3;
        v_UnfrozenFunds := delayOrder_B.FrozenFunds - delayOrder_B.UnfrozenFunds;
      elsif (v_unCloseQty > 0 and v_unCloseQty < delayOrder_B.NotTradeQty) then
        --部分成交
        v_Status        := 2;
        v_UnfrozenFunds := delayOrder_B.FrozenFunds * v_OrderTradeQty /delayOrder_B.Quantity;
      elsif (v_unCloseQty = delayOrder_B.NotTradeQty) then
        --无卖方配对记录，成功返回
        --return 1;
        v_selftTrade:=0;
      else
        --出错回滚，要交收数量为负数了
        --rollback;
        return - 1;
      end if;
      if v_selftTrade =1 then ---有成交方更新委托数据
          update T_DelayOrders
             set Status        = v_Status,
                 TradeQty      = TradeQty + v_OrderTradeQty,
                 UnfrozenFunds = UnfrozenFunds + v_UnfrozenFunds
           where A_OrderNo = delayOrder_B.A_OrderNo;
          --更新冻结资金
          v_F_FrozenFunds := FN_F_UpdateFrozenFunds(delayOrder_B.FirmID,-v_UnfrozenFunds, '15');
          --自交收买方持仓交收处理，涉及持仓明细，持仓合计，资金（无货款、交收保证金）
          v_ret := FN_T_D_SettleOneSelf_close( delayOrder_B.CommodityID, delayOrder_B.Price, delayOrder_B.BS_Flag
                                               ,delayOrder_B.CustomerID  ,v_OrderTradeQty,  0 ,delayOrder_B.a_Orderno  ,null      );
          /* dbms_output.put_line('v_ret -- >>  卖持仓交收'||v_ret);*/
          if (v_ret < 0) then
            return v_ret;
          end if;
      end if;
  end loop;

  return 1;

end;
/

