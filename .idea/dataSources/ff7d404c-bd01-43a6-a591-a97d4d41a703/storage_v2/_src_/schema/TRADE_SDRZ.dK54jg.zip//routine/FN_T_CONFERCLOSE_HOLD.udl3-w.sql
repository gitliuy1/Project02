CREATE function FN_T_ConferClose_hold(p_customerid_b varchar2, --买方交易客户ID
                                                 p_customerid_s varchar2, --卖方交易客户ID
                                                 p_CommodityID  varchar2, --商品
                                                 p_price        number, --委托价格
                                                 p_quantity     number, --委托数量
                                                 p_settletype   number default null, --交收方式
                                                 p_settletPrice number , --交收方式
                                                 p_creator      varchar2, --委托人,创建人
                                                 p_remark1      varchar2, --备注
                                                 p_holdno_b     varchar2, --买方指定持仓单号
                                                 p_holdno_s     varchar2 --卖方指定持仓单号
                                                 ) return number
/****
   * 指定持仓协议交收委托
   * 平仓委托
   * 返回值： >0  成功提交，并返回委托单号 ; -2=商品代码不存在;-3=买二级代码不存在;-4=卖二级代码不存在;-5=买方持仓不足;-6=卖方持仓不足;
   * -11=买方持仓单号非法;-12=卖方持仓单号非法;-13=买方指定持仓数量不足;-14=卖方指定持仓数量不足;
   * -21=持仓不足 ;-22=指定仓不足 ;-99= 不存在相关数据; -100= 其它错误
  ****/
 as
  v_version      varchar2(10) := '1.0.0.0';
  v_count        number(10); --合计条目
  v_A_OrderNo    number(15); --委托号
  v_firmId_b     T_Holdfrozen.Firmid%type;
  v_firmId_s     T_Holdfrozen.Firmid%type;
  v_errorcode    number;
  v_errormsg     varchar2(500);
  --v_sql          varchar2(1200);
  v_A_HoldNo     number(15);--持仓单号
  v_A_HoldNos    varchar2(200);--已处理持仓单号
  v_indexNo      number(10);
  v_start        number(10):=0; 
  v_end          number(10):=0;
  v_isOk         number(10):=0; 
  v_numqty       number(10);--待处理数量
  --v_s_HoldFrozen number(10); --当日申报委托持仓冻结
  v_A_OrderNo_L                     number(15);            --临时委托单号
begin

  --1、检查商品、买交易客户，卖交易客户是否合法

  select count(1) into v_count  from t_commodity t where t.commodityid = p_CommodityID;
  if (v_count < 1) then
    rollback;
    return - 2; --商品代码不存在
  end if;

  select count(1) into v_count from t_customer t where t.customerid = p_customerid_b;
  if (v_count < 1) then
    rollback;
    return - 3; --买二级代码不存在
  end if;

  select count(1) into v_count from t_customer t where t.customerid = p_customerid_s;
  if (v_count < 1) then
    rollback;
    return - 4; --卖二级代码不存在
  end if;

  --2.验证交易客户持仓是否充足,加锁
  select nvl(holdqty - frozenqty, 0) into v_count from T_CustomerHoldSum t
   where t.bs_flag = 1  and t.commodityid = p_CommodityID and t.customerid = p_customerid_b for update;
  if (v_count < p_quantity) then
    rollback;
    return - 5; --买方持仓不足
  end if;

  select nvl(holdqty - frozenqty, 0) into v_count  from T_CustomerHoldSum t
   where t.bs_flag = 2 and t.commodityid = p_CommodityID  and t.customerid = p_customerid_s for update;
  if (v_count < p_quantity) then
    rollback;
    return - 6; --卖二方持仓不足
  end if;
  ---3查询处理指定持仓数据
  if(p_settletype=2)then
    execute immediate 'select count(1) v_count from t_Holdposition t '
                    ||' where t.bs_flag = 1  and t.commodityid = '''||p_CommodityID||''''
                    ||' and t.customerid = '''||p_customerid_b||''' and  t.a_holdno in ('||p_holdno_b||') ' into v_count;
    if (v_count < lengthb(regexp_replace(p_holdno_b,'[^,]',null))+1) then
      rollback;
      return - 11; --买方持仓单号非法
    end if;
    execute immediate 'select count(1) v_count from t_Holdposition t '
                    ||' where t.bs_flag = 2  and t.commodityid = '''||p_CommodityID||''''
                    ||' and t.customerid = '''||p_customerid_s||''' and t.a_holdno in ('||p_holdno_s||') ' into v_count;
    if (v_count < lengthb(regexp_replace(p_holdno_s,'[^,]',null))+1) then
      rollback;
      return - 12; --卖方持仓单号非法
    end if;
  end if;

  select SEQ_T_S_OrderFrozenHold.nextval into v_A_OrderNo_L from dual;
  v_A_HoldNos:='';
  v_numqty:=p_quantity;
  v_start:=1;
  for v_indexNo in 1..lengthb(regexp_replace(p_holdno_b||',','[^,]',null)) ---按序处理，录入顺序，即字符串顺序
  loop
    if (v_indexNo>1) then
       v_start    :=instr(p_holdno_b, ',', 1, v_indexNo-1)+1; 
    end if;
    v_end      :=instr(p_holdno_b||',', ',', 1, v_indexNo)-1; 
    v_A_HoldNo := TO_NUMBER( substr(p_holdno_b,v_start,v_end) );
    ---处理持仓明细，冻结持仓数量
    for hold in ( select a.price,a.overdat,a.HoldQty ,a.HoldQty-nvl(b.FrozenQty,0)-nvl(c.FrozenQty,0) freeqty ,a.A_HoldNo 
                    from T_holdposition a
                         ,(select sum(FrozenQty) FrozenQty from T_SpecFrozenHold where A_HoldNo=v_A_HoldNo ) b
                         ,(select sum(frozenqty - unfrozenqty) FrozenQty from T_S_OrderFrozenHold
                            where bs_flag = 1 and A_HoldNo=v_A_HoldNo  ) c---有效冻结=冻结-解冻
                   where a.CustomerID=p_CustomerID_b and a.CommodityID = p_CommodityID
                     and (a.holdkind<>1 or a.holdkind is null) and a.bs_flag =  1  and a.a_holdno=v_A_HoldNo
                     for update of a.A_HoldNo ---并锁住持仓
               )
    loop
      v_isOk:=1;
      if(hold.freeqty>0) then
         if(v_numqty>=hold.freeqty)  then
            insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty  ,Ordertype )
            values ( v_A_OrderNo_L  ,hold.A_HoldNo    ,1           ,hold.freeqty   ,hold.freeqty            ,0     ,1 );
            v_numqty:=v_numqty-hold.freeqty;
         else
           insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty  ,Ordertype )
            values ( v_A_OrderNo_L  ,hold.A_HoldNo    ,1           ,v_numqty   ,v_numqty            ,0      ,1 );
            v_numqty:=v_numqty-v_numqty;
         end if;
      end if;
    end loop;
    if(v_isOk=0) then
       rollback;
       return - 11; --买方持仓单号非法不足
    else
       v_isOk:=0;
    end if; 
    if (v_indexNo>1) then
       v_A_HoldNos:= v_A_HoldNos||','||v_A_HoldNo;
    else
      v_A_HoldNos:= v_A_HoldNo||'';
    end if;
    --完成冻结持仓明细
    if (v_numqty=0) then 
      exit;
    end if;
  end loop;
  --买方数量不足委托数
  if(v_numqty>0 or v_numqty<0) then
     rollback;
     return -13;
  end if;

  v_A_HoldNos:='';
  v_numqty:=p_quantity;
  v_start:=1;
  for v_indexNo in 1..lengthb(regexp_replace(p_holdno_s||',','[^,]',null))
  loop
    if (v_indexNo>1) then
       v_start    :=instr(p_holdno_s, ',', 1, v_indexNo-1)+1; 
    end if;
    v_end      :=instr(p_holdno_s||',', ',', 1, v_indexNo)-1;
    v_A_HoldNo := TO_NUMBER( substr(p_holdno_s,v_start,v_end) );
    ---处理持仓明细，冻结持仓数量
    for hold in (  select a.price,a.overdat,a.HoldQty ,a.HoldQty-nvl(b.FrozenQty,0)-nvl(c.FrozenQty,0) freeqty ,a.A_HoldNo 
                    from T_holdposition a
                         ,(select sum(FrozenQty) FrozenQty from T_SpecFrozenHold where A_HoldNo=v_A_HoldNo ) b
                         ,(select sum(frozenqty - unfrozenqty) FrozenQty from T_S_OrderFrozenHold
                            where bs_flag = 2 and A_HoldNo=v_A_HoldNo ) c---有效冻结=冻结-解冻
                   where a.CustomerID=p_CustomerID_s and a.CommodityID = p_CommodityID
                     and a.bs_flag =  2  and a.a_holdno=v_A_HoldNo
                     for update of a.A_HoldNo ---并锁住持仓
                 )
    loop
      v_isOk:=1;
      if(hold.freeqty>0) then
         if(v_numqty>=hold.freeqty)  then
            insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty  ,Ordertype )
            values ( v_A_OrderNo_L  ,hold.A_HoldNo    ,2           ,hold.freeqty   ,hold.freeqty            ,0      ,1 );
            v_numqty:=v_numqty-hold.freeqty;
         else
           insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty    ,Ordertype )
            values ( v_A_OrderNo_L  ,hold.A_HoldNo    ,2           ,v_numqty   ,v_numqty            ,0      ,1 );
            v_numqty:=v_numqty-v_numqty;
         end if;
      end if;
    end loop;
    if(v_isOk=0) then
       rollback;
       return - 12; --卖方持仓单号非法不足
    else
       v_isOk:=0;
    end if;  
    if (v_indexNo>1) then
       v_A_HoldNos:= v_A_HoldNos||','||v_A_HoldNo;
    else
      v_A_HoldNos:= v_A_HoldNo||'';
    end if;
     --完成冻结持仓明细
    if (v_numqty=0) then 
      exit;
    end if;
  end loop;
  --卖方数量不足委托数
  if(v_numqty>0 or v_numqty<0) then
     rollback;
     return -14;
  end if;
  
  ---4处理委托数据
  select SEQ_T_E_ApplyTreatySettle.nextval into v_A_OrderNo from dual;
  insert into T_E_ApplyTreatySettle( applyid, commodityid, customerid_s, customerid_b, price, quantity, status, createtime
                                     ,creator, remark1, settletype, holdno_s, holdno_b ,Settleprice )
  values ( v_A_OrderNo, p_CommodityID, p_customerid_s, p_customerid_b, p_price, p_quantity, 1, sysdate
           ,p_creator,  p_remark1,     p_settletype, p_holdno_s, p_holdno_b ,p_settletPrice);

  select t.firmid into v_firmId_b from t_customer t where t.customerid=p_customerid_b;
  select t.firmid into v_firmId_s from t_customer t where t.customerid=p_customerid_s;
  --更新持仓合计冻结资金（买方）
  update T_CustomerHoldSum set frozenQty = frozenQty + p_quantity
   where CommodityID = p_CommodityID and customerid = p_customerid_b and bs_flag = 1;
  --冻结数量记录在持仓冻结表（买方）
  insert into T_Holdfrozen(ID, Operation, FirmID, CustomerID, CommodityID, BS_Flag, frozentype, FrozenQTY, frozenTime)
  values (SEQ_T_HOLDFROZEN.nextval, v_A_OrderNo, v_firmId_b, p_customerid_b, p_CommodityID, 1, 1, p_quantity, sysdate );
  --卖方持仓（卖方）
  update T_CustomerHoldSum set frozenQty = frozenQty + p_quantity
   where CommodityID = p_CommodityID and customerid = p_customerid_s and bs_flag = 2;
  --冻结数量记录在持仓冻结表（卖方）
  insert into T_Holdfrozen (ID, Operation, FirmID, CustomerID, CommodityID, BS_Flag, frozentype, FrozenQTY, frozenTime)
  values (SEQ_T_HOLDFROZEN.nextval, v_A_OrderNo, v_firmId_s, p_customerid_s, p_CommodityID, 2, 1, p_quantity, sysdate );
  --更新 交收申报委托持仓关系表 ：使用委托单号替换 临时委托代号
  update T_S_OrderFrozenHold t set t.a_orderno=v_A_OrderNo  where t.a_orderno=v_A_OrderNo_L;

  return v_A_OrderNo;
exception
  when NO_DATA_FOUND then
    rollback;
    return - 99; --不存在相关数据
  when others then
    v_errorcode := sqlcode;
    v_errormsg  := sqlerrm;
    rollback;
    insert into T_DBLog (err_date, name_proc, err_code, err_msg)
    values (sysdate, 'FN_T_ConferClose_hold', v_errorcode, substr(v_errormsg,1,200 ));
    commit;
    return - 100;
end;
/

