CREATE function FN_T_D_SettleMatch_txandfirm return number
/****
 * 交收申报配对 ,针对特许服务商和交易商撮合交收
 * add by lyf 20160802
 * 返回值
 * 1 成功
 * -1  买方成交数量出错
 * -3  交收持仓数量大于可交收持仓数量
 * -4  交收抵顶数量大于可抵顶数量
 * -99  不存在相关数据
 * -100 其它错误
 *修改： 交易保证金 按持仓到期天数(到期交收 到期天数计 1 ) 所处阶段 设置参数 计算       yuansr 2016 10 30
****/
as
  v_version varchar2(10):='1.0.2.2';
    v_ret     number(4);
    v_FL_ret            timestamp;
    v_errorcode number;
    v_errormsg  varchar2(200);
    v_price t_quotation.curprice%type;
    v_margin number(15,2);  --交易保证金
    v_tradeday  number(8) := 0 ;   --下一个交易日
    v_HoldSum   number(15);
begin
     --1.自动生成到期交收委托数据
    -- for cur_b in (select CommodityID from T_Commodity where SettleWay=1) loop
         v_tradeday := FN_t_ComputeTrustDays;
         --买交收申报委托
         /*if v_tradeday>1 then
            for cur_holdposition_b1 in (select firmid,customerid,commodityid,sum(holdqty) qty from t_holdposition t where t.overdat<=v_tradeday+1 and bs_flag=1 group by firmid,commodityid,customerid order by t.firmid) loop
                select Price into v_price from t_quotation where commodityid = cur_holdposition_b1.commodityid ; --modify by lyf 20160812 安交收结算价结算
                --add by lyf 20160811 增加持仓合计可用数量的查询
                select nvl(holdQty - frozenQty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_b1.customerid and CommodityID = cur_holdposition_b1.commodityID and bs_flag = 1;
                if v_HoldSum>0 then
                  if v_HoldSum>=cur_holdposition_b1.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
                     v_margin := FN_T_ComputeMargin(cur_holdposition_b1.firmid,cur_holdposition_b1.commodityid,1,cur_holdposition_b1.qty,v_price);
                     v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b1.firmid,cur_holdposition_b1.firmid,cur_holdposition_b1.commodityid,cur_holdposition_b1.qty,v_price,cur_holdposition_b1.customerid,'',v_margin,1,v_price);
                  else
                     v_margin := FN_T_ComputeMargin(cur_holdposition_b1.firmid,cur_holdposition_b1.commodityid,1,v_HoldSum,v_price);
                     v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b1.firmid,cur_holdposition_b1.firmid,cur_holdposition_b1.commodityid,v_HoldSum,v_price,cur_holdposition_b1.customerid,'',v_margin,1,v_price);
                  end if;
                end if;
            end loop;
         else*/   --下一天就是交易日
             for cur_holdposition_b2 in (select firmid,customerid,commodityid,sum(holdqty) qty from t_holdposition t where t.overdat<=1 and bs_flag=1 group by firmid,commodityid,customerid order by t.firmid) loop
               select Price into v_price from t_quotation where commodityid = cur_holdposition_b2.commodityid ;
               --add by lyf 20160811 增加持仓合计可用数量的查询
                select nvl(holdQty - frozenQty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_b2.customerid and CommodityID = cur_holdposition_b2.commodityID and bs_flag = 1;
               if v_HoldSum>0 then
                 if v_HoldSum>=cur_holdposition_b2.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
                    if cur_holdposition_b2.qty > 0 then
                       v_margin := FN_T_ComputeMarginPlus(cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,1,1,cur_holdposition_b2.qty,v_price);
                       v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b2.firmid,cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,cur_holdposition_b2.qty,v_price,cur_holdposition_b2.customerid,'',v_margin,1,v_price);
                    end if;
                 else
                    v_margin := FN_T_ComputeMarginPlus(cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,1,1,v_HoldSum,v_price);
                    v_ret :=FN_T_D_BuySettleOrder_close(cur_holdposition_b2.firmid,cur_holdposition_b2.firmid,cur_holdposition_b2.commodityid,v_HoldSum,v_price,cur_holdposition_b2.customerid,'',v_margin,1,v_price);
                 end if;
               end if;
             end loop;
        /* end if;*/

         --卖交收申报委托
        /* if v_tradeday>1 then
            for cur_holdposition_s1 in (select firmid,customerid,commodityid,sum(holdqty) qty from t_holdposition t where t.overdat<=v_tradeday+1 and bs_flag=2 group by firmid,commodityid,customerid order by t.firmid) loop
               select Price into v_price from t_quotation where commodityid = cur_holdposition_s1.commodityid ;
               --add by lyf 20160811 增加持仓合计可用数量的查询
               select nvl(holdQty - frozenQty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_s1.customerid and CommodityID = cur_holdposition_s1.commodityID and bs_flag = 2;
               if v_HoldSum>0 then
                 if v_HoldSum>=cur_holdposition_s1.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
                     v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s1.firmid,cur_holdposition_s1.firmid,cur_holdposition_s1.commodityid,cur_holdposition_s1.qty,v_price,cur_holdposition_s1.customerid,'',1,0,v_price);
                 else
                     v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s1.firmid,cur_holdposition_s1.firmid,cur_holdposition_s1.commodityid,v_HoldSum,v_price,cur_holdposition_s1.customerid,'',1,0,v_price);
                 end if;
               end if;
            end loop;
         else*/
             for cur_holdposition_s2 in (select firmid,customerid,commodityid,sum(holdqty+gageqty) qty from t_holdposition t where t.overdat<=1 and bs_flag=2 group by firmid,commodityid,customerid order by t.firmid) loop
                 select Price into v_price from t_quotation where commodityid = cur_holdposition_s2.commodityid ;
                 --add by lyf 20160811 增加持仓合计可用数量的查询
                 select nvl(holdQty - frozenQty+gageqty-gagefrozenqty, 0) into v_HoldSum  from T_CustomerHoldSum where CustomerID = cur_holdposition_s2.customerid and CommodityID = cur_holdposition_s2.commodityID and bs_flag = 2;
                 if v_HoldSum>0 then
                     if v_HoldSum>=cur_holdposition_s2.qty then   --add by lyf 20160812 增加持仓合计数量和持仓明细持仓数量对比，如果持仓合计和数量 < 持仓明细的，则标明持仓合计里的数量全部是到期持仓明细的数量
                        if cur_holdposition_s2.qty>0 then
                           v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s2.firmid,cur_holdposition_s2.firmid,cur_holdposition_s2.commodityid,cur_holdposition_s2.qty,v_price,cur_holdposition_s2.customerid,'',1,0,v_price);
                        end if;
                     else
                        v_ret :=FN_T_D_SellSettleOrder_close(cur_holdposition_s2.firmid,cur_holdposition_s2.firmid,cur_holdposition_s2.commodityid,v_HoldSum,v_price,cur_holdposition_s2.customerid,'',1,0,v_price);
                     end if;
                 end if;
             end loop;
        /* end if;*/
    -- end loop;

     --2.撮合交收数据  (先把所有到期的委托打入交收数据，再根据交收数据明细撮合特许服务商)
    for cur_Commodity in(select CommodityID from T_Commodity where SettleWay=1 )
    loop
      ---优先自我配对处理 yuansr 2017 09 02
      v_ret := FN_T_D_SettleMatchSelf_close(cur_Commodity.CommodityID);
      if(v_ret < 0) then
        --rollback;
        return v_ret;
      end if;
    end loop;
 /*   --3.自交收  add by lyf 20160812
     v_ret :=FN_T_SettleMatch_TX();   --特许自己先撮合
    if(v_ret < 0) then
       --rollback;
       return v_ret;
    end if;
    
    --4.子特许自交收  add by 20170714
     v_ret :=FN_T_SettleMatch_TX2();   
    if(v_ret < 0) then
       --rollback;
       return v_ret;
    end if;*/

    --3 所有交易商都进行自交收（包含总特许和自特许） add by 2017-08-08 hanqr
    v_ret :=FN_T_SettleMatch_TX3();   
    if(v_ret < 0) then
       --rollback;
       return v_ret;
    end if;
    
    --4 .撮合剩余交收数据 
    for cur_Commodity in(select CommodityID from T_Commodity where SettleWay=1 )
    loop
      v_ret := FN_T_D_SettleMatchOne_close(cur_Commodity.CommodityID);
      if(v_ret < 0) then
        --rollback;
        return v_ret;
      end if;
    end loop;
    
    --提交后计算此交易商浮亏，让其释放浮亏
   -- commit;
    v_FL_ret := FN_T_UpdateFloatingLoss(null,null,null);

    return 1;
/*exception
    when NO_DATA_FOUND then
        rollback;
        return -99;  --不存在相关数据
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_T_D_SettleMatch_txandfirm',v_errorcode,v_errormsg);
    --commit;
    return -100;*/
end;
/

