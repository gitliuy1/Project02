CREATE function FN_F_B_OUTMONEY_2
(
  p_bankID varchar2,      --银行编号
  p_firmID varchar2,      --交易商代码
  p_amount number,        --发生额
  p_remark varchar2,      --备注
  p_type varchar2  ,       --发起方（M:市场  B:银行）
  p_funID varchar2  ,      --银行流水号
  p_actionID varchar2        --银行流水号
) return number
/***
 * 出金
 * version 1.0.0.0 此方法公用
 *
 * 返回值：资金流水号
 ****/
is
  v_reNum number(10):=0;           -- 返回值 大于0 流水号   小于0 错误码
  v_control number(1);           -- 0 受到双重约束，1不受约束，2受交易日约束，3受交易时间约束
  v_beginTime varchar2(8);       -- 交易开始时间
  v_endTime varchar2(8);         -- 交易结束时间
  v_actionid varchar2(100);      -- 出入金流水号
  v_notTradeWeek number(10);     -- 非交易日
  v_notTradeDay number(10);      -- 非交易日
  v_status number(1);            --客户状态  0不可用 1可用
  v_isOpen number(1);            --签解约状态 0未签约 1已签约
  v_tradeFee number(15,2) default 0;       --手续费
  v_dicOut varchar(8);            --出金摘要
  v_dicFee varchar(8);           --手续费摘要
  v_oprCode varchar(8);          --银行科目
  v_realfunds number(15,2);      --可用资金
  v_canOUT number(15,2);         --可取资金
  v_lastrealfunds number(15,2);      --上日可用资金
  v_sumIN number(15,2);          --入金合计
  v_sumOUT number(15,2);         --出金合计
  v_frozenFunds number(15,2);    --冻结余额
  v_maxPerSglTransMoney_b number(15,2);   --单笔最大
  v_maxPerTransMoney_b number(15,2);      --每日最大
  v_maxPerTransCount_b number(10);       --每日累计次数
  v_moneyThreshold_b number(15,2);     --出金阈值
  v_maxPerSglTransMoney_f number(15,2);   --单笔最大
  v_maxPerTransMoney_f number(15,2);      --每日最大
  v_maxPerTransCount_f number(10);       --每日累计次数
  v_moneyThreshold_f number(15,2);     --出金阈值
  v_sumCount number(10) default 0;                  --每次实际累计次数
  v_sumMoney number(15,2) default 0;          --每日实际已转金额
  v_t number(15);
   v_count number(8);       --流水条数
    v_countDate number(8);       --流水条数
begin
  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('1'||v_t);*/
  begin
    select nvl(maxPerTransMoney,0),nvl(maxPerTransCount,0),nvl(maxPerSglTransMoney,0),nvl(moneyThreshold,0),nvl(control,0),beginTime,endTime into v_maxPerTransMoney_b,v_maxPerTransCount_b,v_maxPerSglTransMoney_b,v_moneyThreshold_b,v_control,v_beginTime,v_endTime from F_B_banks where bankid=p_bankID;
  exception when NO_DATA_FOUND then
    v_reNum := -1; --银行不存在；
    return v_reNum;
  end;

  --判断交易日期及交易时间
  if(v_control=0) then
   begin
    select count(*) into v_countDate from t_a_nottradeday;
    if(v_countDate!=0) then
      select instr(''||week,to_char(sysdate,'D')),instr(''||day,to_char(sysdate,'yyyy-MM-dd')) into v_notTradeWeek,v_notTradeDay from t_a_nottradeday ;
      if(v_notTradeWeek>0 or v_notTradeDay>0) then
         v_reNum := -2;--非交易日
         return v_reNum;
      end if;
       end if;
    exception when NO_DATA_FOUND then
    v_reNum := 0;
    end;
    if(to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmddHH24:Mi:ss')>sysdate or to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')<sysdate) then
         v_reNum := -3; --非交易时间
         return v_reNum;
    end if;

  elsif(v_control=2) then
    begin
     select count(*) into v_countDate from t_a_nottradeday;
       if(v_countDate!=0) then
          select instr(''||week,to_char(sysdate,'D')),instr(''||day,to_char(sysdate,'yyyy-MM-dd')) into v_notTradeWeek,v_notTradeDay from t_a_nottradeday ;
          if(v_notTradeWeek>0 or v_notTradeDay>0) then
             v_reNum := -2;--非交易日
             return v_reNum;
          end if;
       end if;
    exception when NO_DATA_FOUND then
    v_reNum := 0;
    end;
  elsif(v_control=3) then
      --select * from dual t where to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmdd HH24:Mi:ss')<sysdate and to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')>sysdate
      if(to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmddHH24:Mi:ss')>sysdate or to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')<sysdate) then
         v_reNum := -3; --非交易时间
         return v_reNum;
      end if;
  end if;
--判断交易商状态
  begin
    select status,isopen into v_status,v_isOpen from f_b_Firmidandaccount where firmid=p_firmID and bankid=p_bankID;
  exception when NO_DATA_FOUND then
    v_reNum := -4; --交易商不存在
    return v_reNum;
  end;
  if(v_status!=0)then
    v_reNum := -5; --交易商不可用
    return v_reNum;
  end if;
  if(v_isOpen!=1)then
    v_reNum := -6; --交易商未签约
    return v_reNum;
  end if;
  if(p_type='B')then
    select nvl(count(*),0) into v_count from f_b_capitalinfo where funid=p_funID and bankid=p_bankID and createdate=to_char(sysdate,'yyyy-MM-dd');
    if(v_count>0) then
      v_reNum:=-11;--银行流水号已存在
      return v_reNum;
    end if;
  end if;

  if(p_actionID>0)then
  select  nvl(count(*),0) into v_count from f_b_capitalinfo where actionID=p_actionID and bankid=p_bankID and createdate=to_char(sysdate,'yyyy-MM-dd');
  if(v_count>0) then
      v_reNum:=-12;--市场流水号已存在
      return v_reNum;
    end if;
  end if;
  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('2'||v_t);*/

  --校验出金条件，单笔，次数等等
  begin
    select nvl(maxPerTransMoney,0),nvl(maxPerTransCount,0),nvl(maxPerSglTransMoney,0)，nvl(moneyThreshold,0) into v_maxPerTransMoney_f,v_maxPerTransCount_f,v_maxPerSglTransMoney_f,v_moneyThreshold_f from F_B_FirmUser where firmid=p_firmID;
  exception when NO_DATA_FOUND then
    v_reNum := -4; --交易商不存在
    return v_reNum;
  end;

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('2.1-'||v_t);*/

  if(v_maxPerSglTransMoney_f > 0) then    --最大单笔
    v_maxPerSglTransMoney_f := v_maxPerSglTransMoney_f;
  else
    v_maxPerSglTransMoney_f := v_maxPerSglTransMoney_b;
  end if;

  if(v_maxPerTransMoney_f > 0) then      --每日最大
    v_maxPerTransMoney_f := v_maxPerTransMoney_f;
  else
    v_maxPerTransMoney_f := v_maxPerTransMoney_b;
  end if;

  if(v_maxPerTransCount_f > 0) then     --每次累计次数
    v_maxPerTransCount_f := v_maxPerTransCount_f;
  else
    v_maxPerTransCount_f := v_maxPerTransCount_b;
  end if;

  if(v_moneyThreshold_f>0) then --出金阈值
     v_moneyThreshold_f:=v_moneyThreshold_f;
  else
     v_moneyThreshold_f:=v_moneyThreshold_b;
  end if;

  if(p_amount > v_maxPerSglTransMoney_f) then
    v_reNum := -7;    --超过单笔最大
    return v_reNum;
  end if;

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('2.2-'||v_t);*/

  select /*+ index(f_b_capitalinfo,IDX_F_B_CAPITALINFO_FIRMID) */ nvl(sum(money),0) into v_sumMoney from f_b_capitalinfo where createdate = to_char(sysdate,'yyyy-MM-dd') and bankid = p_bankID and firmid = p_firmID and status<>1 and type=1;
  if(v_sumMoney+p_amount > v_maxPerTransMoney_f) then
    v_reNum := -8;    -- 超过每日累计最大
    return v_reNum;
  end if;

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('2.3-'||v_t);*/

  select /*+ index(f_b_capitalinfo,IDX_F_B_CAPITALINFO_FIRMID) */ nvl(count(*),0) into v_sumCount from f_b_capitalinfo where createdate = to_char(sysdate,'yyyy-MM-dd') and bankid = p_bankID and firmid = p_firmID and type=1;
  if(v_sumCount+1 > v_maxPerTransCount_f) then
    v_reNum := -9;    -- 超过每日累计出金次数
    return v_reNum;
  end if;

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('2.4-'||v_t);*/

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('3'||v_t);*/
  -- 判断可出资金
  /*    规则：上日期末+当日入金-当日出金与当前可用资金取小
              默认当日入金可出，如要设置当日入金不可出计算的时候上日期末不加上当日入金即可
  */
  v_realfunds := FN_F_GetRealFunds(p_firmID,1);    --当前可用
  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('3.1-'||v_t);*/
  begin
      select nvl(todaybalance,0) into v_lastrealfunds from f_firmbalance where b_date = (select max(B_Date) bdate from f_firmbalance t where B_Date<trunc(sysdate)) and firmid=p_firmID;   --上日期末余额(当日期初余额)
  exception when NO_DATA_FOUND then
    v_lastrealfunds := 0;
  end;
  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('3.2-'||v_t);*/

  select /*+ index(f_b_capitalinfo,IDX_F_B_CAPITALINFO_FIRMID) */ nvl(sum(case when type=0 then money else 0 end),0) into v_sumIN from f_b_capitalinfo where bankid = p_bankID and status=0 and createdate = to_char(sysdate,'yyyy-MM-dd') and firmid = p_firmID;
    /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('3.3-'||v_t);*/
  select /*+ index(f_b_capitalinfo,IDX_F_B_CAPITALINFO_FIRMID) */ nvl(sum(case when type=1 then money else 0 end),0) into v_sumOUT from f_b_capitalinfo where bankid = p_bankID and status<>1 and createdate = to_char(sysdate,'yyyy-MM-dd') and firmid = p_firmID;

  --当日入金可出
 if(v_lastrealfunds + v_sumIN - v_sumOUT >= v_realfunds) then
  v_canOUT := v_realfunds-v_moneyThreshold_f;
  else
  v_canOUT := v_lastrealfunds + v_sumIN - v_sumOUT-v_moneyThreshold_f;
 end if;

  --当日入金不可出
  /* if(v_lastrealfunds  - v_sumOUT >= v_realfunds) then
    v_canOUT := v_realfunds-v_moneyThreshold_f;
  else
    v_canOUT := v_lastrealfunds  - v_sumOUT-v_moneyThreshold_f;
  end if;*/

  /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
  dbms_output.put_line('4'||v_t);*/

  --计算交易商手续费数据
    --手续费暂时不处理默认为0.后期考虑加上

  if(p_amount+v_tradeFee <= v_canOUT) then
    --冻结财务资金
    v_frozenFunds := FN_F_UpdateFrozenFunds(p_firmID,p_amount+v_tradeFee,28);  --冻结财务资金
    update F_B_firmidandaccount set frozenFuns=frozenFuns + p_amount where firmid =p_firmID and bankid = p_bankID;  --冻结银行接口资金
    if(SQL%ROWCOUNT = 0) then
      v_reNum := -4; --交易商不存在
      return v_reNum;
    end if;

    /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
    dbms_output.put_line('5'||v_t);*/

    --插入资金流水
    if(p_actionID>0) then
    v_actionid:=p_actionID;
    else
    select SEQ_F_B_ACTION.nextval into v_actionid from dual;
    end if;
    select value into v_dicOut from f_b_dictionary where name = 'outsummary';
    select value into v_dicFee from f_b_dictionary where name = 'feesummary';
    select value into v_oprCode from f_b_dictionary where type=1 and bankid=p_bankid;
    insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
    values(SEQ_F_B_CAPITALINFO.nextval, p_firmID, null, p_bankID, v_oprCode, p_firmid, 1, p_amount, v_dicOut, sysdate, null, 2, p_remark, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);

    insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
    values(SEQ_F_B_CAPITALINFO.nextval, p_firmID, null, p_bankID, p_firmid, 'Market', 2, v_tradeFee, v_dicFee, sysdate, null, 2, p_remark, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);

    /*SELECT (SYSDATE - TO_DATE('1970-1-1 8', 'YYYY-MM-DD HH24')) * 86400000 + TO_NUMBER(TO_CHAR(SYSTIMESTAMP(3), 'FF')) AS MILLIONS into v_t FROM DUAL;
    dbms_output.put_line('6'||v_t);*/

  else --余额不足
    v_reNum := -10;
    return v_reNum;
  end if;



  return v_actionid;
end;
/

