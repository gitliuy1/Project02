CREATE function fn_br_r_financereward (
       p_doDate           date  ---返佣日期
) return number
/*********************************
 * 佣金返款方法：（验证返款前提）
 *   1 获取佣金记录
 *   2 获取会员信息
 *   3 写流水，修改佣金记录
 *返回值：
 *   1=计算成功；-1=不是闭市计算完成状态；-2=财务结算已完成；-3=不是计算完成状态；-100= 系统异常，返款失败；
 *
 ********************************/
is
    v_b_date              date;           ---结算系统日期
    v_trade_date          date;           ---结算系统日期
    --v_sys_date            date;           ---系统日期
    v_status              number(2,0) ;   --系统状态
    v_fresult             number(16,2);
    v_errorcode           number;
    v_errormsg            varchar2(200);
    v_firstpayrate        number(6,4)  ;  --首款比例
    v_autopay             char(1);        --是否自动付佣金 Y 是 N 否
     v_payDate            date;
begin

    ---截止日期 必须是已结算，且系统必须处于结算完成状态：交易日
    select tradedate ,status  into v_trade_date，v_status from t_systemstatus t for update;
    if p_doDate>v_trade_date or v_status<>10 then
       return -1;----不是闭市计算完成状态
    end if;

    select status  into v_status from f_systemstatus t for update;

    if v_status=2 then
      return -2;----财务结算已完成
    end if;

    select status,b_date into v_status,v_b_date from br_r_systemstatus t for update nowait;

    if v_status not in (2) then
       return -3;----不是计算完成状态
    end if;

    update br_r_systemstatus t set t.status=3;
    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=3;

    commit;
    
    --v_sys_date:=trunc(sysdate);

    --查询是否自动付佣金 Y 是 N 否
    select autopay into v_autopay from BR_RewardParameterProps;
    if(v_autopay = 'N') then --如果是手动付佣金，将当日佣金明细首款置为0 ，尾款为总佣金
       v_firstpayrate:=0;
    else
      --获取首款比例 yuansr 2018 01 31
      select firstpayrate into v_firstpayrate from  BR_BrokerRewardProps;
    end if;
    --计算付款日
    v_payDate := FN_BR_BrokerPayDate(p_doDate);

    update br_r_rewardinfo t set t.firstpay  = trunc((nvl(t.reward,0)+nvl(t.salereward,0))*v_firstpayrate,2)
     where t.cleardate = p_doDate;
     
    ---更新交易明细佣金首尾款
    update br_r_firmcomoditydaytrade t set t.firstpay = trunc(t.reward*v_firstpayrate,2) ,t.secondpay=t.reward-trunc(t.reward*v_firstpayrate,2)
     where t.cleardate=p_doDate;

    ---更新直供明细佣金首尾款
    update BR_R_FIRMSALEREWARD t set t.firstpay = trunc(t.reward*v_firstpayrate,2) ,t.secondpay=t.reward-trunc(t.reward*v_firstpayrate,2)
     where t.cleardate=p_doDate;

    for rewardItem in ( select t.brokerid,t.cleardate,nvl(t.reward,0)+nvl(t.salereward,0) Reward ,t1.firmid ,t.firstpay
                          from br_r_rewardinfo t,br_broker t1
                         where t.brokerid=t1.brokerid and (nvl(t.reward,0)>0 or nvl(t.salereward,0)>0) and t.cleardate=p_doDate
                         order by t.grade asc,t.brokerid asc for update )
    loop
         v_fresult:=fn_f_updatefunds(rewardItem.Firmid,'15019',rewardItem.firstpay ,null);
         ---select * from  f_summary
         insert into br_brokerreward(brokerid, occurdate, moduleid, amount, paidamount, paydate ,initAmount )
         values ( rewardItem.Brokerid,rewardItem.Cleardate,15,rewardItem.Reward-rewardItem.firstpay ,rewardItem.firstpay ,v_payDate ,rewardItem.Reward-rewardItem.firstpay );
    end loop;

    ---佣金返款
    update br_r_systemstatus t set t.status=4;
    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=4;
    
    insert into op_globallog_all(id,operator,operatetime,operatetype, operatecontent,operateresult  ) 
    values (  seq_op_globallog.nextval,'dbfunc',sysdate,5012, '完成佣金返款:'||to_char(p_doDate,'yyyy-mm-dd'),1 );
    
    --如果是自动付佣金，便将付款日<=当日且待付>0的佣金付给会员；更新会员待付佣金表
    if (v_autopay = 'Y') then
        for brokerReward in ( select t.brokerid, t.amount, t.occurdate ,t1.firmid
                                from BR_Brokerreward t ,br_broker t1
                                where t.brokerid=t1.brokerid and t.paydate <= trunc(p_doDate) and t.amount > 0 and t.moduleid=15 
                             ) 
        loop
            v_fresult := fn_f_updatefunds(brokerReward.firmid,'15019',brokerReward.Amount,null);
            update BR_Brokerreward m set m.amount= 0,m.paidamount = m.paidamount + brokerReward.Amount
             where m.brokerid = brokerReward.Brokerid and m.occurdate = brokerReward.Occurdate and m.moduleid=15;
        end loop;
    end if;

    commit;

    return 1;
 exception
    when others then
      v_errorcode:=sqlcode;
      v_errormsg :=sqlerrm;
      rollback;
      insert into T_DBLog(err_date,name_proc,err_code,err_msg) values(sysdate,'fn_br_r_financereward',v_errorcode,v_errormsg);
      update br_r_systemstatus t set t.status=2;
      commit;
    return -100;
end;
/

