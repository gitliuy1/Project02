CREATE FUNCTION FN_T_getMaxSubString
(
    p_tableName            varchar2,  -- 表名
    p_columnName           varchar2,  -- 列名
    p_isNo                 number,    --找最大数字 1=是，其他=否
    p_like                 varchar2,  --列过滤条件
    p_likeType             varchar2,  --1=%p_like 2=p_like% 3=%p_like%
    p_dir                  number,    --截取放向 1=后，-1=前 ;0=不截取
    p_length               number    --长度 -1=不限制;
)
RETURN VARCHAR2
/****
 * 初始化交易系统
 * 返回值 1 成功;-100 其它错误
****/
as
   v_sql                varchar2(1000);
   v_like               varchar2(200);
   v_substr             varchar2(300);
   v_where              varchar2(1000);
   v_result             varchar2(300);
begin

   v_where:='';
   v_sql:=' select ''''||max( ';--返回字符串
   v_like:='';
   
   if (p_like is not null and  length(p_like) >0 ) then
     v_like:=p_like;
     if (p_likeType=1) then
       v_like:= p_columnName||' like ''%'||v_like||'''';
     elsif (p_likeType=2) then
       v_like:= p_columnName||' like '''||v_like||'%''';
     elsif (p_likeType=3) then
        v_like:= p_columnName||' like ''%'||v_like||'%''';
     else 
        return '';
     end if;
   end if;

   if (p_dir=1) then
     v_substr:=' substr('||p_columnName||',instr('||p_columnName||','||p_like||')+length('||p_like||') ) ';
   elsif (p_dir=2 ) then
     v_substr:=' substr('||p_columnName||',1 ,instr('||p_columnName||','||p_like||') ) ';
   else
     v_substr:='';
   end if;
   
   if (p_length>0) then
     v_substr:=' substr('||v_substr||',1 ,'||p_length||') ';
   else
     v_substr:=' substr('||v_substr||' ,-'||p_length||') ';
   end if;

   if (p_isNo=1) then
     v_sql:=v_sql||' to_number( '||v_substr||') ';--Enf to_number
     v_where:=' where regexp_instr( '|| v_substr|| ',''[1-9][0-9]?$'')=1  ';
     if (length(v_like)>1) then
       v_where:=v_where||' and '||v_like;
     end if;
   else
     if (length(v_like)>1) then
       v_where:=v_where||' where '||v_like;
     end if;
   end if;

   v_sql:=v_sql||' ) ';--Enf max

   v_sql:=v_sql||' from  '|| p_tableName ;


   execute immediate v_sql||v_where into v_result;


   return v_result;
end;
/

