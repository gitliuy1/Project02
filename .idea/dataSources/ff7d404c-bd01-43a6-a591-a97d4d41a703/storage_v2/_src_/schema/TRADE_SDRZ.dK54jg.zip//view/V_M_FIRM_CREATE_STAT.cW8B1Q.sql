CREATE VIEW V_M_FIRM_CREATE_STAT AS
  select
       trunc(createtime) createdate,        --开户日期
       count(1) cnt                         --开户数量
  from m_firm group by trunc(createtime)
/

