CREATE VIEW V_T_BR_FIRMREWARDDEAIL AS
  select t.firmid,t.commodityid,t.cleardate,0 rewardtype,t.brokerid
       ,(select bb.name from br_broker bb where bb.brokerid = t.brokerid ) brokername
       ,t.firstpay,t.secondpay,t.reward,t.marketreward,t.fee-t.marketreward-t.appendfee brokereachdivide,t.qty quantity ,0 trademoney ,t.brokerageid
       ,(select bba.name from br_brokerage bba where bba.brokerageid = t.brokerageid) brokeragename
  from br_r_firmComodityDayTrade t
/

