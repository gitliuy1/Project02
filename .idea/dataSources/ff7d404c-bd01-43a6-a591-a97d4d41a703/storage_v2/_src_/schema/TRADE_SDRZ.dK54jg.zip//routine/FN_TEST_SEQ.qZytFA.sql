CREATE function FN_TEST_SEQ  --返回值
return INTEGER
 as  --声明
seqNo INTEGER :=0;
addNo INTEGER :=0;
returnCode INTEGER :=0;
BEGIN
    --执行体
    returnCode:=1;
    
    select SEQ_MYDEMO.nextval into seqNo from dual; 
    addNo := seqNo+10;
    WHILE seqNo <= addNo  LOOP
      BEGIN
        select SEQ_MYDEMO.nextval into seqNo from dual;
      END;
      END LOOP;
      return(returnCode);
 exception
    when others then
       rollback;
        update f_systemstatus
           set status = 0,
               note = 'FN_TEST_SEQ 执行持仓、成交、委托序列时报错';
        commit;
        returnCode := -1000;
        return(returnCode);
END;
/

