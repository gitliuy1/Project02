CREATE function FN_T_D_SettleMatchOne_ZSSPlus3(p_TxfirmID    varchar2, --特许服务商交易商代号
                                                         p_CommodityID varchar2, --商品代码
                                                         p_a_orderno   t_delayorders.a_orderno%type)
  return number
/****
   * 指定特许服务商 商品交收申报配对
   * 返回值
   * 1 成功
   * -1 =买方成交数量出错   ; -2= 特许服务商资金不足  ;-3=交收持仓数量大于可交收持仓数量
   * -4 =交收抵顶数量大于可抵顶数量 ;-5 =做市商不存在  3300555
   * -11=买方持仓不足  ;     -12 =卖方持仓不足
   * -21=已被其他特许服务商审核 ; -22= 解冻意向仓单失败
   * -32= 卖方仓单不足
  ****/
 as
  v_version              varchar2(10) := '1.0.2.2';
  v_ret                  number(4);
  v_OrderTradeQty        number(10) := 0;
  v_TradeDate            date;
  --v_Balance              number(15, 2) := 0;
  v_UnfrozenFunds        number(15, 2);
  v_F_FrozenFunds        number(15, 2);
  v_Status               number(2);
  v_num                  number(10);
  --v_DelayNeedBill        number(2); --延期交收是否需要仓单，0：不需要； 1：需要；
  v_tradedAmount         number(10) := 0; --成交数量
  v_unCloseQty           number(10); --未平数量，用于中间计算
  v_NeutralMatchPriority number(2); --中立仓反向持仓是否优先撮合,0:不优先；1：优先
  v_bs_flag              t_delayorders.bs_flag%type;
  --v_A_OrderNo            t_delayorders.a_orderno%type;
  --v_A_TradeNo            t_trade.a_tradeno%type;
  v_t_holdqty            t_holdposition.holdqty%type;
  v_overdat              t_commodity.overdat%type;
  v_contractFactor       t_commodity.contractfactor%type;
  v_A_HoldNo             t_holdposition.a_holdno%type;
  v_marginAlgr           number(2);
  v_marginRate_b         number(10, 4);
  v_marginRate_s         number(10, 4);
  v_marginAssure_b       number(10, 4);
  v_marginAssure_s       number(10, 4);
  v_Margin               number(15, 2) := 0; --应收保证金
  v_Assure               number(15, 2) := 0; --应收担保金
  v_tradeno              t_holdposition.a_tradeno%type;
  v_sql                  varchar2(4000);
  v_matchId              varchar2(32);
  v_b_firmid             varchar2(32);
  v_s_firmid             varchar2(32);
  v_breedid              varchar2(12);
  v_billQty              number(12) := 0;
  v_A_Funds              number(15, 2) := 0; --可用资金
  --v_billid               bi_stock.stockid%type;
  v_marginsetsql         varchar2(200); --持仓天数对应保证金阶段查询语句
  v_getmarginsql         varchar2(2000); --持仓天数对应保证金阶段设置查询语句
  v_ztxFirm              varchar2(32); -- 总特许服务商 新建2017-3-30 11:02:09 hanqr
  v_ztxCustomer          varchar2(32); -- 总特许服务商对应交易员 新建2017-3-30 11:02:09 hanqr
  --v_clearprice           t_quotation.price%type;
  v_noneTxFirmId         varchar2(32):='-1'; -- 所有特许服务商,未指定特许服务商
  v_orderTxFirmId        varchar2(32);       -- 申报委托记录的特许服务商
  v_goodsId              number(10);         --意向货种
  v_placeId              number(10);         --意向交收地
  v_isDeailedBill        number(2):=0;       --卖申报时是否有意向仓单（有意向仓单即已冻结仓单）yuansr 2017 07 07
  v_order_bs_flag        t_delayorders.bs_flag%type;         
begin

  --将原有63300555修改为从t_tx_ztxFirm表里获取到的总特许服务商 2017-3-30 11:03:28 hanqr
  select t.txfirmid into v_ztxFirm from t_tx_txfirm t where t.txfirmid=p_TxfirmID for update ; 
  --将原有6330055500修改为从t_customer表里获取到的总特许服务商对应的交易员 2017-3-30 11:03:28 hanqr
  select t.customerid into v_ztxCustomer from t_customer t where t.firmid= v_ztxFirm ;
  --获取申报委托记录的特许服务商 并加锁保证数据独立
  select t.txfirmid,t.bs_flag into v_orderTxFirmId,v_order_bs_flag from T_DelayOrders t  where  t.a_orderno=p_a_orderno for update;
  
  if (v_orderTxFirmId = v_ztxFirm) then
    v_ztxFirm := v_ztxFirm;--无用代码，仅用于保持if 结构
  elsif (v_orderTxFirmId = v_noneTxFirmId) then --将 未指定特许服务商 更新为审核特许服务商
    update T_DelayOrders t set t.txfirmid=v_ztxFirm where t.txfirmid=v_noneTxFirmId and t.a_orderno=p_a_orderno;
  else
    return -21;---已被其他特许服务商审核
  end if;

  --卖申报时，查看是否有指定意向仓单 yuansr 2017 07 07
  if (v_order_bs_flag=2) then
     select count(1) into v_num from T_D_PurposeBill t where t.a_orderno= p_a_orderno;
     if (v_num>0) then --有指定意向仓单
       v_isDeailedBill:=1;
     end if;
  end if;

  --检查做市商是否存在
  select count(*) into v_num from m_firm where firmid= v_ztxFirm;
  if v_num = 0 then
     return -5;
  end if;
  --1、如果交收商品表中没有此商品则插入
  select count(*) into v_num from T_SettleCommodity where CommodityID = p_CommodityID;
  if (v_num = 0) then
    select TradeDate into v_TradeDate from T_SystemStatus;
    insert into T_SettleCommodity select v_TradeDate, a.* from T_Commodity a where a.CommodityID = p_CommodityID;
  end if;
  --获取商品合约因子（用于计算货款相关项和仓单手数）和到期天数设置（用于新仓初始到期天数）
  select overdat,contractFactor into v_overdat,v_contractFactor from t_commodity where commodityid=p_CommodityID;
  --获取市场设置
  --select DelayNeedBill into v_DelayNeedBill from T_A_Market;--延期交收是否需要仓单0：不需要 1：需要
  select NEUTRALMATCHPriority into v_NeutralMatchPriority from t_a_market; --中立仓撮合优先级 0 默认，1中立仓优先
  --2、根据交收委托单号查询交收委托数据 ,HoldType->1：正常持仓；2 中立仓持仓 
  for delayOrder in (select A_OrderNo, CommodityID, CustomerID, T_DelayOrders.BS_Flag BS_Flag, (Quantity - TradeQty) NotTradeQty
                            , Price, FrozenFunds, UnfrozenFunds, Quantity, FirmID, delaymoney, a_holdno, aholdflag
                       from T_DelayOrders  , 
                            (select distinct (t.FirmID) as FID, 1 as OrderType,  BS_Flag from T_HoldPosition t 
                              where t.HoldType = decode(v_NeutralMatchPriority, 1, 2, 1) and t.CommodityID = p_CommodityID
                            ) hp
                      where DelayOrderType = 1 and T_DelayOrders.BS_Flag=hp.BS_Flag and Status in (1, 2) 
                        and CommodityID = p_CommodityID and firmid = hp.FID(+) 
						            and txfirmid=v_ztxFirm	and A_OrderNo = p_a_orderno ---由指定特许服务商审核
                        for update of A_OrderNo)
  loop
      v_unCloseQty    := delayOrder.NotTradeQty;
      v_tradedAmount  := v_unCloseQty;
      v_Status        := 3;
      v_UnfrozenFunds := delayOrder.FrozenFunds -delayOrder.UnfrozenFunds;

      if delayOrder.bs_flag = 1 then
        v_bs_flag := 2;
        v_b_firmid:=delayOrder.firmid;
        v_s_firmid:=v_ztxFirm;

        --start add by lyf 20160830 判断该交收申请人是否有可用仓单   modify by lyf 20160919 增加持仓数量的检查
        select breedid into v_breedid from t_commodity where commodityid=p_CommodityID;
        begin
          select nvl((a.quantity - b.frozen), 0) into v_billQty ---可用仓单数量
            from (select sum(quantity) quantity, breedid, ownerfirm from bi_stock s 
                   where not exists ( select stockid from BI_StockOperation so  where so.stockID = s.stockid)
                     and s.stockstatus = 1 and s.quantity<=delayOrder.NotTradeQty 
                   group by breedid, ownerfirm
                 ) a,
                 (select nvl(sum(frozen), 0) frozen, firmid, breedid from br_billQtyFrozen  group by breedid, firmid) b
           where a.breedid = b.breedid  and b.firmid = a.ownerfirm(+) and ownerfirm = v_s_firmid and a.breedid = v_breedid;
        
          if v_billQty <= 0 then
              rollback;
              return -32;  --仓单数量不足
          elsif v_billQty-delayOrder.NotTradeQty*v_contractFactor<0 then
              rollback;
              return -32;  --仓单数量不足
          end if;
        exception
        when NO_DATA_FOUND then
             begin
              select nvl(sum(quantity),0) into v_billQty from bi_stock s
              where not exists (select stockid from BI_StockOperation so where so.stockID = s.stockid)
              and s.stockstatus = 1 and s.breedid = v_breedid and s.ownerfirm = v_s_firmid and s.quantity<=delayOrder.NotTradeQty ;
              if v_billQty <= 0 then
                  rollback;
                  return -32;  --仓单数量不足
              end if;
            exception
            when NO_DATA_FOUND then
                 rollback;
                 return -32;  --仓单数量不足
            end;
        end;
        --end
      else
        v_bs_flag := 1;
        v_b_firmid:=v_ztxFirm;
        v_s_firmid:=delayOrder.firmid;
      end if;
      
      --计算可用资金，并锁住财务资金 add by lyf 20160831
      v_A_Funds := FN_F_GetRealFunds(v_ztxFirm, 1);
      --start  add by lyf 20160810 增加是否是指定持仓单号交收的，如果是指定持仓单号，则新生成的特许服务商的持仓的合同号为指定持仓单号的
      if delayOrder.aholdflag=2 then
         /*for th in (select * from t_holdposition where commodityid=p_CommodityID and firmid=delayOrder.firmid and holdqty>0
                       and bs_flag=delayOrder.bs_flag order by a_holdno)*/ 
         ----使用委托时冻结的持仓,保证委托冻结、成交、交收使用相同的持仓 
         for th in (select t1.* ,( nvl(t2.qty,0)-nvl(t2.unfrozenqty，0) ) holdqtyFrozen
                      from t_holdposition     t1      ,T_S_OrderFrozenHold t2
                     where commodityid=p_CommodityID and firmid=delayOrder.firmid and holdqty>0
                       and t1.a_holdno=t2.a_holdno   and t2.a_orderno=delayOrder.a_Orderno
                       and t1.bs_flag=delayOrder.bs_flag order by t1.a_holdno)
         loop
            v_tradeno:=th.A_HoldNo;
            --v_t_holdqty:=th.holdqtyFrozen-v_tradedamount;
            v_t_holdqty:=th.holdqtyFrozen;--根据委托时冻结处理 yuansr 2017 07 13
            --根据持仓日期 获取对应阶段的交易保证金算法设置,计算保证金 yuansr 2016 10 08
            select case when settleDays1 is null 
                        then 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s'
                        when settleDays1 is not null and th.overdat<=settleDays1 and (settleDays2 is null or th.overdat>settleDays2)
                        then 'marginitem1 ,marginitem1_s ,marginitemassure1 ,marginitemassure1_s'
                        when settleDays2 is not null and th.overdat<=settleDays2 and (settleDays3 is null or th.overdat>settleDays3)
                        then 'marginitem2 ,marginitem2_s ,marginitemassure2 ,marginitemassure2_s'
                        when settleDays3 is not null and th.overdat<=settleDays3 and (settleDays4 is null or th.overdat>settleDays4)
                        then 'marginitem3 ,marginitem3_s ,marginitemassure3 ,marginitemassure3_s'
                        when settleDays4 is not null and th.overdat<=settleDays4 and (settleDays5 is null or th.overdat>settleDays5)
                        then 'marginitem4 ,marginitem4_s ,marginitemassure4 ,marginitemassure4_s'
                        when settleDays5 is not null and th.overdat<=settleDays5
                        then 'marginitem5 ,marginitem5_s ,marginitemassure5 ,marginitemassure5_s'
                   else 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s' end
              into v_marginsetsql
              from t_commodity
             where commodityid=p_CommodityID ;
            v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from t_commodity where commodityid='''||p_CommodityID||'''' ;
            --dbms_output.put_line(v_getmarginsql);
            execute immediate v_getmarginsql into v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s;
            --获取特户的交易保证金，保证金算法
            begin
                v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from T_A_FirmMargin where  FirmID='''||v_ztxFirm
                              ||''' and commodityid='''||p_CommodityID||'''' ;---yuansr 2016 10 08
                execute immediate v_getmarginsql into v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s;
            exception
                when NO_DATA_FOUND then
                null;
            end;

            --if v_t_holdqty>=0 then
            if v_t_holdqty>=0 then
               --v_t_holdqty:=v_tradedamount;
               --1 insert 生成做市商持仓明细用来和申报的客户交收 modify by lyf 20160801 
               --修改特许服务商平移持仓的持仓价格改为申报成交价 modify by yangq 2017.03.29 添加调期交收的标志
               --新仓持仓价取申报交易商对应持仓的持仓订立价 yuansr 2017.06.30 
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
               insert into t_holdposition( a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime
                                           ,holdmargin ,firmid  ,gageqty , holdassure, floatingloss, holdtype, atcleardate, deadline
                                           ,remainday, overdat  ,sa_orderno ,holdkind )
               values ( v_A_HoldNo, v_tradeno, v_ztxCustomer, p_CommodityID, v_bs_flag, th.price, v_t_holdqty ,v_t_holdqty
                      	,sysdate, 0, v_ztxFirm, th.gageqty, 0, 0, th.holdtype, trunc(sysdate), th.deadline, th.remainday, v_overdat
                        ,p_a_orderno,2);
               --、添加冻结持仓记录(用于交收)，更新交易客户持仓明细表 冻结数量 add by yuansr 2016 10 20 
               insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty )
               values ( p_a_orderno  ,v_A_HoldNo    ,v_bs_flag         ,v_t_holdqty   ,v_t_holdqty            ,0      );
               --2 insert 生成新的持仓明细，买卖方向和交收的客户一样，并且合约到期天数为90   modify by lyf 20160801 
               --修改特许服务商新生成的持仓的价格和对手价格一样  modify by lyf 20160809 
               --到期日和开仓日期也都改为和老仓一样的 modify by lyf 20160810 
               --新生成的合同号去委托的持仓单号
               -- start   计算保证金  add by lyf 20160809 增加特许服务商调期交收的时候收取保证金，这个保证金收取是收取的交易保证金
               v_Margin := FN_T_ComputeMarginByArgs( delayOrder.bs_flag,v_t_holdqty,th.price,v_contractFactor,v_marginAlgr
                                                     ,v_marginRate_b ,v_marginRate_s);
               if(v_Margin < 0) then
                  Raise_application_error(-20040, 'computeMargin error');
               end if;
               --计算担保金
               v_Assure := FN_T_ComputeAssureByArgs( delayOrder.bs_flag,v_t_holdqty,th.price,v_contractFactor,v_marginAlgr
                                                     ,v_marginAssure_b,v_marginAssure_s );
               if(v_Assure < 0) then
                  Raise_application_error(-20041, 'computeAssure error');
               end if;
               --保证金应加上担保金
               v_Margin := v_Margin + v_Assure;	
               -- end
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
               --modify by yangq 2017.03.29 添加调期交收的标志
               insert into t_holdposition ( a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime
                                            ,holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline
                                            ,remainday, overdat,sa_orderno,holdkind )
               values ( v_A_HoldNo, v_tradeno, v_ztxCustomer, p_CommodityID, delayOrder.bs_flag, th.price, v_t_holdqty, v_t_holdqty
                        ,th.holdtime, v_Margin, v_ztxFirm, th.gageqty, v_Assure, 0, th.holdtype, th.atcleardate, th.deadline
                        ,th.remainday,th.overdat,'',2);
               --1更新交易客户持仓合计表 --新仓保证金为0   yuansr 2017 04 21
               select count(*) into v_num from t_customerholdsum 
                where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=v_bs_flag;
               if v_num>0 then
                  update T_CustomerHoldSum
                     set holdQty = holdQty + v_t_holdqty, holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor
                         ,frozenqty=v_t_holdqty
                         ,evenprice = ( holdFunds + th.price*v_t_holdqty*v_contractFactor )
                                      /( (holdQty + v_t_holdqty)*v_contractFactor )
                   where CustomerID = v_ztxCustomer and CommodityID = p_CommodityID and bs_flag = v_bs_flag;
               else
                  insert into T_CustomerHoldSum ( CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice
                                                	,FrozenQty,HoldMargin,HoldAssure,FirmID)
                  values ( v_ztxCustomer, p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0
                           ,th.price,v_t_holdqty,0,0,v_ztxFirm);
               end if;
               --2 更新交易商持仓合计表 --新仓保证金为0   yuansr 2017 04 21
               select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=v_bs_flag;
               if v_num>0 then
                  update T_FirmHoldSum 
                     set holdQty = holdQty + v_t_holdqty, holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                         evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)
                                     /((holdQty + v_t_holdqty )*v_contractFactor)
                   where Firmid = v_ztxFirm  and CommodityID = p_CommodityID and bs_flag = v_bs_flag;	
               else
                  insert into T_FirmHoldSum (FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
                  values( v_ztxFirm, p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0
                          ,th.price, 0,0 );
               end if;
               --3 更新交易客户持仓合计表 --特许服务商旧仓保证金按特许服务商持仓明细记录的保证金更新  yuansr 2017 04 21
               select count(*) into v_num from t_customerholdsum 
                where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=delayOrder.bs_flag;
               if v_num>0 then
                  update T_CustomerHoldSum
                     set holdQty = holdQty + v_t_holdqty,holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor
                         ,HoldMargin = HoldMargin + v_Margin ,HoldAssure = HoldAssure + v_Assure
                         ,evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                  where CustomerID = v_ztxCustomer  and CommodityID = p_CommodityID and bs_flag = delayOrder.bs_flag;
               else
                  insert into T_CustomerHoldSum ( CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice
                                                 ,FrozenQty ,HoldMargin ,HoldAssure,FirmID )
                  values ( v_ztxCustomer, p_CommodityID, delayOrder.bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0
                           ,th.price,0 ,v_Margin,v_Assure,v_ztxFirm );
               end if;
               --4 更新交易商持仓合计表 --特许服务商旧仓保证金按特许服务商持仓明细记录的保证金更新  yuansr 2017 04 21
               select count(*) into v_num from T_FirmHoldSum 
                where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=delayOrder.bs_flag;
               if v_num>0 then
                  update T_FirmHoldSum
                     set holdQty = holdQty + v_t_holdqty, holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor
                         ,HoldMargin = HoldMargin + v_Margin,HoldAssure = HoldAssure + v_Assure
                         ,evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                   where Firmid = v_ztxFirm and CommodityID = p_CommodityID and bs_flag = delayOrder.bs_flag;
               else
                  insert into T_FirmHoldSum (FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
                  values ( v_ztxFirm, p_CommodityID, delayOrder.bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0
                           ,th.price, v_Margin, v_Assure);
               end if;
               update T_Firm set runtimemargin = runtimemargin + v_Margin,RuntimeAssure = RuntimeAssure + v_Assure 
                where Firmid = v_ztxFirm;
               --更新冻结资金，包括个人部分的保证金
               if (v_A_Funds < v_Margin-v_Assure) then
                  rollback;
                   return - 2; --资金余额不足
               end if;	
               v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_ztxFirm,v_Margin-v_Assure,'15');
            end if;
         end loop;
      else
         v_sql:=' and a_holdno='''||delayOrder.a_holdno||'''';
          --dbms_output.put_line( 'v_sql'||v_sql );
         /*for th in ( select * from t_holdposition where commodityid=p_CommodityID and firmid=delayOrder.firmid and holdqty+frozenqty>0 
                     and bs_flag=delayOrder.bs_flag and a_holdno=delayOrder.a_holdno) */
         ----使用委托时冻结的持仓,保证委托冻结、成交、交收使用相同的持仓 yuansr 2017 07 13
         for th in (select t1.* ,( nvl(t2.qty,0)-nvl(t2.unfrozenqty，0) ) holdqtyFrozen
                      from t_holdposition     t1      ,T_S_OrderFrozenHold t2
                     where commodityid=p_CommodityID and firmid=delayOrder.firmid and holdqty>0
                       and t1.a_holdno=t2.a_holdno   and t2.a_orderno=delayOrder.a_Orderno
                       and t1.bs_flag=delayOrder.bs_flag and t1.a_holdno=delayOrder.a_holdno)
         loop  --add by lyf 20160816 指定仓单时候查询数量的时候加上冻结的th.frozenqty
            v_tradeno:=th.A_HoldNo;
            v_t_holdqty:=th.holdqtyFrozen;--根据委托时冻结处理 yuansr 2017 07 13
            --v_t_holdqty:=th.holdqtyFrozen+th.frozenqty-v_tradedamount;  --add by lyf 20160816 指定仓单时候查询数量的时候加上冻结的th.frozenqty
            --dbms_output.put_line( 'v_t_holdqty'||v_t_holdqty );
            --根据持仓日期 获取对应阶段的交易保证金算法设置,计算保证金 yuansr 2016 10 08
            select case when settleDays1 is null 
                        then 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s'
                        when settleDays2 is not null and th.overdat<=settleDays2 and (settleDays3 is null or th.overdat>settleDays3)
                        then 'marginitem1 ,marginitem1_s ,marginitemassure1 ,marginitemassure1_s'
                        when settleDays3 is not null and th.overdat<=settleDays3 and (settleDays4 is null or th.overdat>settleDays4)
                        then 'marginitem2 ,marginitem2_s ,marginitemassure2 ,marginitemassure2_s'
                        when settleDays4 is not null and th.overdat<=settleDays4 and (settleDays5 is null or th.overdat>settleDays5)
                        then 'marginitem3 ,marginitem3_s ,marginitemassure3 ,marginitemassure3_s'
                        when settleDays5 is not null and th.overdat<=settleDays5
                        then 'marginitem4 ,marginitem4_s ,marginitemassure4 ,marginitemassure4_s'
                   else 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s' end
              into v_marginsetsql
              from t_commodity
             where commodityid=p_CommodityID ;
            v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from t_commodity where  commodityid='''||p_CommodityID||'''' ;
            --dbms_output.put_line(v_getmarginsql);
            execute immediate v_getmarginsql into v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s;
            --获取特户的交易保证金，保证金算法
            begin
                v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from T_A_FirmMargin where FirmID='''||v_ztxFirm||''' and commodityid='''||p_CommodityID||'''' ;---yuansr 2016 10 08
                execute immediate v_getmarginsql into v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s;
            exception
                when NO_DATA_FOUND then
                null;
            end;

            if v_t_holdqty>=0 then
               --v_t_holdqty:=v_tradedamount;
               --1 insert 生成做市商持仓明细用来和申报的客户交收 modify by lyf 20160801 修改特许服务商平移持仓的持仓价格改为申报成交价
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
               --modify by yangq 2017.03.29 添加调期交收的标志
               insert into t_holdposition
                (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat,sa_orderno,holdkind )
               values
                (v_A_HoldNo, v_tradeno, v_ztxCustomer, p_CommodityID, v_bs_flag, th.price, v_t_holdqty, v_t_holdqty, sysdate, 0, v_ztxFirm, th.gageqty, 0, 0, th.holdtype, trunc(sysdate), th.deadline, th.remainday, v_overdat,p_a_orderno,2);
                
               --、添加冻结持仓记录，更新交易客户持仓明细表 冻结数量 add by yuansr 2016 10 20
               insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty )
               values ( p_a_orderno  ,v_A_HoldNo    ,v_bs_flag         ,v_t_holdqty   ,v_t_holdqty            ,0      );

               --2 insert 生成新的持仓明细，买卖方向和交收的客户一样，并且合约到期天数为90   modify by lyf 20160801 修改特许服务商新生成的持仓的价格和对手价格一样  modify by lyf 20160809 到期日和开仓日期也都改为和老仓一样的 modify by lyf 20160810 新生成的合同号去委托的持仓单号
                 -- start   计算保证金  add by lyf 20160809 增加特许服务商调期交收的时候收取保证金，这个保证金收取是收取的交易保证金
                  v_Margin := FN_T_ComputeMarginByArgs(delayOrder.bs_flag,v_t_holdqty,th.price,v_contractFactor,v_marginAlgr,v_marginRate_b,v_marginRate_s);
                  if(v_Margin < 0) then
                      Raise_application_error(-20040, 'computeMargin error');
                  end if;
                  --计算担保金
                  v_Assure := FN_T_ComputeAssureByArgs(delayOrder.bs_flag,v_t_holdqty,th.price,v_contractFactor,v_marginAlgr,v_marginAssure_b,v_marginAssure_s);
                  if(v_Assure < 0) then
                      Raise_application_error(-20041, 'computeAssure error');
                  end if;
                  --保证金应加上担保金
                  v_Margin := v_Margin + v_Assure;
                 -- end
                select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
                --modify by yangq 2017.03.29 添加调期交收的标志
                insert into t_holdposition
                  (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat,sa_orderno,holdkind )
                 values
                  (v_A_HoldNo, v_tradeno, v_ztxCustomer, p_CommodityID, delayOrder.bs_flag, th.price, v_t_holdqty, v_t_holdqty, th.holdtime, v_Margin, v_ztxFirm, th.gageqty, v_Assure, 0, th.holdtype, th.atcleardate, th.deadline, th.remainday,th.overdat,'',2);
               
                --1更新交易客户持仓合计表 ---新仓保证金为0 不更新  yuansr 2017 04 21
                  select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=v_bs_flag;
                  if v_num>0 then
                     update T_CustomerHoldSum
                      set holdQty = holdQty + v_t_holdqty,
                      holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                      frozenqty=v_t_holdqty,
                      evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                      where CustomerID = v_ztxCustomer
                      and CommodityID = p_CommodityID
                      and bs_flag = v_bs_flag;
                  else
                    insert into T_CustomerHoldSum
                      (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                    values
                      (v_ztxCustomer, p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price,v_t_holdqty,0,0,v_ztxFirm);
                  end if;
                  --2更新交易商持仓合计表 新仓保证金为0 不更新  yuansr 2017 04 21
                   select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=v_bs_flag;
                  if v_num>0 then
                     update T_FirmHoldSum
                      set holdQty = holdQty + v_t_holdqty,
                      holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                      evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                      where Firmid = v_ztxFirm
                      and CommodityID = p_CommodityID
                      and bs_flag = v_bs_flag;
                  else
                      insert into T_FirmHoldSum
                      (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                    values
                      (v_ztxFirm, p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price, 0,0);
                  end if;
                   --3 更新交易客户持仓合计表 ---特许服务商旧仓保证金按特许服务商持仓明细记录的保证金更新  yuansr 2017 04 21
                  select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=delayOrder.bs_flag;
                  if v_num>0 then
                     update T_CustomerHoldSum
                      set holdQty = holdQty + v_t_holdqty,
                      holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                      HoldMargin = HoldMargin + v_Margin,
                      HoldAssure = HoldAssure + v_Assure,
                      evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                      where CustomerID = v_ztxCustomer
                      and CommodityID = p_CommodityID
                      and bs_flag = delayOrder.bs_flag;
                  else
                    insert into T_CustomerHoldSum
                      (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                    values
                      (v_ztxCustomer, p_CommodityID, delayOrder.bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price,0,v_Margin,v_Assure,v_ztxFirm);
                  end if;
                  --4 更新交易商持仓合计表 ---特许服务商旧仓保证金按特许服务商持仓明细记录的保证金更新  yuansr 2017 04 21
                   select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid=v_ztxFirm and bs_flag=delayOrder.bs_flag;
                  if v_num>0 then
                     update T_FirmHoldSum
                      set holdQty = holdQty + v_t_holdqty,
                      holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                      HoldMargin = HoldMargin + v_Margin,
                      HoldAssure = HoldAssure + v_Assure,
                      evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                      where Firmid = v_ztxFirm
                      and CommodityID = p_CommodityID
                      and bs_flag = delayOrder.bs_flag;
                  else
                      insert into T_FirmHoldSum
                      (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                    values
                      (v_ztxFirm, p_CommodityID, delayOrder.bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price, v_Margin, v_Assure);
                  end if;
                   update T_Firm set runtimemargin = runtimemargin + v_Margin,RuntimeAssure = RuntimeAssure + v_Assure where Firmid = v_ztxFirm;
                      --更新冻结资金，包括个人部分的保证金
                  if (v_A_Funds < v_Margin-v_Assure) then
                    rollback;
                    return - 2; --资金余额不足
                  end if;
                 v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_ztxFirm,v_Margin-v_Assure,'15');
            end if;
          end loop;
      end if;
    --end

    v_tradedAmount  := v_unCloseQty;

    v_ret := FN_T_D_SettleOne_ZSS( delayOrder.CommodityID, delayOrder.delaymoney, v_bs_flag, v_ztxCustomer
                                   ,v_tradedAmount, 0, p_a_orderno, -2,  2);

    if (v_ret < 0) then
      rollback;
      return v_ret;
    end if;
    v_unCloseQty := v_unCloseQty - v_tradedAmount;
    --exit when v_unCloseQty = 0;
    v_OrderTradeQty := delayOrder.NotTradeQty - v_unCloseQty;
    --dbms_output.put_line('-----v_OrderTradeQty------'||v_OrderTradeQty);
    if (v_unCloseQty = 0) then
      --全部成交
      v_Status        := 3;
      v_UnfrozenFunds := delayOrder.FrozenFunds - delayOrder.UnfrozenFunds;
    elsif (v_unCloseQty > 0 and v_unCloseQty < delayOrder.NotTradeQty) then
      --部分成交
      v_Status        := 2;
      v_UnfrozenFunds := delayOrder.FrozenFunds * v_OrderTradeQty / delayOrder.Quantity;
    elsif (v_unCloseQty = delayOrder.NotTradeQty) then
      --无卖方配对记录，成功返回
      return 1;
    else
      --出错回滚，要交收数量为负数了
      rollback;
      return - 1;
    end if;
    update T_DelayOrders
       set Status   = v_Status, TradeQty = TradeQty + v_OrderTradeQty , UnfrozenFunds = UnfrozenFunds + v_UnfrozenFunds
     where A_OrderNo = delayOrder.A_OrderNo;
    --更新冻结资金
    -- dbms_output.put_line('-----v_UnfrozenFunds 1  '||delayOrder.FirmID||'  ----  '||v_UnfrozenFunds);
    v_F_FrozenFunds := FN_F_UpdateFrozenFunds(delayOrder.FirmID, -v_UnfrozenFunds, '15');
    --  dbms_output.put_line('-----v_UnfrozenFunds   '||delayOrder.FirmID||'  ----  '||v_UnfrozenFunds);

    --买方持仓交收，涉及持仓明细，持仓合计，资金
    v_ret := FN_T_D_SettleOne_ZSS( delayOrder.CommodityID, delayOrder.delaymoney,  delayOrder.BS_Flag,  delayOrder.CustomerID
                                   ,v_OrderTradeQty, 0, p_a_orderno, delayOrder.a_holdno, delayOrder.aholdflag );
    if (v_ret < 0) then
      rollback;
      return v_ret;
    else
      select seq_T_SettleMatch.nextval into v_matchId from dual;
      v_matchId := 'TQ_' || v_matchId;
      select TradeDate into v_TradeDate from T_SystemStatus;
      v_ret:=FN_T_SettleMatch_ZSS(p_CommodityID,v_OrderTradeQty,0,1,v_b_firmid,v_s_firmid,to_char(v_TradeDate,'yyyy-mm-dd'),v_matchId,p_a_orderno);
      if (v_ret < 0) then
        rollback;
        return v_ret-10;
      else
        ---判断 当申报方卖仓单方，是否已（冻结记录交收）指定意向仓单——有则使用意向仓单yuansr 2017 07 07
        if  v_order_bs_flag=2 and v_isDeailedBill=1   then
            for billItem in ( select t1.a_orderno ,t1.stockid ,t2.quantity  from T_D_PurposeBill t1 ,bi_stock t2
                               where t1.stockid=t2.stockid and t1.a_orderno=delayOrder.a_Orderno for update) 
            loop
                v_ret:= fn_bi_unfrozenbill(15,billItem.Stockid);
                if (v_ret < 0) then
                  rollback;
                  return -22;---解冻意向仓单失败
                end if;
                insert into t_billfrozen (id, operation, billid, operationtype, modifytime) 
                values (SEQ_T_BILLFROZEN.NEXTVAL, v_matchId,billItem.Stockid, 2, sysdate);
                --更改状态为 成交状态
                update T_D_PurposeBill t set t.status=2 where t.stockid=billItem.Stockid and t.a_orderno=billItem.a_orderno;
            end loop;
        else ---无意向仓单 按原有处理方式进行处理 yuansr 2017 07 07
            -- 根据委托单号查询意向货种和意向交收地，传进冻结仓单存储，用于配对仓单 2017-7-6 hanqr
            select  goodsid,placeid into v_goodsId,v_placeId from T_DelayOrders  where a_orderno = p_a_orderno;
            -- add by lyf 20160919 配对成功后要冻结仓单
            v_ret:= FN_BI_UnusedStocks(p_CommodityID,v_s_firmid,v_OrderTradeQty*v_contractFactor,v_matchId,v_goodsId,v_placeId);
            if (v_ret < 0) then
              rollback;
              return v_ret;
            end if;
        end if;

      end if;
    end if;
  end loop;

  return 1;

end;
/

