CREATE function FN_F_B_INOUTMONEY
(
  p_bankID varchar2,      --银行编号
  p_firmID varchar2,      --交易商代码
  p_amount number,        --发生额
  p_remark varchar2,      --备注
  p_type varchar2,         --发起方（M:市场  B:银行）
  p_funID varchar2 ,       --银行流水号
  p_inouttype number ,   --出入金类型(0：入金  1：出金)
  p_queueInfoId number    --出入金队列ID
) return number
is
  v_reNum number(10):=0;           -- 返回值 大于0 流水号   小于0 错误码
  v_actionid varchar2(100);      -- 出入金流水号
  v_dicIN varchar(8);            --入金摘要
  v_dicOut varchar(8);            --出金摘要
  v_dic varchar(8);            --摘要
  v_dicFee varchar(8);           --手续费摘要
  v_oprCode varchar(8);          --银行科目
  v_tradeFee number(15,2) default 0;       --手续费
  v_note varchar2(100); --错误信息
begin
  if(p_inouttype=0) then--入金
      v_reNum:=fn_f_b_inmoney(p_bankID,p_firmID,p_amount,p_remark,p_type);
  else    --出金
      v_reNum:=fn_f_b_outmoney(p_bankID,p_firmID,p_amount,p_remark,p_type,p_funID);
  end if;
  --修改出入金信息队列状态
  update f_b_queueinfo set status=1 where id= p_queueInfoId;
  if(v_reNum<0) then --出入金不成功，补失败流水
        if(v_reNum=-1) then v_note:='银行不存在';
        elsif(v_reNum=-2) then v_note:='非交易日';
        elsif(v_reNum=-3) then v_note:='非交易时间';
        elsif(v_reNum=-4) then v_note:='交易商不存在';
        elsif(v_reNum=-5) then v_note:='交易商不可用';
        elsif(v_reNum=-6) then v_note:='交易商未签约';
        elsif(v_reNum=-7) then v_note:='超过单笔最大';
        elsif(v_reNum=-8) then v_note:='超过每日累计最大';
        elsif(v_reNum=-9) then v_note:='超过每日累计出金次数';
        elsif(v_reNum=-10) then v_note:='余额不足';
        elsif(v_reNum=-11) then v_note:='银行流水号已存在';
        end if;
        select SEQ_F_B_ACTION.nextval into v_actionid from dual;
        select value into v_dicIN from f_b_dictionary where name = 'insummary';
        select value into v_dicOut from f_b_dictionary where name = 'outsummary';
        select value into v_dicFee from f_b_dictionary where name = 'feesummary';
        begin
            select value into v_oprCode from f_b_dictionary where type=1 and bankid=p_bankid;
        exception when NO_DATA_FOUND then
            v_reNum := -1;
        return v_reNum;
        end;
        if(p_inouttype=0) then
          v_dic:=v_dicIN;
        else
          v_dic:=v_dicOut;
        end if;
        insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
        values(SEQ_F_B_CAPITALINFO.nextval, p_firmid, null, p_bankid, v_oprCode, p_firmid, p_inouttype, p_amount, v_dic, sysdate, null, 1, p_remark||v_note, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);

        insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
        values(SEQ_F_B_CAPITALINFO.nextval, p_firmid, null, p_bankid, p_firmid, 'Market', 2, v_tradeFee, v_dicFee, sysdate, null, 1, p_remark||v_note, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);
  else
    return v_reNum;
  end if;
  return v_reNum;
end;
/

