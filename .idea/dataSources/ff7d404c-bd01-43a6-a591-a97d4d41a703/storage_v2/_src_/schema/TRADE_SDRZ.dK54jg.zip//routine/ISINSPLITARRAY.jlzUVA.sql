CREATE FUNCTION IsInSplitArray( keyValues    varchar2
                                           ,arrayValues varchar2
                                           ,delimiter   varchar2
)RETURN number
  as
  v_length       number(10);
  v_start        number(10):=1; 
  v_end          number(10):=0;
BEGIN
  v_length:=lengthb(regexp_replace(arrayValues||delimiter,'[^'||delimiter||']',null));
  for v_indexNo in 1..v_length ---按序处理，录入顺序，即字符串顺序
  loop
    if (v_indexNo>1) then
       v_start    :=instr(arrayValues, ',', 1, v_indexNo-1)+1; 
    end if;
    v_end      :=instr(arrayValues||',', ',', 1, v_indexNo);
    if (substr(arrayValues,v_start,v_end-v_start)=keyValues) then
       return 1;
    end if;
  end loop;
  RETURN -1;
END;
/

