CREATE function FN_T_ComputeMarginPlus(
    p_FirmID               varchar2,      --交易商代号
    p_CommodityID          varchar2,      --商品代号
    p_bs_flag              number,        --买卖标识
    p_overdat              number,        --持仓到期天数，为空表示今日新增持仓
    p_quantity             number,        --数量
    p_price                number         --价格
) return number
/****
 * 计算保证金
 * 返回值 成功返回保证金;-1 计算所需数据不全;-100 其它错误
****/
as
   v_version              varchar2(10):='1.0.0.1';
   v_marginRate_b         number(10,4);               ---买保证金系数
   v_marginRate_s         number(10,4);               ---卖保证金系数
   v_marginAlgr           number(2);                  ---保证金算法
   v_contractFactor       number(12,2);               ---合约因子
   v_margin               number(15,2) default 0;     ---保证金
   v_marginsetsql         varchar2(200);            --持仓天数对应保证金阶段查询语句
   v_getmarginsql         varchar2(2000);           ---持仓天数对应保证金阶段设置查询语句
begin
  
   --根据持仓日期 获取对应阶段的交易保证金算法设置,计算保证金 
    select case when settleDays1 is null or p_overdat is null 
                then 'marginRate_b,marginRate_s'
                when settleDays1 is not null and p_overdat<=settleDays1 and (settleDays2 is null or p_overdat>settleDays2)
                then 'marginitem1 ,marginitem1_s'
                when settleDays2 is not null and p_overdat<=settleDays2 and (settleDays3 is null or p_overdat>settleDays3)
                then 'marginitem2 ,marginitem2_s'
                when settleDays3 is not null and p_overdat<=settleDays3 and (settleDays4 is null or p_overdat>settleDays4)
                then 'marginitem3 ,marginitem3_s'
                when settleDays4 is not null and p_overdat<=settleDays4 and (settleDays5 is null or p_overdat>settleDays5)
                then 'marginitem4 ,marginitem4_s'
                when settleDays5 is not null and p_overdat<=settleDays5
                then 'marginitem5 ,marginitem5_s'
           else 'marginrate_b,marginrate_s' end
      into v_marginsetsql
      from t_commodity
     where commodityid=p_CommodityID ;
    v_getmarginsql:='select marginalgr,contractfactor ,'||v_marginsetsql||'  from t_commodity where commodityid='''||p_CommodityID||'''' ;
    --dbms_output.put_line(v_getmarginsql);
    execute immediate v_getmarginsql into v_marginAlgr,v_contractFactor,v_marginRate_b,v_marginRate_s;

    begin
        --获取特户的交易担保金，保证金算法
        v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from T_A_FirmMargin where FirmId='''||p_FirmID||''' and commodityid='''||p_CommodityID||'''' ;
        execute immediate v_getmarginsql into v_marginAlgr,v_marginRate_b,v_marginRate_s;
    exception
        when NO_DATA_FOUND then
            null;
    end;

    if(v_marginAlgr=1) then  --应收保证金=数量*合约因子*价格*保证金
        if(p_bs_flag = 1) then  --买
            if(v_marginRate_b = -1) then --  -1表示收全款
              v_margin:=p_quantity*v_contractFactor*p_price;
            else
              v_margin:=p_quantity*v_contractFactor*p_price*v_marginRate_b;
            end if;
        elsif(p_bs_flag = 2) then  --卖
            if(v_marginRate_s = -1) then --  -1表示收全款
              v_margin:=p_quantity*v_contractFactor*p_price;
            else
              v_margin:=p_quantity*v_contractFactor*p_price*v_marginRate_s;
            end if;
        end if;
    elsif(v_marginAlgr=2) then  --应收保证金=数量*保证金
        if(p_bs_flag = 1) then  --买
            if(v_marginRate_b = -1) then --  -1表示收全款
              v_margin:=p_quantity*v_contractFactor*p_price;
            else
              v_margin:=p_quantity*v_marginRate_b;
            end if;
        elsif(p_bs_flag = 2) then  --卖
            if(v_marginRate_s = -1) then --  -1表示收全款
              v_margin:=p_quantity*v_contractFactor*p_price;
            else
              v_margin:=p_quantity*v_marginRate_s;
            end if;
        end if;
    end if;

    if(v_margin is null) then
    	rollback;
        return -1;
    end if;
    return v_margin;
exception
    when no_data_found then
    	rollback;
        return -1;
    when others then
	    rollback;
    	return -100;
end;
/

