CREATE VIEW V_BR_BROKERAPPLY AS
  select t1.brokerid,t1.name
  from br_broker t1,br_broker_relation t2 ---非纯数字不可在线开户（在线开户不支持）
 where t1.brokerid=t2.brokerid  and  regexp_like(t1.brokerid,'^[[:digit:]]+$')  and t1.membertype=0 and t1.brokerid not in (select m.brokerid from m_broker m)
/

