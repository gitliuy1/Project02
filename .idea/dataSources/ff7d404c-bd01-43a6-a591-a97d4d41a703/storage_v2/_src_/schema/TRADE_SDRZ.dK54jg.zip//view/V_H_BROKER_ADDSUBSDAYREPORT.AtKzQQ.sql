CREATE VIEW V_H_BROKER_ADDSUBSDAYREPORT AS
  select b1.rootbrokerid,b1.rootLevel,bt.commodityid,bt.cleardate,b2.name rootname
       , sum(bt.tradefee) tradefee,sum(bt.quantity) quantity,sum(bt.amount) amount
  from v_broker_relation_all b1 ,v_h_broker_dayreport bt, br_broker b2
 where b2.brokerid=b1.rootbrokerid and b1.brokerid=bt.brokerid
 group by b1.rootbrokerid,b1.rootLevel,bt.commodityid,bt.cleardate,b2.name
/

