CREATE VIEW V_T_OVERDUEHOLDPOSITION AS
  select firmid,       -- 交易商代码
       customerid,   -- 交易客户代码
       commodityid,  -- 商品代码
       bs_flag,      -- 买卖方向，1：买，2：卖
       holdqty,      -- 持仓数量
       openqty,      -- 开仓数量
       gageqty,      -- 抵顶数量
       maycloseQty   -- 可转让数量
  from (select ag.*, (s.holdqty - s.FrozenQty) maycloseQty
          from (select a.firmid,
                       a.customerid,
                       a.commodityid,
                       a.bs_flag,
                       sum(a.holdqty) holdqty,
                       sum(a.openqty) openqty,
                       sum(a.gageqty) gageqty
                  from T_HoldPosition a
                 where 1 = 1
                   and remainday = 0
                   and a.deadline is not null
                 group by a.firmid, a.customerid, a.commodityid, a.bs_flag) ag,
               t_customerholdsum s
         where ag.commodityid = s.commodityid
           and ag.customerid = s.customerid
           and ag.bs_flag = s.bs_flag
           and ag.holdqty > 0
           )
/

