CREATE function FN_BI_SwapTradePlus( p_orderno        varchar2       ---发起委托单号
                                            ,p_tradeType     number  			  ---成交类型，对应串换类型
                                            ,p_auditor       varchar2       ---操作人
                                            ,p_remark        varchar2       ---备注
)
return number as
/****
 * 功能：串换成交 yuansr 2017 05 16
 * 返回值:  -1=发起状态，不可终审成交;-2=确认交易商拒绝委托，不可终审成交;-3=待初审委托，不可终审成交;
 *         -5=已终审成交委托，不可终审成交;-6=已撤单委托，不可终审成交;
 *         -100=其它错误
****/
  v_result           number(2);
  v_errorcode        number;
  v_errormsg         varchar2(200);

  v_F_FrozenFunds    F_FIRMBALANCE.LASTBALANCE%type;
  v_status           BI_SWAPSTOCKORDERS.STATUS%type;
  v_stockids         BI_SWAPSTOCKORDERS.STOCKIDS%type;
  v_compensate       BI_SWAPSTOCKORDERS.COMPENSATE%type;  
  v_firmid           BI_SWAPSTOCKORDERS.FIRMID%type;

  v_o_compensate     BI_SWAPSTOCKORDERS.COMPENSATE%type;
  v_o_firmid         BI_SWAPSTOCKORDERS.FIRMID%type;
  v_o_stockids       BI_SWAPSTOCKORDERS.STOCKIDS%type;
  v_TradeNo          BI_SWAPSTOCKTRADE.TRADENO%type;
  
  v_sql              varchar2(500);
  type c_item is ref cursor;
  v_item             c_item;
  v_stockId          bi_stock.stockid%type;

begin

  ---1 获取委托信息
  select t.status  ,t.firmid ,t.stockids ,t.compensate  ,t.o_firmid ,t.o_stockids ,t.o_compensate 
    into v_status  ,v_firmid ,v_stockids ,v_compensate  ,v_o_firmid ,v_o_stockids ,v_o_compensate
    from bi_swapstockorders t 
   where t.orderno=p_orderno for update ;

  ---2 验证成交前提
  if v_status <> 4  then --不是待终审状态，不可终审成交
     return 0-v_status;  ---交易商未审核同意
  end if;

  ---3 成交回报处理
  --委托中的发起交易商仓单过户给确认交易商
  v_sql:='select t.stockid  from bi_stock t where  t.ownerfirm='''||v_firmid||''''
       ||'   and t.stockid in('''|| replace(v_stockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND;
       --解冻仓单
       v_result:=fn_bi_unfrozenbill(15,v_stockId);
       if v_result<>1 then
          rollback;
          return -3;
       end if;
       --更换仓单所属交易商
       update bi_stock t set t.ownerfirm=v_o_firmid ,t.lasttime=sysdate  where t.ownerfirm=v_firmid and t.stockid=v_stockId ;
  end loop;
  close v_item;
  --发起交易商附加资金划给确认交易商
  if (v_compensate is not null) and (v_compensate>0) then
     v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_firmid,0-v_compensate,'15');
     v_F_FrozenFunds:= fn_f_updatefunds(v_firmid,'15028',v_compensate,null);
     v_F_FrozenFunds:= fn_f_updatefunds(v_o_firmid,'15029',v_compensate,null);
  end if;

  --委托中的确认交易商仓单过户给发起交易商
  v_sql:='select t.stockid  from bi_stock t where  t.ownerfirm='''||v_o_firmid||''''
       ||'   and t.stockid in('''|| replace(v_o_stockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND;
       --解冻仓单
       v_result:=fn_bi_unfrozenbill(15,v_stockId);
       if v_result<>1 then
          rollback;
          return -3;
       end if;
       --更换仓单所属交易商
       update bi_stock t set t.ownerfirm=v_firmid  ,t.lasttime=sysdate  where t.ownerfirm=v_o_firmid and t.stockid=v_stockId  ;
  end loop;
  close v_item;
  --确认交易商附加资金划给发起交易商
  if (v_o_compensate is not null) and (v_o_compensate>0) then
     v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_o_firmid,0-v_o_compensate,'15');
     v_F_FrozenFunds:= fn_f_updatefunds(v_o_firmid,'15028',v_o_compensate,null);
     v_F_FrozenFunds:= fn_f_updatefunds(v_firmid,'15029',v_o_compensate,null);
  end if;

  --4 创建成交记录
  select FN_T_ComputeTradeNo(SEQ_BI_SwapStockTrade.nextval) into v_TradeNo from dual;

  insert into Bi_Swapstocktrade( tradeno, orderno, o_orderno, tradetime, swapway, auditor  ) 
  values ( v_TradeNo ,p_orderno  ,p_orderno ,sysdate ,p_tradeType ,p_auditor ) ;

  ---4 更新委托状态为审核成交
  update bi_swapstockorders t set t.status=t.status+1 ,t.modifytime=sysdate ,t.auditor=p_auditor ,t.remark=t.remark||';'||p_remark
   where t.orderno=p_orderno;  

  return v_TradeNo;
  
  exception
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_BI_SwapTradePlus',v_errorcode,v_errormsg);
    
     insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'datas',-1,p_orderno||'|'||p_tradeType||'|'||p_auditor||'|'||p_remark);
    commit;
    return -100;
end;
/

