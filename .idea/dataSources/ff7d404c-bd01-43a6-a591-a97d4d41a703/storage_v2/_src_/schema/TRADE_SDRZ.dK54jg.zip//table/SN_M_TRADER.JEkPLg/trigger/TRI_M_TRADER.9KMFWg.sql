CREATE TRIGGER TRI_M_TRADER
  AFTER UPDATE
  ON SN_M_TRADER
  FOR EACH ROW
  declare
    --tmp_id number(10):=-1;
begin
  if updating then
     for p in(select password from m_trader where traderId=:old.traderId)
     loop
         if (p.password!=:new.password) then
              update m_trader set password=:new.password where traderId=:old.traderId;
         end if;
     end loop;
  end if;
end TRI_m_trader;
/

