CREATE VIEW V_BI_STOCKOPERATION AS
  select t."STOCKID",t."OPERATIONID",(select count(*) from bi_stockoperation bs where bs.isgage = '1' and bs.stockid = t.stockid ) as isGage,(select count(*) from bi_dismantle bd where bd.status='0' and bd.stockid = t.stockid) as isFirstAudit,(select count(*) from bi_dismantle bd where bd.status='3' and bd.stockid = t.stockid) as isFinalAudit from bi_stockoperation t
/

