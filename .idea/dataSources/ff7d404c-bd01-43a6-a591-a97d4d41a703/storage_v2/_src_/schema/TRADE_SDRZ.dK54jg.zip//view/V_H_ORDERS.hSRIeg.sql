CREATE VIEW V_H_ORDERS AS
  select t.cleardate,t.a_Orderno,t.a_orderno_w,t.commodityid,t.customerid,t.traderid,t.bs_flag,case when t.ordertype=1 then '订立' else case when t.timeflag=1 then '转让' when timeflag=2 then '调期转让' else '转让' end end ordertype,t.status,t.withdrawtype,t.failcode,t.quantity,t.price,t.closemode,t.specprice,t.tradeqty,t.frozenfunds,t.unfrozenfunds,t.ordertime,t.withdrawtime,t.ordererip,t.signature,t.closeflag,t.firmid,t.consignerid,t.withdrawerid,t.updatetime,t.billtradetype,t.specialorderflag,t.a_holdno from t_h_orders t
/

