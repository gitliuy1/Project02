CREATE function FN_T_D_SettleMatch_txandfirmBk(
                            p_type number
) return number
/****
 * 交收申报配对 ,针对特许服务商和交易商撮合交收
 * add by lyf 2016080
****/
as
  v_version varchar2(10):='1.0.2.2';
    v_ret     number(4);
    v_FL_ret            timestamp;
    v_errorcode number;
    v_errormsg  varchar2(200);
    v_price t_quotation.curprice%type;
    v_margin number(15,2);  --交易保证金
    v_tradeday  number(8) := 0 ;   --下一个交易日
    v_HoldSum   number(15);
begin
    if p_type =1 then --备份数据
    --1.委托数据
      insert into t_holdposition_ysr select * from t_holdposition;
      insert into t_customerholdsum_ysr select * from t_customerholdsum;
      insert into t_firmholdsum_ysr select * from t_firmholdsum;     
    else--还原备份数据
      insert into t_holdposition select * from t_holdposition_ysr;
      insert into t_customerholdsum select * from t_customerholdsum_ysr;
      insert into t_firmholdsum select * from t_firmholdsum_ysr; 
    end if;

    return 1;
end;
/

