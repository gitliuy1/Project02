CREATE VIEW V_C_TRADEMODULE AS
  select distinct l.moduleid,t.shortname name from f_ledgerfield  l,C_TradeModule t where l.moduleid=t.moduleid
/

