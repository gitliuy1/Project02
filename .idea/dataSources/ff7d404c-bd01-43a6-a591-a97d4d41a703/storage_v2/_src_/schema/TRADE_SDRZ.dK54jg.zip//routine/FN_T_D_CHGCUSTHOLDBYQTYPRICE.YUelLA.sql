CREATE FUNCTION FN_T_D_ChgCustHoldByQtyPrice
(
  p_CustomerID    varchar2,   --交易客户代码
  p_CommodityID   varchar2,   --商品代码
  p_BS_Flag       number,     --买卖标志
  p_TradeQty      number,     --数量
  p_HoldPrice     number,     --持仓价
  p_HoldMargin    number,     --保证金
  p_HoldAssure    number      --担保金
)  return number
/***
 * 更新交易客户持仓合计信息
 *
 * 返回值：1成功
 ****/
is
  v_version varchar2(10):='1.0.0.0';
  v_ContractFactor    number(12,2);
  
begin
    ----获取商品合约因子
    select ContractFactor into v_ContractFactor from T_Commodity where CommodityID = p_CommodityID;
    --更改交易客户持仓合计表中的持仓记录
    update T_CustomerHoldSum
       set holdqty = holdqty - p_TradeQty
           ,FrozenQty = FrozenQty - decode(sign(p_TradeQty),-1,0,p_TradeQty) --当p_TradeQty<0时，不需要冻结数量，mod by lizs
           ,holdfunds = holdfunds - p_HoldPrice*p_TradeQty*v_ContractFactor
           ,HoldMargin = HoldMargin - nvl(p_HoldMargin,0)
           ,HoldAssure = HoldAssure - nvl(p_HoldAssure,0)
           ,EvenPrice = decode(HoldQty+GageQty-p_TradeQty,0,0,(HoldFunds-p_HoldPrice*p_TradeQty*v_ContractFactor)/((HoldQty+GageQty-p_TradeQty)*v_ContractFactor))
     where CustomerID = p_CustomerID
       and CommodityID = p_CommodityID
       and bs_flag = p_BS_Flag;

   return 1;
end;
/

