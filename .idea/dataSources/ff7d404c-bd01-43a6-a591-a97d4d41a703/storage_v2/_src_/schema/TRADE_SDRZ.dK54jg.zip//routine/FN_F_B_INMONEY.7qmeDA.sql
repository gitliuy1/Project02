CREATE function FN_F_B_INMONEY
(
  p_bankID varchar2,      --银行编号
  p_firmID varchar2,      --交易商代码
  p_amount number,        --发生额
  p_remark varchar2,      --备注
  p_type varchar2         --发起方（M:市场  B:银行）
) return number
/***
 * 入金
 * version 1.0.0.0 此方法公用
 *
 * 返回值：资金流水号
 ****/
is
  v_reNum number(10):=0;           -- 返回值 大于0 流水号   小于0 错误码
  v_control number(1);           -- 0 受到双重约束，1不受约束，2受交易日约束，3受交易时间约束
  v_beginTime varchar2(8);       -- 交易开始时间
  v_endTime varchar2(8);         -- 交易结束时间
  v_actionid varchar2(100);      -- 出入金流水号
  v_notTradeWeek number(10);     -- 非交易日
  v_notTradeDay number(10);      -- 非交易日
  v_status number(1);            --客户状态  0不可用 1可用
  v_isOpen number(1);            --签解约状态 0未签约 1已签约
  v_tradeFee number(15,2) default 0;       --手续费
  v_dicIn varchar(8);            --入金摘要
  v_dicFee varchar(8);           --手续费摘要
  v_oprCode varchar(8);          --银行科目
  v_countDate varchar(8);          --交易日期表条数
begin
  begin
    select control,beginTime,endTime into v_control,v_beginTime,v_endTime from F_B_banks where bankid=p_bankID;
  exception when NO_DATA_FOUND then
    v_reNum := -1;
    return v_reNum;
  end;
  --判断交易日期及交易时间
  if(v_control=0) then
    begin
      select count(*) into v_countDate from t_a_nottradeday;
      if (v_countDate != 0) then
        select instr('' || week, to_char(sysdate, 'D')),
               instr('' || day, to_char(sysdate, 'yyyy-MM-dd'))
          into v_notTradeWeek, v_notTradeDay
          from t_a_nottradeday;
        if (v_notTradeWeek > 0 or v_notTradeDay > 0) then
          v_reNum := -2; --非交易日
          return v_reNum;
        end if;
      end if;
    exception
      when NO_DATA_FOUND then
        v_reNum := 0;
    end;
      if(to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmddHH24:Mi:ss')>sysdate or to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')<sysdate) then
         v_reNum := -3; --非交易时间
         return v_reNum;
      end if;
  elsif(v_control=2) then
    begin
      select count(*) into v_countDate from t_a_nottradeday;
      if (v_countDate != 0) then
        select instr('' || week, to_char(sysdate, 'D')),
               instr('' || day, to_char(sysdate, 'yyyy-MM-dd'))
          into v_notTradeWeek, v_notTradeDay
          from t_a_nottradeday;
        if (v_notTradeWeek > 0 or v_notTradeDay > 0) then
          v_reNum := -2; --非交易日
          return v_reNum;
        end if;
      end if;
    exception
      when NO_DATA_FOUND then
        v_reNum := 0;
    end;
  elsif(v_control=3) then
      --select * from dual t where to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmdd HH24:Mi:ss')<sysdate and to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')>sysdate
      if(to_date(to_char(sysdate,'yyyyMMdd')||v_beginTime,'yyyymmddHH24:Mi:ss')>sysdate or to_date(to_char(sysdate,'yyyyMMdd')||v_endTime,'yyyymmdd HH24:Mi:ss')<sysdate) then
         v_reNum := -3; --非交易时间
         return v_reNum;
      end if;
  end if;
--判断交易商状态
  begin
    select status,isopen into v_status,v_isOpen from f_b_Firmidandaccount where firmid=p_firmID and bankid=p_bankID;
  exception when NO_DATA_FOUND then
    v_reNum := -4; --交易商不存在
    return v_reNum;
  end;
  if(v_status!=0)then
    v_reNum := -5; --交易商不可用
    return v_reNum;
  end if;
  if(v_isOpen!=1)then
    v_reNum := -6; --交易商未签约
    return v_reNum;
  end if;

  --计算交易商手续费数据
    --手续费暂时不处理默认为0.后期考虑加上


  --插入资金流水
  select SEQ_F_B_ACTION.nextval into v_actionid from dual;
  select value into v_dicIN from f_b_dictionary where name = 'insummary';
  select value into v_dicFee from f_b_dictionary where name = 'feesummary';
  select value into v_oprCode from f_b_dictionary where type=1 and bankid=p_bankid;
  insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
  values(SEQ_F_B_CAPITALINFO.nextval, p_firmid, null, p_bankid, v_oprCode, p_firmid, 0, p_amount, v_dicIN, sysdate, null, 2, p_remark, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);

  insert into F_B_capitalInfo(id, FIRMID, FUNID, BANKID, DEBITID, CREDITID, TYPE, MONEY, OPERATOR, CREATETIME, BANKTIME, STATUS, NOTE, ACTIONID,EXPRESS,bankName,account,createdate,funid2)
  values(SEQ_F_B_CAPITALINFO.nextval, p_firmid, null, p_bankid, p_firmid, 'Market', 2, v_tradeFee, v_dicFee, sysdate, null, 2, p_remark, v_actionid,0,null,null,to_char(sysdate,'yyyy-MM-dd'),'gnnt'||v_actionid);

  return v_actionid;
end;
/

