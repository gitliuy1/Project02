CREATE VIEW V_T_E_APPLYGAGE AS
  select g."APPLYID",g."COMMODITYID",g."FIRMID",g."CUSTOMERID",g."QUANTITY",g."APPLYTYPE",g."STATUS",g."CREATETIME",g."CREATOR",g."REMARK1",g."MODIFYTIME",g."MODIFIER",g."REMARK2",m.name name from T_E_ApplyGage g,m_firm m
where g.firmid = m.firmid
/

