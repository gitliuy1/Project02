CREATE VIEW V_T_SETTLEMATCH AS
  select a."MATCHID",a."COMMODITYID",a."CONTRACTFACTOR",a."QUANTITY",a."HL_AMOUNT",a."STATUS",a."RESULT",a."SETTLETYPE",a."FIRMID_B",a."BUYPRICE",a."BUYPAYOUT_REF",a."BUYPAYOUT",a."BUYMARGIN",a."TAKEPENALTY_B",a."PAYPENALTY_B",a."SETTLEPL_B",a."FIRMID_S",a."SELLPRICE",a."SELLINCOME_REF",a."SELLINCOME",a."SELLMARGIN",a."TAKEPENALTY_S",a."PAYPENALTY_S",a."SETTLEPL_S",a."CREATETIME",a."MODIFYTIME",a."SETTLEDATE",a."MODIFIER",a."ISTRANSFER", b.name b_name,c.s_name s_name
  from T_SettleMatch a,
       m_firm b,
       (select s.matchid matchid,m.name s_name
          from T_SettleMatch s, m_firm m
         where s.firmid_s = m.firmid) c
 where a.firmid_b = b.firmid
 and a.matchid = c.matchid
/

