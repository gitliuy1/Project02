CREATE function FN_T_ComputeSwapFee(
    p_a_HoldNo       number,
    p_quantity       number,
    p_bs_flag        number
) return number
/****
 *add by lyf 20160126 （平历史仓时计算调期费函数）
 * 根据参数计算 调期费用
 * 返回值 成功返回手续费;-1 计算交易费用所需数据不全;-100 其它错误
****/
as
  v_version varchar2(10):='1.0.0.1';
  v_fee             number(15,2) default 0;
  v_ratio           number(15,2) default 0;
  v_overdate        number(15) default 0;
  v_commodityid     varchar2(15);
  v_count1           number(15);        --数据条数 2017-4-11 15:39:51 by hanqr
  v_count2           number(15);
  v_firmId          varchar2(32);          --交易商代码
  v_txFirmId        varchar2(32);          --特许服务商代码
  v_buyrate         number(8,4);       --买特殊费率
  v_sellrate        number(8,4);       --卖特殊费率
  v_rate            number(8,4);       --特殊费率
begin
    select t.overdat,commodityid,t.firmid into v_overdate,v_commodityid,v_firmId from t_holdposition t where t.a_holdno=p_a_HoldNo;
    select ratio into v_ratio from swapfee where commodityid=v_commodityid and swapday=v_overdate and bs_flag=p_bs_flag;
    v_fee:= p_quantity*v_ratio;
    
    --增加特殊调期服务费计算
    --查出交易商、商品对应的特许服务商
    /*select count(*) into v_count1 from t_tx_fctxf t where t.firmid=v_firmId and t.commodityid=v_commodityid;
    --如果有对应的特许服务商，则查出交易商、商品、特许服务商对应的特殊调期服务费率
    if(v_count1 > 0 ) then
    	select t.txfirmid into v_txFirmId from t_tx_fctxf t where t.firmid=v_firmId and t.commodityid=v_commodityid;
      select count(*) into v_count2 from t_tx_speSwapRate s where s.commodityid=v_commodityid and s.firmid=v_firmId and s.txfirmid=v_txFirmId;
      
      --查出对应的特殊费率
      if(v_count2 > 0) then 
      
         select s.buyrate,s.sellrate into v_buyrate,v_sellrate
                from t_tx_speSwapRate s where s.commodityid=v_commodityid and s.firmid=v_firmId and s.txfirmid=v_txFirmId;       
         if(p_bs_flag = 1) then--买方向 
            v_rate := v_buyrate;
         else --卖方向
           v_rate := v_sellrate;
         end if;
          
         if(v_fee is null) then
          --  rollback;
          return 0;
         else
           v_fee := v_fee * v_rate; --调期服务费= 调服务费 * 特殊比率
         end if;
         
      end if;    
    end if;*/
    
    --1特殊调期服务费计算 yuansr 2017 08 24
    begin
       select t1.buyrate,t1.sellrate into v_buyrate,v_sellrate
         from t_tx_speSwapRate t1 ,t_tx_fctxf t2 
        where t1.txfirmid = t2.txfirmid and t1.firmid = t2.firmid and t1.commodityid=t2.commodityid
          and t1.firmid=v_firmId and t1.commodityid=v_commodityid
          and t2.firmid=v_firmId and t2.commodityid=v_commodityid;

       if(p_bs_flag = 1) then--买方向 
         v_fee:= v_fee*v_buyrate;
       else --卖方向
         v_fee:= v_fee*v_sellrate;
       end if;

    exception
        when NO_DATA_FOUND then
            --rollback;
            return v_fee;  --无特殊设置，直接返回计算出的结果值
    end;
   
    if(v_fee is null) then
      --  rollback;
      return 0;
    end if;    
    return v_fee;
exception
    when no_data_found then
      --rollback;
        return 0;
    when others then
      --rollback;
       return -100;
end;
/

