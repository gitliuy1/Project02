CREATE function FN_T_SettleMatch_TX2 return number
/****
   *   add by hanqr 20170714 增加子特许服务商自主交收
   *  轮询持仓时过滤交收类型不为提前交收即可（除延期商品交收申报当日下市外，交收持仓不会出现同时存在延期和到期交收的情况，这是遗留问题，暂时排除该情况）
   *  添加配对时交收类型只看商品设置的交收类型与持仓的交收类型无关
   * 返回值
   *  1 成功
   * -1 买方持仓不足
   * -2 卖方持仓不足
  ****/
 as
  v_contractFactor       number; --合约因子
  v_buypayout_ref        number(15, 2) := 0; --买方参考货款
  v_buyPayout            number(15, 2) := 0; --已收买方货款
  v_sellincom_ref        number(15, 2) := 0; --卖方参考货款
  v_buyMargin            number(15, 2) := 0; --买方交收保证金
  v_sellMargin           number(15, 2) := 0; --卖方交收保证金
  v_everybuyPayout       number(15, 2) := 0; --买方每笔持仓已收货款
  v_everybuyMargin       number(15, 2) := 0; --买方每笔持仓交收保证金
  v_everysellMargin      number(15, 2) := 0; --卖方每笔持仓交收保证金
  v_price                number;
  v_settleprice_b        number := 0;
  v_settleprice_s        number := 0;
  v_weight               number(15, 4);
  v_amountQty_s          number(10);
  v_amountQty_b          number(10);
  v_quantity             number(10);
  v_settlePriceType      number(2); --到期交收价格计算 0 （结算价）,1,3 统一价 2订立价
  v_delaySettlePriceType number(2); --延期交收申报交收价格类型 0统一价（结算价） 1订立价
  v_settleType           number(2); --配对表的交收方式 1到期 3延期
  v_settleDate           varchar2(20); --交收日期 （到期交收取持仓明细的交收处理日期，延期为p_settleDate）
  v_settleWay            number(2); --商品表交收方式0中远期（到期） 1连续现货（延期） 2专场交易 （到期）
  v_count                number;
  v_frozen               number(15);
  v_TradeDate            date;
  v_amountQty            number(10);
  v_matchId              varchar2(32);
  v_quantity_s             number(10);
  v_Qty                  number(10);   --add by lyf 20160818 记录成交数量
  v_ztxFirm              varchar2(32);         -- 总特许服务商 新建2017-3-30 11:02:09 hanqr

begin

  for txf in (select txfirmid from t_tx_txfirm) loop
      select TradeDate into v_TradeDate from T_SystemStatus;
      --1. 查询 非提前交收，未完全配对的交收持仓明细商品并去重复,根据商品代码查询可配对的的交收日期（到期和延期）
      --modify by lyf 20160816 增加判断特许的交收明细数据是不是审核的数量的条件，持仓明细里 sa_orderno 不为空的时候表示为客户主动交收委托并且特许同意，所以需要去除
      for sl in (select id,firmid, customerid, commodityid, settleprocessdate, bs_flag, price, holdqty, holdtime, holdmargin, gageqty, settletype, holdtype, overdat,Payout,settlePrice,SettleMargin,happenMatchPayout,happenMatchSettleMargin
                   from t_settleholdposition t, (select distinct a_holdno, min(overdat) overdat from (
                          (select overdat, a_holdno from t_holdposition where overdat <= 1 and sa_orderno is null) union all
                          (select distinct min(overdat) overdat, a_holdno from t_h_holdposition b where sa_orderno is null and b.a_holdno in (select distinct a_holdno from t_h_holdposition) and overdat <= 1 group by a_holdno)
                        ) group by a_holdno) h
                  where t.a_holdno = h.a_holdno
                    and matchStatus != 2
                    and settleType <> 2
                    --and firmid = v_ztxFirm
                    and   firmid = txf.txfirmid
                    and settleprocessdate = v_TradeDate
                    and bs_flag = 2
                  order by t.a_holdno asc) loop

                  v_sellincom_ref  := 0;

        select seq_T_SettleMatch.nextval into v_matchId from dual;
        v_matchId := 'TX_' || v_matchId;
        --到历史商品表查询商品参数 如果历史查不到查当前商品（因为交易结算时商品导历史，所以在交易结算前做当天的延期申报配对时只能查当前商品表）
        select count(*) into v_count from t_h_commodity where commodityid = sl.commodityid and trunc(cleardate) = trunc(sl.settleprocessdate);
        if v_count = 0 then
          select settlepricetype, delaySettlePriceType, contractFactor, settleWay into v_settlePriceType, v_delaySettlePriceType, v_contractFactor, v_settleWay
            from t_commodity  where commodityid = sl.commodityid;
        else
          select settlepricetype, delaySettlePriceType, contractFactor, settleWay into v_settlePriceType, v_delaySettlePriceType, v_contractFactor, v_settleWay
            from t_h_commodity where commodityid = sl.commodityid and trunc(cleardate) = trunc(sl.settleprocessdate);
        end if;

        --说明 ：合同到期，将客户和特许服务商的到期持仓，按照当日结算价进行交收结算，计算交收盈亏，计入可用资金，所以去结算价交收

        v_settleType           := 3;
        v_delaySettlePriceType := 0;
        v_settlePriceType      := 0;
        v_Qty:=0;
        v_buypayout_ref  := 0;
        --卖方
        select nvl(sum(HoldQty + GageQty - happenMATCHQTY), 0) into v_amountQty_s from t_settleholdposition t where CommodityID = sl.commodityid
               and BS_Flag = 2 and FirmID = sl.firmid and settletype <> 2 and SettleProcessDate = sl.settleprocessdate and id=sl.id ;
         v_quantity_s:=v_amountQty_s;
        --add by 20160815 增加买交收明细数据循环
        for bl in (select id,firmid, customerid, commodityid, settleprocessdate, bs_flag, price, holdqty, holdtime, holdmargin, gageqty, settletype, holdtype,Payout,settlePrice,SettleMargin,happenMatchPayout,happenMatchSettleMargin
                     from t_settleholdposition t, (select distinct a_holdno, min(overdat) overdat from (
                                   (select overdat, a_holdno from t_holdposition where overdat <= 1 and sa_orderno is null) union all
                                   (select distinct min(overdat) overdat, a_holdno from t_h_holdposition b where sa_orderno is null and b.a_holdno in (select distinct a_holdno from t_h_holdposition) and overdat <= 1 group by a_holdno))
                            group by a_holdno) h
                    where t.a_holdno = h.a_holdno
                      and matchStatus != 2
                      and settleType <> 2
                      --and firmid = v_ztxFirm
                      and   firmid = txf.txfirmid
                      and settleprocessdate = sl.settleprocessdate
                      and commodityid = sl.commodityid
                      and bs_flag = 1
                    order by t.a_holdno asc) loop

           --v_buypayout_ref  := 0;

          --买方
          select nvl(sum(HoldQty + GageQty - happenMATCHQTY), 0) into v_amountQty_b from t_settleholdposition t
           where CommodityID = bl.commodityid and BS_Flag = 1 and FirmID = bl.firmid and settletype <> 2 and SettleProcessDate = bl.settleprocessdate and id=bl.id;

          if v_amountQty_b > v_quantity_s then
            v_amountQty := v_quantity_s;
          elsif v_quantity_s > v_amountQty_b then
            v_amountQty := v_amountQty_b;
          else
            v_amountQty := v_amountQty_b;
          end if;
          v_weight := v_amountQty; --配对数量

              v_settleDate := bl.settleprocessdate;
              v_quantity:=v_amountQty_b;
              if (v_settlePriceType = 2) then
                v_price := bl.price;
              else
                v_price := bl.settlePrice;
              end if;
              v_settleprice_b := bl.settlePrice;
              if v_quantity > v_weight then
                if v_weight <> 0 then
                v_buypayout_ref  := v_buypayout_ref + v_price * v_weight * v_contractFactor;
                v_everybuyPayout := bl.Payout / (bl.HoldQty + bl.GageQty) * v_weight;
                v_everybuyMargin := bl.SettleMargin / (bl.HoldQty + bl.GageQty) * v_weight;
                v_buyPayout      := v_buyPayout + v_everybuyPayout;
                v_buyMargin      := v_buyMargin + v_everybuyMargin;
                --修改交收持仓明细配对状态=部分配对，已配对数量，已配对货款，已配对保证金
                update T_SettleHoldPosition
                   set MATCHStatus             = 1,
                       happenmatchqty          = happenmatchqty + v_weight,
                       happenMatchPayout       = happenMatchPayout + v_everybuyPayout,
                       happenMatchSettleMargin = happenMatchSettleMargin + v_everybuyMargin
                 where id = bl.id;
                --插入交收配对关联表
                insert into T_MatchSettleholdRelevance (MatchID, SettleID, Quantity, Price,  SettlePayOut, Settlemargin)
                values (v_matchId, bl.id, v_weight, v_price, v_everybuyPayout, v_everybuyMargin);
                v_Qty:=v_Qty+v_weight;  --add by lyf 20160818 增加买交收数量的统计。
                 v_quantity_s:=v_quantity_s-v_weight;
                v_weight := 0;
                end if;
              else
                if v_quantity > 0 then
                  v_buypayout_ref := v_buypayout_ref + v_price * v_quantity * v_contractFactor;
                  v_weight        := v_weight - v_quantity;
                  v_Qty:=v_Qty+v_quantity;  --add by lyf 20160818 增加买交收数量的统计。
                  v_quantity_s:=v_quantity_s-v_quantity;
                  --最后一笔持仓用减法换算已配对货款和保证金
                  v_everybuyPayout := bl.Payout - bl.happenMatchPayout;
                  v_everybuyMargin := bl.SettleMargin - bl.happenMatchSettleMargin;
                  v_buyPayout      := v_buyPayout + v_everybuyPayout;
                  v_buyMargin      := v_buyMargin + v_everybuyMargin;
                  --修改交收持仓明细配对状态=全部配对，已配对数量，已配对货款，已配对保证金
                  update T_SettleHoldPosition
                     set MATCHStatus             = 2,
                         happenmatchqty          = bl.HoldQty + bl.GageQty,
                         happenMatchPayout       = happenMatchPayout +  v_everybuyPayout,
                         happenMatchSettleMargin = happenMatchSettleMargin + v_everybuyMargin
                   where id = bl.id;
                  --插入交收配对关联表
                  insert into T_MatchSettleholdRelevance
                    (MatchID,
                     SettleID,
                     Quantity,
                     Price,
                     SettlePayOut,
                     Settlemargin)
                  values
                    (v_matchId,
                     bl.id,
                     v_quantity,
                     v_price,
                     v_everybuyPayout,
                     v_everybuyMargin);
                end if;
              end if;

              --v_quantity_s:=v_quantity_s-v_weight;
              exit when v_quantity_s = 0;
            /*end loop;
          end if;*/
        end loop;
        --卖方
            v_weight := v_Qty;
            v_settleDate := sl.settleProcessDate;
            v_quantity   := v_amountQty_s;
            if (v_settlePriceType = 2) then
              v_price := sl.price;
            else
              v_price := sl.settlePrice;
            end if;
            v_settleprice_s := sl.settlePrice;
            if v_quantity > v_weight then
              if v_weight<>0 then
              v_sellincom_ref   := v_sellincom_ref +
                                   v_price * v_weight * v_contractFactor;
              v_everysellMargin := sl.SettleMargin /(sl.HoldQty + sl.GageQty) * v_weight;
              v_sellMargin      := v_sellMargin + v_everysellMargin;
              --修改交收持仓明细配对状态=部分配对，已配对数量，已配对保证金
              update T_SettleHoldPosition
                 set MATCHStatus             = 1,
                     happenmatchqty          = happenmatchqty + v_weight,
                     happenMatchSettleMargin = happenMatchSettleMargin + v_everysellMargin
               where id = sl.id;
              --插入交收配对关联表
              insert into T_MatchSettleholdRelevance
                (MatchID,
                 SettleID,
                 Quantity,
                 Price,
                 SettlePayOut,
                 Settlemargin)
              values
                (v_matchId, sl.id, v_weight, v_price, 0, v_everysellMargin);
              v_weight := 0;
              end if;
            else
              if v_quantity > 0 then
                v_sellincom_ref   := v_sellincom_ref +  v_price * v_quantity * v_contractFactor;
                v_everysellMargin := sl.SettleMargin - sl.happenMatchSettleMargin;
                v_sellMargin      := v_sellMargin + v_everysellMargin;
                v_weight          := v_weight - v_quantity;
                --修改交收持仓明细配对状态=全部配对，已配对数量，已配对保证金
                update T_SettleHoldPosition
                   set MATCHStatus             = 2,
                       happenmatchqty          = sl.HoldQty + sl.GageQty,
                       happenMatchSettleMargin = happenMatchSettleMargin + v_everysellMargin
                 where id = sl.id;
                --插入交收配对关联表
                insert into T_MatchSettleholdRelevance
                  (MatchID,
                   SettleID,
                   Quantity,
                   Price,
                   SettlePayOut,
                   Settlemargin)
                values
                  (v_matchId,
                   sl.id,
                   v_quantity,
                   v_price,
                   0,
                   v_everysellMargin);
              end if;
            end if;
            --exit when v_weight = 0;
          /*end loop;
        end if;*/
        --插入交收配对表
        if v_Qty>0 then
        insert into T_SettleMatch
          (MatchID,
           CommodityID,
           ContractFactor,
           Quantity,
           Status,
           Result,
           SettleType,
           FirmID_B,
           BuyPrice,
           BuyPayout_Ref,
           BuyPayout,
           BuyMargin,
           FirmID_S,
           SellPrice,
           SellIncome_Ref,
           SellIncome,
           SellMargin,
           CreateTime,
           ModifyTime,
           SettleDate,
           Modifier)
        values
          (v_matchId,
           sl.commodityid,
           v_contractFactor,
           v_Qty,
           2,
           1,
           v_settleType,
           sl.firmid,
           v_settleprice_b,
           v_buypayout_ref,
           v_buyPayout,
           v_buyMargin,
           sl.firmid,
           v_settleprice_s,
           v_sellincom_ref,
           0,
           v_sellMargin,
           sysdate,
           sysdate,
           v_settleDate,
           'system');
        --插入交收配对日志表
        insert into T_SettleMatchLog
          (id, Matchid, operator, Operatelog, Updatetime)
        values
          (seq_t_settlematchlog.nextval,
           v_matchId,
           'system',
           '添加交收配对：配对数量' || v_amountQty || ',买方：' || sl.firmid ||
           ',价格：' || v_settleprice_b || ',卖方:' || sl.firmid || '价格：' ||
           v_settleprice_s,
           sysdate);
          end if;
      end loop;--end of sl loop
  end loop; -- end of txf loop
  return 1;
end;
/

