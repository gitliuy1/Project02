CREATE FUNCTION FN_T_getMissOrderedQueue
(
    p_tableName            varchar2,  -- 表名
    p_columnName           varchar2,  -- 列名
    p_like                 varchar2,  --列过滤条件
    p_likeType             number,    --1=%p_like 2=p_like% 3=%p_like%
    p_dir                  number,    --截取放向 1=后，-1=前 ;0=不截取
    p_length               number     --长度 -1=不限制;
)
RETURN number
/****
 * 获取指定表指定列，最小缺失号（从1开始的最小数字）
 * 返回值 最小缺失号
****/
as
   v_sql                varchar2(3000);
   v_like               varchar2(100);
   v_substr             varchar2(300);
   v_where              varchar2(500);
   v_result             number(10);
begin

   v_where:='';
   v_sql:=' select ';--返回字符串
   v_like:='';

   if (p_like is not null and  length(p_like) >0 ) then
     v_like:=p_like;
     if (p_likeType=1) then
       v_like:= p_columnName||' like ''%'||v_like||'''';
     elsif (p_likeType=2) then
       v_like:= p_columnName||' like '''||v_like||'%''';
     elsif (p_likeType=3) then
        v_like:= p_columnName||' like ''%'||v_like||'%''';
     else
        return '';
     end if;
   end if;

   if (p_dir=1) then
     v_substr:=' substr('||p_columnName||',instr('||p_columnName||','''||p_like||''')+length('''||p_like||''') ) ';
   elsif (p_dir=-1 ) then
     v_substr:=' substr('||p_columnName||',1 ,instr('||p_columnName||','''||p_like||''') ) ';
   else
     v_substr:=p_columnName;
   end if;

   if (p_length>0) then
     if (p_dir=1) then
        v_substr:=' substr('||v_substr||',1 ,'||p_length||') ';
     else
        v_substr:=' substr('||v_substr||' ,-'||p_length||') ';
     end if;
   end if;

   v_sql:=v_sql||' to_number( '||v_substr||') ';--Enf to_number
   v_where:=' where regexp_instr( '|| v_substr|| ',''[1-9][0-9]?$'')=1  ';
   if (length(v_like)>1) then
     v_where:=v_where||' and '||v_like;
   end if;

   v_sql:=v_sql||' as  getNo  ';--Enf select

   v_sql:=v_sql||' from  '|| p_tableName ;
   
   v_sql:=v_sql||v_where;
   
   v_sql:='select min(t.getNo) maxNo from (' ||v_sql||') t '
        ||' where not exists ( select 1 from ( '||v_sql||') t2  where t2.getNo=t.getNo+1) ';

   execute immediate v_sql into v_result;

   return nvl(v_result,0)+1;
end;
/

