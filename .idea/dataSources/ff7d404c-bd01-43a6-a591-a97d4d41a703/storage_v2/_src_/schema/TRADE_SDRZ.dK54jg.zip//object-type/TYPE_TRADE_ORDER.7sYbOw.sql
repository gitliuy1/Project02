CREATE TYPE              "TYPE_TRADE_ORDER"                                          as object(
    OrderNo  number(15),  --小单委托单号
    Quantity  number(15),  --小单委托成交数量
    M_TradeNo_m  number(15),  --大单撮合成交号
    M_TradeNo_o  number(15)  --小单撮合成交号
);
/

