CREATE FUNCTION FN_T_getNextQueue
(
    p_broker                 varchar2  --会员代号
)
RETURN varchar2
/****
 * 获取指定表指定列，最小缺失号（从1开始的最小数字）
 * 返回值 最小缺失号
****/
as
   v_sql                varchar2(3000);
   v_like               varchar2(100);
   v_substr             varchar2(300);
   v_result             varchar2(10);
begin

   ---001不存在时,使用001
   v_sql:=  'select to_char(count(1)) from m_firm where firmId = '''||p_broker||'001''';
   execute immediate v_sql into v_result;
   if(v_result='0') then
     return '001';
   end if;

   ---存在001使用，从001开始寻找最小断点值
   if ( p_broker is not null and  length(p_broker) >0) then
      v_like:=' and firmId like '''||p_broker||'%''';
      v_substr:='substr(firmId,instr(firmId,'''||p_broker||''')+length('''||p_broker||''') ) ';
   else
      v_substr:=' firmId ';
   end if;
   
   v_sql := ' select to_number( '||v_substr||' )  as  getNo  '
         || '   from  m_firm where regexp_instr( '||v_substr||' ,''[[:digit:]]'')=1 and length(firmId)=length('''||p_broker||''')+3 '  
         || v_like;--返回字符串

   v_sql:='select to_char( nvl(min(t.getNo),0)+1 ,''000'' ) maxNo from (' ||v_sql||') t '
        ||' where not exists ( select 1 from ( '||v_sql||') t2  where t2.getNo=t.getNo+1) ';

   execute immediate v_sql into v_result;

   return substr(v_result,2);
end;
/

