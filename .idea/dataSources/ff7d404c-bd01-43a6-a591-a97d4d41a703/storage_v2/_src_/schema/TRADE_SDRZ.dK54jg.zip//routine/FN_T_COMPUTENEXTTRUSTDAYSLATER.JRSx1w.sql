CREATE function FN_t_ComputeNextTrustDaysLater
(
        i_nextDays number
)
return number
/****
 *  计算i_nextDays天后到下一个交易日的天数;减1就是i_nextDays天后紧跟的非交易日天数
 *  用于计算净持仓对应到期天数范围: i_nextDays<=净持仓到期天数<i_nextDays+FN_t_ComputeNextTrustDaysLater(i_nextDays)
 *  yuansr 2017 04 07
****/
as
    v_version              varchar2(10):='1.0.0.1';
    v_TradeDate            date;
    v_Week                 varchar2(30);            --非交易的星期几
    v_Day                  varchar2(1024);          --非交易的日期
    v_destWeek             varchar2(10);            --下个日期对应的星期几
    v_pos                  number(15,2):=0;         --位置
    v_bLoop                boolean;                 --是否需要循环标志
    v_Days                 number(10):=0;           --托管的天数

begin
    --1、获取i_days天后的结算日期,当天要计算在内 -1
    select trunc(sysdate+i_nextDays-1) into v_TradeDate from dual;
    --2、查询非交易日，未设置非交易日时返回1
    begin
           select Week,Day into v_Week,v_Day
             from t_A_NotTradeDay;
    exception
         when NO_DATA_FOUND then
       return 1;
    end;

    if (v_Week is null and v_Day is null) then
        return 1;
    end if;

    --3、推算到下一个交易日天数
    v_Days := 1;
    v_bLoop := true;
    
    while v_bLoop loop
      <<top>>
      select ',' || TO_CHAR(v_TradeDate+v_Days,'D') || ',' into v_destWeek  from dual;
      if(v_Week is not null) then
        select INSTR(',' || v_Week || ',',v_destWeek,1,1) into v_pos  from dual;
        if(v_pos > 0) then
          v_bLoop := true;
          v_Days := v_Days+1;
          goto top;
        else
          v_bLoop := false;
        end if;
      end if;
      if(v_Day is not null) then
        select INSTR(',' || v_Day || ',',to_char(v_TradeDate+v_Days,'yyyy-MM-dd'),1,1) into v_pos  from dual;
        if(v_pos > 0) then
          v_bLoop := true;
          v_Days := v_Days+1;
          goto top;
        else
          v_bLoop := false;
        end if;
      end if;
    end loop;
  
    --4、返回天数
    if (v_Days = 0) then
       return 0;
    end if;
    --dbms_output.put_line( '==========' || v_Days);

    return v_Days;
end;
/

