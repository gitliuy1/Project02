CREATE procedure SP_T_upDataIndexInit
as
/*重建数据上报序列（重置序号），从1开始 */
begin
    --1.当日上报成交单序列
  	execute immediate 'drop sequence SEQ_TradeIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_TradeIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';
    --2.当日上报委托单序列
  	execute immediate 'drop sequence SEQ_OrderIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_OrderIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';
	  --3.当日上报行情序列
  	execute immediate 'drop sequence SEQ_QuotationIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_QuotationIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';
    --4.当日上报仓单序列
  	execute immediate 'drop sequence SEQ_StockIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_StockIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';
    --5.当日上报交割数据序列
  	execute immediate 'drop sequence SEQ_DeliveryTradeIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_DeliveryTradeIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';
    --6.当日上报资金数据序列
  	execute immediate 'drop sequence SEQ_FundTransferIndexOfToday'; 
    -- Create sequence 
    execute immediate 'create sequence SEQ_FundTransferIndexOfToday '|| chr(10) ||
                      'minvalue 1'|| chr(10) ||
                      'maxvalue 9999999999999'|| chr(10) ||
                      'start with 1'|| chr(10) ||
                      'increment by 1'|| chr(10) ||
                      'nocache ';                                                                                        
                    
end;
/

