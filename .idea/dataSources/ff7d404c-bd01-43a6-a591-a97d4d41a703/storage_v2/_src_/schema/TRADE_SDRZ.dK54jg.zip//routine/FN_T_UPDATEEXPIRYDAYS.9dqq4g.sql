CREATE function fn_t_updateexpirydays(
p_ClearDate Date,
p_stockid varchar2)
/**
  * 更新仓单有效日期
  * yangq 2017.06.13
  */
 return number is
  v_remaindays       number;
  v_notificationdays number;
  v_firmid           varchar2(32);
  v_lastmodifytime   date;
  v_overDate         number;
  v_status           number;
begin
  --检查今天是否初始化过
  select t.lastmodifytime, t.expirydays
    into v_lastmodifytime, v_remaindays
    from bi_stock_expirydate t
   where t.stockid = p_stockid;
  if trunc(v_lastmodifytime) != trunc(sysdate) then
    --计算到下一个交易日的天数
    v_overDate := FN_t_ComputeTrustDays(p_ClearDate);
    --更新仓单有效期
    update bi_stock_expirydate t
       set t.expirydays     = t.expirydays - v_overDate,
           t.lastmodifytime = sysdate
     where t.stockid = p_stockid;
     --更新到期天数
    v_remaindays := v_remaindays - v_overDate;
    --提醒交易商
    select t.notificationdays
      into v_notificationdays
      from bi_expiry_settings t;
    select t.ownerfirm,t.stockstatus
             into v_firmid,v_status
             from bi_stock t
            where t.stockid = p_stockid;
  
    if (v_remaindays <= v_notificationdays and v_status != 2 and v_status !=3 and v_status != 6) then
      insert into m_message
      values
        (seq_m_message.nextval,
         '您的仓单:' || p_stockid || ' 即将到期,剩余有效期天数为:' || v_remaindays ||
         ' 请及时出库!',
         4,
         v_firmid,
         sysdate,
         'admin');
    end if;
  end if;
  return(0);
end;
/

