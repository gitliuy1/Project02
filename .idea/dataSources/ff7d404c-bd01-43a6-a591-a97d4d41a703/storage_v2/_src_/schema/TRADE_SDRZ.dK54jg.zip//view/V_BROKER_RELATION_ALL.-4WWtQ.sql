CREATE VIEW V_BROKER_RELATION_ALL AS
  select b1.brokerid,b1.brokerlevel,b1.parentid,b2.brokerid rootbrokerid,b2.brokerlevel rootLevel
  from br_broker_relation b2,br_broker_relation b1
 where b1.brokerid in (
        select b.brokerid
        from br_broker_relation b
        CONNECT BY b.parentid = prior b.brokerid AND b.brokerid != b.parentid
        start with  b.brokerid=b2.brokerid
       )
 order by b2.brokerid,b1.brokerlevel
/

