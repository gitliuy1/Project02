CREATE procedure SP_TQ_AllocateData
(
          p_TradeDate date
)
/***
 * 处理调期分配数据：数据移入历史表；初始化当日表
 ****/
is
begin

   --数据移入历史表
   insert into t_h_tx_holdAllotApply( txfirmid ,commodityid ,cleardate ,ztxfirmid ,qty_b ,qty_s ,changetime ,chager ,audittime ,status ,auditer )
   select txfirmid  ,commodityid  ,p_TradeDate  ,ztxfirmid  ,qty_b  ,qty_s  ,changetime  ,chager  ,audittime  ,status  ,auditer
     from t_tx_holdAllotApply;
   delete t_tx_holdAllotApply;
   --初始化关联分配状态
   update t_tx_holdAllotStatus t set t.status=0;

end;
/

