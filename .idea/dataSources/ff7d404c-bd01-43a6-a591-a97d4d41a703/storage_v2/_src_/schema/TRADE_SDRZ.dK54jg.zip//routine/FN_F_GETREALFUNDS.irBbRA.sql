CREATE function FN_F_GetRealFunds
(
  p_firmid varchar2,   --交易商代码
  p_lock number      --是否上锁 1:上锁 0：不上锁
) return number
/***
 * 获取可用资金
 * version 1.0.0.1 公用方法
 * 返回值：可用余额
 ****/
is
  v_realfunds number(15,2);
begin
  if(p_lock=1) then
    select balance-frozenfunds-frozengdfunds-frozenzgfunds into v_realfunds from f_firmfunds where firmid=p_firmid for update;   -- modify by lyf 20151123 减去调拨到高达的资金
  else
    select balance-frozenfunds-frozengdfunds-frozenzgfunds into v_realfunds from f_firmfunds where firmid=p_firmid;  -- modify by lyf 20151123
  end if;
  return v_realfunds;
end;
/

