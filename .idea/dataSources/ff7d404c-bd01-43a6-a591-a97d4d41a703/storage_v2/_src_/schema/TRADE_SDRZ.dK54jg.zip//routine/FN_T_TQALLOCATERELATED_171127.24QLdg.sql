CREATE function FN_T_TqAllocateRelated_171127 return number
/****
 * 根据子特许服务商交易商商品关系 进行调期交易持仓 分配
 * 返回值： 1 =成功；-1=不是闭市状态 ;-2 =已完成； -100 = 失败
 * 修改原因：直接修改持仓明细中的持仓交易商和交易商客户，会出现持仓明细全部分配后，结算时
 *        ，总特许服务商无明细有合计记录（数据为0 ），持仓明细合计条目与持仓合计条目不一致，
 *        引起重算交易资金（要求持仓明细合计条目与持仓合计条目一致） 异常；
 * 修改：采用更新原有持仓明细，新建持仓明细方式 进行持仓分配 2017 04 11
****/
as
    v_result                number(10);           --指定持仓合计
    v_ztxFirm               varchar2(32);         --总特许服务商
    v_ztxCustomer           varchar2(32);         --总特许服务商对应交易客户代码
    v_duedate               number(10);
    v_duedate2              number(10);
    
    v_TqHoldQty_one_B       number(10)	:= 0;     --数量统计
    v_TqHoldQty_one_S       number(10)  := 0;     --数量统计
    v_Margin_sum_B          number(15, 2) := 0;   --指定特许服务商分配对应应收保证金合计
    v_Margin_sum_S          number(15, 2) := 0;   --指定特许服务商分配对应应收保证金合计
    v_Assure_sum_B          number(15, 2) := 0;   --指定特许服务商分配对应应收担保金合计
    v_Assure_sum_S          number(15, 2) := 0;   --指定特许服务商分配对应应收担保金合计
    v_holdFunds_sum_B       number(15,2)  := 0;   --指定特许服务商分配对应应收担保金合计
    v_holdFunds_sum_S       number(15,2)  := 0;   --指定特许服务商分配对应应收担保金合计
    v_floatingloss_sum_B    number(15,2)  := 0;
    v_floatingloss_sum_S    number(15,2)  := 0;   
    v_TqHoldQty_sum         number(10)    := 0;   --调期持仓合计 

    v_Margin                number(15, 2) := 0;   --单次分配对应应收保证金
    v_Assure                number(15, 2) := 0;   --单次分配对应应收担保金
    v_holdFunds             number(15,2)  := 0;   --单次分配对应持仓市值
    v_floatingloss          number(15,2)  := 0;  
    v_swapfee               number(15,2)  := 0; 
    v_o_holdno              number(15);           --对立持仓号
    v_n_holdno              number(15);           --拆仓新仓单号
    v_F_FrozenFunds         number(15, 2);

    v_contractFactor        number(12,2) ;        --合约因子 
    v_num                   number(10);           --数量统计
    v_errorcode             number;
    v_errormsg              varchar2(200);
begin

    select status into v_result  from t_tx_holdAllotStatus for update nowait;

    if (v_result=1) then
      return -2;---已完成分配
    end if;
    
    select status into v_result  from t_systemstatus for update nowait;

    if (v_result!=1) then
      return -1;---不是闭市状态
    end if;

    --获取分配（到期天数）范围
    select duedate  into v_duedate from t_tx_duedateput for update nowait;
    v_duedate2:=v_duedate+FN_t_ComputeNextTrustDaysLater(v_duedate);

    --将原有63300555修改为从t_tx_ztxFirm表里获取到的总特许服务商 2017-3-30 11:03:28 hanqr
    select z.txfirmid into v_ztxFirm from t_tx_ztxFirm z; 
    --将原有6330055500修改为从t_customer表里获取到的总特许服务商对应的交易客户代码 
    select t.customerid into v_ztxCustomer from t_customer t where t.firmid= v_ztxFirm ;
    
    --1、判断总数量，并锁住持仓合计记录
    --for item in (select txfirmid,commodityid,firmid from t_tx_fctxf for update nowait)
    for item in ( select t1.txfirmid, t1.commodityid, t1.firmid, t2.contractFactor
                    from t_tx_fctxf t1                ,t_commodity t2
                   where t1.commodityid=t2.commodityid 
                    for update nowait)
    loop
        ---获取商品信息
        --select  contractFactor into v_contractFactor from t_commodity where commodityid = item.commodityid;
        v_contractFactor:=item.contractfactor;
        ----初始化
        v_TqHoldQty_one_B  :=  0;           --特许服务商调期已分配买数量
        v_TqHoldQty_one_S  :=  0;           --特许服务商调期已分配卖数量
        v_Margin_sum_B     :=  0;           --特许服务商分配对应应收保证金合计
        v_Margin_sum_S     :=  0;           --特许服务商分配对应应收保证金合计
        v_Assure_sum_B     :=  0;           --特许服务商分配对应应收担保金合计
        v_Assure_sum_S     :=  0;           --特许服务商分配对应应收担保金合计
        v_holdFunds_sum_B  :=  0;           --特许服务商分配对应应收担保金合计
        v_holdFunds_sum_S  :=  0;           --特许服务商分配对应应收担保金合计
        v_floatingloss_sum_B  := 0;
        v_floatingloss_sum_S  := 0;

        --按持仓时间从小到大选取持仓，进行分配
        for holdItem in (  select t2.holdqty,t2.a_holdno ,t2.f_cleardate,t2.n_tradeno ,t2.a_tradeholdno ,t2.customerid,t2.firmid ,t2.bs_flag
                                  ,t2.holdmargin,t2.holdassure,t2.price,t2.floatingloss ,t2.swapfee
                                  ,nvl(t2.n_o_closefl_one,0)  n_o_closefl_one---调期成交反记税后浮亏
                             from (select n_tradeno,a_tradeholdno,f_cleardate ,min(overdat) overdat ,count(1) cnt  --获取旧的（到期天数小）持仓
                                     from t_holdposition 
                                    where firmid = v_ztxFirm and commodityid=item.commodityid  and holdkind=1
                                    group by n_tradeno,a_tradeholdno,f_cleardate 
                                   ) t1
                                  ,t_holdposition t2
                            where t1.overdat=t2.overdat and t1.f_cleardate=t2.f_cleardate ---调期成交，成交号，每天从1开始，需加上成交日期区分
                              and t1.n_tradeno=t2.n_tradeno and t1.a_tradeholdno = t2.a_tradeholdno ---原有持仓单号和调期成交号，确认一组中立持仓  
                              and t2.totxfirmid=item.firmid and t2.commodityid=item.commodityid
                              and t2.firmid = v_ztxFirm and t1.cnt=2 and t2.holdqty>0 ---不成对的不处理,为 0 的持仓是处理过的持仓
                              and t2.overdat<v_duedate2 and t2.holdkind=1
                            order by t2.holdtime asc  for update of t2.a_holdno ---按持仓时间处理
                        )
        loop
           /******* 1 当前交易商当前商品 调期持仓持仓明细分配 *****/
           if ( holdItem.Bs_Flag= 1) then ---当前持仓是买持仓
               /****进行买持分配，复制持仓明细新建持仓分配给子特许服务商；再更新原有持仓，持仓数量及资金项;对立如是****/
               ---1 创建新仓，直接分配给对应的特许服务商
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_n_holdno from dual;
               insert into t_holdposition( a_holdno ,firmid ,customerid ,holdqty ,holdmargin ,holdassure ,floatingloss ,swapfee ,n_o_closefl_one
                                           ,commodityid ,bs_flag ,price ,openqty ,a_tradeno ,holdtime ,holdtype ,overdat ,atcleardate 
                                           ,deadline ,remainday ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate  )
               select v_n_holdno ,item.txfirmid ,item.txfirmid||'00',holdqty  ,holdmargin ,holdassure ,floatingloss,swapfee ,n_o_closefl_one
                      ,commodityid ,Bs_Flag ,price ,Openqty ,a_tradeno ,Holdtime ,holdtype ,overdat,atcleardate 
                      ,deadline ,remainday  ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate
                 from t_holdposition t
                where t.a_holdno=holdItem.a_Holdno;
               ---2 更新原有持仓 持仓数量及资金项
               update t_holdposition t set t.holdqty=0 ,holdmargin=0 ,t.holdassure=0 ,t.floatingloss=0 ,t.swapfee=0 ,t.n_o_closefl_one=0
                where t.a_holdno=holdItem.a_Holdno;
               ---3 持仓合计信息
               v_Margin_sum_B     :=  v_Margin_sum_B + holdItem.Holdmargin;
               v_Assure_sum_B     :=  v_Assure_sum_B + holdItem.Holdassure;
               v_holdFunds_sum_B  :=  v_holdFunds_sum_B + holdItem.Price*holdItem.Holdqty*v_contractFactor ;
               v_floatingloss_sum_B := v_floatingloss_sum_B+holdItem.Floatingloss;

               ---4 获取对立仓 买持仓                 
               select t.a_holdno,t.price*v_contractFactor*t.holdqty,t.holdmargin,t.holdassure,floatingloss,swapfee 
                 into v_o_holdno ,v_holdFunds ,v_Margin ,v_Assure,v_floatingloss,v_swapfee
                 from t_holdposition t
                where t.f_cleardate=holdItem.f_Cleardate  and t.n_tradeno=holdItem.n_tradeno 
                  and t.a_tradeholdno=holdItem.a_tradeholdno and t.bs_flag=2 ;
               ---5 对立仓创建新仓，直接分配给对应的特许服务商
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_n_holdno from dual;
               insert into t_holdposition( a_holdno ,firmid ,customerid ,holdqty ,holdmargin ,holdassure ,floatingloss ,swapfee ,n_o_closefl_one
                                           ,commodityid ,bs_flag ,price ,openqty ,a_tradeno ,holdtime ,holdtype ,overdat ,atcleardate 
                                           ,deadline ,remainday ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate  )
               select v_n_holdno ,item.txfirmid ,item.txfirmid||'00',holdqty  ,holdmargin ,holdassure ,floatingloss,swapfee ,n_o_closefl_one
                      ,commodityid ,Bs_Flag ,price ,Openqty ,a_tradeno ,Holdtime ,holdtype ,overdat,atcleardate 
                      ,deadline ,remainday  ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate
                 from t_holdposition t
                where t.a_holdno=v_o_holdno;
               ---6 对立仓 更新调期成交中间持仓的交易商，交易客户代号：从总特许服务商 分配给对应子特许服务商
               update t_holdposition t set t.holdqty=0 ,holdmargin=0 ,t.holdassure=0 ,t.floatingloss=0 ,t.swapfee=0 ,t.n_o_closefl_one=0
                where t.a_holdno = v_o_holdno;
               ---7 对立仓 持仓合计信息
               v_Margin_sum_S     :=  v_Margin_sum_S + v_Margin; 
               v_Assure_sum_S     :=  v_Assure_sum_S + v_Assure;
               v_holdFunds_sum_S  :=  v_holdFunds_sum_S + v_holdFunds;
               v_floatingloss_sum_S := v_floatingloss_sum_S + v_floatingloss;
               ---8 修改分配数量合计；
               v_TqHoldQty_one_B:=v_TqHoldQty_one_B+holdItem.Holdqty;
               ---9 完成分配后，反记持仓盈亏也随分配一同计入 对应特许服务商，并退换总特许服务商 反记持仓盈亏
               v_F_FrozenFunds := FN_F_UpdateFundsFull( item.txfirmid ,'15004',holdItem.n_o_Closefl_One,null,item.commodityid,null,null);
               v_F_FrozenFunds := FN_F_UpdateFundsFull( v_ztxFirm     ,'15005',holdItem.n_o_Closefl_One,null,item.commodityid,null,null);

           elsif ( holdItem.Bs_Flag= 2 ) then---当前持仓是卖持仓
                /****进行买持分配，复制持仓明细新建持仓分配给子特许服务商；再更新原有持仓，持仓数量及资金项;对立如是****/
               ---1 创建新仓，直接分配给对应的特许服务商
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_n_holdno from dual;
               insert into t_holdposition( a_holdno ,firmid ,customerid ,holdqty ,holdmargin ,holdassure ,floatingloss ,swapfee ,n_o_closefl_one
                                           ,commodityid ,bs_flag ,price ,openqty ,a_tradeno ,holdtime ,holdtype ,overdat ,atcleardate 
                                           ,deadline ,remainday ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate  )
               select v_n_holdno ,item.txfirmid ,item.txfirmid||'00',holdqty  ,holdmargin ,holdassure ,floatingloss,swapfee ,n_o_closefl_one
                      ,commodityid ,Bs_Flag ,price ,Openqty ,a_tradeno ,Holdtime ,holdtype ,overdat,atcleardate 
                      ,deadline ,remainday  ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate
                 from t_holdposition t
                where t.a_holdno=holdItem.a_Holdno;
               ---2 更新原有持仓 持仓数量及资金项
               update t_holdposition t set t.holdqty=0 ,holdmargin=0 ,t.holdassure=0 ,t.floatingloss=0 ,t.swapfee=0,t.n_o_closefl_one=0
                where t.a_holdno=holdItem.a_Holdno;
               ---3 持仓合计信息
               v_Margin_sum_S     :=  v_Margin_sum_S + holdItem.Holdmargin ; 
               v_Assure_sum_S     :=  v_Assure_sum_S + holdItem.Holdassure ;
               v_holdFunds_sum_S  :=  v_holdFunds_sum_S + holdItem.Price*holdItem.Holdqty*v_contractFactor ;
               v_floatingloss_sum_S := v_floatingloss_sum_S+holdItem.Floatingloss;

               ---4 获取对立仓 买持仓
               select t.a_holdno ,t.price*v_contractFactor*t.holdqty ,t.holdmargin ,t.holdassure ,floatingloss ,swapfee
                 into v_o_holdno ,v_holdFunds ,v_Margin ,v_Assure ,v_floatingloss ,v_swapfee
                 from t_holdposition t
                where t.f_cleardate=holdItem.f_Cleardate  and t.n_tradeno=holdItem.n_tradeno 
                  and t.a_tradeholdno=holdItem.a_tradeholdno and t.bs_flag=1 ;
               ---5 对立仓创建新仓，直接分配给对应的特许服务商
               select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_n_holdno from dual;
               insert into t_holdposition( a_holdno ,firmid ,customerid ,holdqty ,holdmargin ,holdassure ,floatingloss ,swapfee ,n_o_closefl_one
                                           ,commodityid ,bs_flag ,price ,openqty ,a_tradeno ,holdtime ,holdtype ,overdat ,atcleardate 
                                           ,deadline ,remainday ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate  )
               select v_n_holdno ,item.txfirmid ,item.txfirmid||'00',holdqty  ,holdmargin ,holdassure ,floatingloss,swapfee ,n_o_closefl_one
                      ,commodityid ,Bs_Flag ,price ,Openqty ,a_tradeno ,Holdtime ,holdtype ,overdat,atcleardate 
                      ,deadline ,remainday  ,holdkind ,totxfirmid ,a_tradeholdno ,n_tradeno ,f_cleardate
                 from t_holdposition t
                where t.a_holdno=v_o_holdno;
               ---6 对立仓 更新调期成交中间持仓的交易商，交易客户代号：从总特许服务商 分配给对应子特许服务商
               update t_holdposition t set t.holdqty=0 ,holdmargin=0 ,t.holdassure=0 ,t.floatingloss=0 ,t.swapfee=0 ,t.n_o_closefl_one=0
                where t.a_holdno = v_o_holdno;
               ---7 对立仓 持仓合计信息,不计持仓数量，最后持仓数量变化为 v_TqHoldQty_one_S+v_TqHoldQty_one_B
               v_Margin_sum_B     :=  v_Margin_sum_B + v_Margin; 
               v_Assure_sum_B     :=  v_Assure_sum_B + v_Assure;
               v_holdFunds_sum_B  :=  v_holdFunds_sum_B + v_holdFunds;
               v_floatingloss_sum_B := v_floatingloss_sum_B + v_floatingloss;
               ---8 修改分配数量;
               v_TqHoldQty_one_S:=v_TqHoldQty_one_S+holdItem.Holdqty;
               ---9 完成分配后，反记持仓盈亏也随分配一同计入 对应特许服务商，并退换总特许服务商 反记持仓盈亏
               v_F_FrozenFunds := FN_F_UpdateFundsFull(item.txfirmid,'15004',holdItem.n_o_Closefl_One,null,item.commodityid,null,null);
               v_F_FrozenFunds := FN_F_UpdateFundsFull(v_ztxFirm,'15005',holdItem.n_o_Closefl_One,null,item.commodityid,null,null);
            end if;---完成一个持仓明细分配
        end loop;---完成当前交易商当前商品的持仓分配

        ---更新持仓合计,此处更新可减少更新表（查刷内存）次数
        v_TqHoldQty_sum:=v_TqHoldQty_one_B+v_TqHoldQty_one_S;
        /*******2 当前交易商当前商品,买方向持仓持仓合计更新: 持仓、保证金、担保金、持有市值、浮亏、均价*****/
        if (v_TqHoldQty_sum>0) then ---合计大于0 表示有调期，反之无，有调期，总特许一定有持仓合计
            ---1 更新总特许服务交易客户持仓合计
            update T_CustomerHoldSum
               set holdQty    = holdQty - v_TqHoldQty_sum,
                   holdFunds  = holdFunds -v_holdFunds_sum_B,
                   HoldMargin = HoldMargin - v_Margin_sum_B,
                   HoldAssure = HoldAssure - v_Assure_sum_B,
                   floatingloss = floatingloss - v_floatingloss_sum_B,
                   evenprice  =  decode( holdQty,v_TqHoldQty_sum,0, (holdFunds -v_holdFunds_sum_B) /((holdQty - v_TqHoldQty_sum) * v_contractFactor) )
             where CustomerID = v_ztxCustomer and CommodityID = item.commodityid and bs_flag = 1;
            ---2 更新总特许服务交易商持仓合计
            update T_FirmHoldSum
               set holdQty    = holdQty - v_TqHoldQty_sum,
                   holdFunds  = holdFunds -v_holdFunds_sum_B,
                   HoldMargin = HoldMargin - v_Margin_sum_B,
                   HoldAssure = HoldAssure - v_Assure_sum_B,
                   floatingloss = floatingloss - v_floatingloss_sum_B,
                   evenprice  = decode( holdQty,v_TqHoldQty_sum,0, (holdFunds -v_holdFunds_sum_B) /((holdQty - v_TqHoldQty_sum) * v_contractFactor) )
             where Firmid = v_ztxFirm and CommodityID = item.commodityid and bs_flag = 1;

            ---3 更新子特许服务商交易客户持仓合计
            select count(*) into v_num from t_customerholdsum where commodityid = item.commodityid and firmid = item.txfirmid and bs_flag = 1;
            if v_num > 0 then
              update T_CustomerHoldSum
                 set holdQty    = holdQty + v_TqHoldQty_sum,
                     holdFunds  = holdFunds + v_holdFunds_sum_B,
                     HoldMargin = HoldMargin + v_Margin_sum_B,
                     HoldAssure = HoldAssure + v_Assure_sum_B,
                     floatingloss = floatingloss + v_floatingloss_sum_B,
                     evenprice  = (holdFunds + v_holdFunds_sum_B) /((holdQty + v_TqHoldQty_sum) * v_contractFactor)
               where CustomerID = item.txfirmid||'00' and CommodityID = item.commodityid and bs_flag = 1;
            else
              insert into T_CustomerHoldSum (CustomerID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,FrozenQty,HoldMargin,HoldAssure, FirmID)
              values(item.txfirmid||'00',item.commodityid,1,v_TqHoldQty_sum, v_holdFunds,0,(v_holdFunds) /(v_TqHoldQty_sum * v_contractFactor),0,v_Margin, v_Assure,item.txfirmid);
            end if;

            ---4 更新子特许服务商交易商持仓合计表
            select count(*) into v_num from T_FirmHoldSum where commodityid = item.commodityid and firmid = item.txfirmid and bs_flag = 1;
            if v_num > 0 then
              update T_FirmHoldSum
                 set holdQty    = holdQty + v_TqHoldQty_sum,
                     holdFunds  = holdFunds + v_holdFunds_sum_B,
                     HoldMargin = HoldMargin + v_Margin_sum_B,
                     HoldAssure = HoldAssure + v_Assure_sum_B,
                     floatingloss = floatingloss + v_floatingloss_sum_B,
                     evenprice  = (holdFunds + v_holdFunds_sum_B) /((holdQty + v_TqHoldQty_sum) * v_contractFactor)
               where FirmID = item.txfirmid and CommodityID = item.commodityid and bs_flag = 1;
            else
              insert into T_FirmHoldSum(FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
              values(item.txfirmid,item.commodityid,1,v_TqHoldQty_sum, v_holdFunds,0,(v_holdFunds) /(v_TqHoldQty_sum * v_contractFactor),v_Margin, v_Assure);
            end if;
        end if;---（调期特许服务商）买持仓合计信息更新

        /*******3 当前交易商当前商品,卖方向持仓持仓合计更新: 持仓、保证金、担保金、持有市值、浮亏、均价  *****/
        if ( v_TqHoldQty_sum > 0 ) then ---合计大于0表示有调期，反之无，有调期，总特许一定有持仓合计
            ---1 更新总特许服务交易客户持仓合计
            update T_CustomerHoldSum
               set holdQty    = holdQty - v_TqHoldQty_sum,
                   holdFunds  = holdFunds - v_holdFunds_sum_S,
                   HoldMargin = HoldMargin - v_Margin_sum_S,
                   HoldAssure = HoldAssure - v_Assure_sum_S,
                   floatingloss = floatingloss - v_floatingloss_sum_S,
                   evenprice  = decode( holdQty,v_TqHoldQty_sum,0, (holdFunds - v_holdFunds_sum_S) /((holdQty - v_TqHoldQty_sum) * v_contractFactor) )
             where CustomerID = v_ztxCustomer and CommodityID = item.commodityid and bs_flag = 2;
            ---2 更新总特许服务交易商持仓合计
            update T_FirmHoldSum
               set holdQty    = holdQty - v_TqHoldQty_sum,
                   holdFunds  = holdFunds - v_holdFunds_sum_S,
                   HoldMargin = HoldMargin - v_Margin_sum_S,
                   HoldAssure = HoldAssure - v_Assure_sum_S,
                   floatingloss = floatingloss - v_floatingloss_sum_S,
                   evenprice  = decode( holdQty,v_TqHoldQty_sum,0, (holdFunds - v_holdFunds_sum_S) /((holdQty - v_TqHoldQty_sum) * v_contractFactor) )
             where Firmid = v_ztxFirm and CommodityID = item.commodityid and bs_flag = 2;

            ---3 更新子特许服务商交易客户持仓合计
            select count(*) into v_num from t_customerholdsum where commodityid = item.commodityid and firmid = item.txfirmid and bs_flag = 2;
            if v_num > 0 then
              update T_CustomerHoldSum
                 set holdQty    = holdQty + v_TqHoldQty_sum,
                     holdFunds  = holdFunds + v_holdFunds_sum_S,
                     HoldMargin = HoldMargin + v_Margin_sum_S,
                     HoldAssure = HoldAssure + v_Assure_sum_S,
                     floatingloss = floatingloss + v_floatingloss_sum_S,
                     evenprice  = (holdFunds + v_holdFunds_sum_S) /((holdQty + v_TqHoldQty_sum) * v_contractFactor)
               where CustomerID = item.txfirmid||'00' and CommodityID = item.commodityid and bs_flag = 2;
            else
              insert into T_CustomerHoldSum (CustomerID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,FrozenQty,HoldMargin,HoldAssure, FirmID)
              values(item.txfirmid||'00',item.commodityid,2,v_TqHoldQty_sum, v_holdFunds,0,(v_holdFunds) /(v_TqHoldQty_sum * v_contractFactor),0,v_Margin, v_Assure,item.txfirmid);
            end if;

            ---4 更新子特许服务商交易商持仓合计表
            select count(*) into v_num from T_FirmHoldSum where commodityid = item.commodityid and firmid = item.txfirmid and bs_flag = 2;
            if v_num > 0 then
              update T_FirmHoldSum
                 set holdQty    = holdQty + v_TqHoldQty_sum,
                     holdFunds  = holdFunds + v_holdFunds_sum_S,
                     HoldMargin = HoldMargin + v_Margin_sum_S,
                     HoldAssure = HoldAssure + v_Assure_sum_S,
                     floatingloss = floatingloss + v_floatingloss_sum_S,
                     evenprice  = (holdFunds + v_holdFunds_sum_S) /((holdQty + v_TqHoldQty_sum) * v_contractFactor)
               where FirmID = item.txfirmid and CommodityID = item.commodityid and bs_flag = 2;
            else
              insert into T_FirmHoldSum(FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
              values(item.txfirmid,item.commodityid,2,v_TqHoldQty_sum, v_holdFunds,0,(v_holdFunds) /(v_TqHoldQty_sum * v_contractFactor),v_Margin, v_Assure);
            end if;
        end if;---（调期特许服务商）卖持仓合计信息更新

    end loop;

    update t_tx_holdAllotStatus t set t.status=1; 
    
    return 1;
    
    exception
      when OTHERS then
          v_errorcode:=sqlcode;
          v_errormsg :=sqlerrm;
          rollback;
          insert into T_DBLog(err_date,name_proc,err_code,err_msg)
          values(sysdate,'FN_T_TqAllocateRelated',v_errorcode,v_errormsg);
          commit;
    return -100;
end;
/

