CREATE VIEW V_H_TRADE2 AS
  select CLEARDATE,
       Q.A_TRADENO,
       A_ORDERNO,
       TRADETIME,
       CUSTOMERID,
       COMMODITYID,
       BS_FLAG,
       case
         when ORDERTYPE = 1 then
          '订立'
         else
          case
            when timeflag = 1 then
             '转让'
            when timeflag = 2 then
             '调期转让'
            else
             '转让'
          end
       end ORDERTYPE,
       PRICE,
       QUANTITY,
       CLOSE_PL,
       TRADEFEE,
       SWAPFEE,
       TRADETYPE,
       HOLDPRICE,
       HOLDTIME,
       FIRMID,
       CLOSEADDEDTAX,
       FIRMNAME,
       Q.OPPCUSTOMERID,
       TIMEFLAG,
       ATCLEARDATE,
       TRADEATCLEARDATE,
       Q.OPPCUSTOMERNAME
  from (select a.*, m.name FirmName, a.oppFirmId oppCustomerID, o.timeflag ,om.name OPPCUSTOMERNAME
          from T_H_TRADE a, M_firm m, t_h_orders o ,M_firm om
         where m.firmID = a.firmID and om.firmid=a.oppfirmid
           and a.a_orderno = o.a_orderno
         order by a.firmID, a.a_orderno) Q
/

