CREATE VIEW V_T_E_APPLYTREATYSETTLE AS
  select aaa."APPLYID",aaa."COMMODITYID",aaa."CUSTOMERID_S",aaa."CUSTOMERID_B",aaa."PRICE",aaa."QUANTITY",aaa."STATUS",aaa."CREATETIME",aaa."CREATOR"
       ,aaa."REMARK1",aaa."MODIFYTIME",aaa."MODIFIER",aaa."REMARK2",aaa.holdno_s,aaa.holdno_b,aaa.settletype,aaa.settleprice
       ,mmm.name b_name,ccc.s_name s_name
  from T_E_ApplyTreatySettle aaa,
       m_firm mmm,
       (select b.s_applyid s_applyid, m.name s_name
          from m_firm m,
               (select t.applyid s_applyid, c.firmid s_firmid
                  from T_E_ApplyTreatySettle t, t_customer c
                 where t.customerid_s = c.customerid) b
         where m.firmid = b.s_firmid) ccc,
        (select bb.firmid b_firmid,a.applyid applyid from T_E_ApplyTreatySettle a,t_customer bb where a.customerid_b = bb.customerid) ddd
  where mmm.firmid = ddd.b_firmid
  and   ddd.applyid = aaa.applyid
  and   aaa.applyid = ccc.s_applyid
/

