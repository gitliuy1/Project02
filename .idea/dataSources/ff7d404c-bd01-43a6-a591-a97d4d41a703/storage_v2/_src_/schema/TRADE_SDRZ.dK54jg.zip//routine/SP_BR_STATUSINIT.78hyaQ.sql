CREATE procedure sp_br_statusinit(
p_ClearDate Date  --初始化日期
)
as
/*********************
 佣金结算状态初始化存储
 存储说明：凡是需要进行多级佣金结算的系统 初始化时均要使用

**********************/
v_status br_r_systemstatus.status%type;
v_trade_date br_r_systemstatus.b_date%type;

begin
  --1.检查财务系统交易状态
  begin
     select status ,t.b_date into v_status ,v_trade_date  from br_r_systemstatus t where rownum < 2;
  exception
     when NO_DATA_FOUND then
       return;---表中有数据表示启用多级返佣 返佣结算;反之 未启用多级返佣 返佣结算 yuansr 2017 02 24
  end;
  --2.如果状态不为结算完成状态，即返回
  if(v_status <> 5) then
    return;
  end if;
  
  --取佣金结算下一个交易日
  --select min(t.day) nextTradeDay into v_trade_date from t_tradedays t where t.day>v_trade_date;
  select t.tradedate into v_trade_date from t_systemstatus t;

  --3.如果状态为结算完成，即修改状态为未结算
  update br_r_systemstatus set b_date=trunc(p_ClearDate) ,status = 0,note = '未结算',cleartime=sysdate ;
  update br_r_clearstatus set status = 'N',updatetime  = sysdate;
end;
/

