CREATE function FN_T_GageQty(
    --p_ApplyID        number,     --申请单号 modify by yukx 20100421
    p_CommodityID varchar2, --商品代码
    p_BS_Flag        number,    --买卖标志，目前只有卖方
    p_CustomerID     varchar2,     --客户ID
    --p_BillID         varchar2, --仓单号 modify by yukx 20100421
    --p_Modifier       varchar2,   --创建人 modify by yukx 20100421
    p_Quantity       number   --仓单数量
) return number
/****
 * 抵顶
 * 返回值
 * 1 成功
 * 2 已处理过
 * -1  抵顶时超出可抵顶数量
 * -2  抵顶数量大于持仓数量
 * -3  抵顶数量大于可用数量
 * -4  没有对应的生效仓单抵顶记录
 * -100 其它错误
****/
as
	v_version varchar2(10):='1.0.3.1';
    v_CommodityID varchar2(16);
    v_FirmID     varchar2(32);
    v_BS_Flag        number(2);
    v_price          number(15,2);
    v_frozenQty      number(10);
    v_holdQty        number(10);
    v_Margin         number(15,2):=0;   --应收保证金
	v_Assure         number(15,2):=0;   --应收担保金
    v_A_HoldNo       number(15);
    v_HoldSumQty     number(10);
    v_MarginPriceType       number(1);
    v_ContractFactor T_Commodity.ContractFactor%type;
    v_errorcode      number;
    v_errormsg       varchar2(200);
    v_MarginPrice    number(15,2);  --计算成交保证金的价格
	v_HoldFunds    number(15,2):=0;  --平仓时应退持仓金额
    v_unCloseQty     number(10):=p_quantity; --未平数量，用于中间计算
    v_margin_one     number(15,2);   --用于中间计算
	v_Assure_one     number(15,2);   --用于中间计算
    v_tradedAmount   number(10):=0;  --成交数量
	v_CustomerID        varchar2(40);
	v_CloseAlgr           number(2);
	v_orderby  varchar2(100);
	v_F_FrozenFunds   number(15,2);
	type c_HoldPosition is ref cursor;
	v_HoldPosition c_HoldPosition;
	v_sql varchar2(1000);
	v_num            number(10);
	v_FL_ret            timestamp;
	v_AtClearDate          date;
	v_closeTodayHis        number(2);    --平今仓还是历史仓(0平今仓；1平历史仓)
	v_YesterBalancePrice    number(15,2);
	v_TradeDate date;
	v_GageMode number(2);--抵顶模式，分0全抵顶和1半抵顶，半抵顶时要计算浮亏，2009-10-14
  v_AvailableQuantity number(10);--可用数量 add by yukx 20100507
  v_overdat               number(10);   --合约到期天数 yuansr 2016 10 09
  
  
  --新加变量 2019年3月4日liuyang
  v_seq_OrderNo          number(30,2);--委托单号
  v_seq_TradeNo          number(15); --成交单号
  v_mtn_opp1             NUMBER(15);--最大成交单号
  v_customerName         VARCHAR2(64);-- 客户名称
  v_commodityName        VARCHAR2(40);-- 商品名称
begin
     -- modify by yukx 20100421
	    --select count(*) into v_num from T_ValidBill where BillID = p_BillID and Status=1;
	    --if(v_num >0) then
	    --   rollback;
	    --    return 2;  --已处理过
	    --end if;

      --验证抵顶数量与可用数量 add by yukx 20100507
      --申请时数量已冻结，此时只需验证冻结数量是否满足，原：v_AvailableQuantity=Quantity-FrozenQty  20131211 by jwh
      begin
        select FrozenQty into v_AvailableQuantity from T_ValidGageBill
        where FirmID=(select FirmID from T_Customer where CustomerID=p_CustomerID)
          and commodityID=p_CommodityID;
        exception
          when NO_DATA_FOUND then
  	      return -4;--没有对应的生效仓单抵顶记录
      end;

      if(v_AvailableQuantity<p_Quantity) then
        return -3;--抵顶数量大于可用数量
      end if;

		v_CustomerID := p_CustomerID;
	    v_CommodityID := p_CommodityID;
        v_BS_Flag := p_BS_Flag;
        --获取平仓算法，保证金计算类型,合约因子
        select CloseAlgr,GageMode into v_CloseAlgr,v_GageMode from T_A_Market;
        select MarginPriceType,ContractFactor,LastPrice into v_MarginPriceType,v_ContractFactor,v_YesterBalancePrice from T_Commodity where CommodityID=v_CommodityID;
		select TradeDate into v_TradeDate from T_SystemStatus;

     begin
      select holdqty, frozenqty  into v_HoldSumQty, v_frozenQty from T_CustomerHoldSum
        where CustomerID = v_CustomerID
          and CommodityID = v_CommodityID
          and bs_flag = v_BS_Flag for update;
        exception
        when NO_DATA_FOUND then
  	     return -13;--未查询到对应持仓数量
      end;

      --申请时数量已冻结，此时只需验证冻结数量是否满足，原验证： p_quantity > v_HoldSumQty-v_frozenqty 20131211 by jwh
        if(p_quantity > v_frozenqty) then
            rollback;
            return -1;
        end if;
    	--遍历持仓明细的数量并过滤掉指定平仓冻结的数量
        --根据平仓算法(0先开先平；1后开先平；2持仓均价平仓(不排序)选择排序条件
        if(v_CloseAlgr = 0) then
	        v_orderby := ' order by a.A_HoldNo ';
	    elsif(v_CloseAlgr = 1) then
	        v_orderby := ' order by a.A_HoldNo desc ';
	    end if;


    	v_sql := 'select a.overdat, a.a_holdno,FirmID,price,(a.HoldQty-nvl(b.FrozenQty,0)),a.AtClearDate from T_holdposition a,(select A_HoldNo,nvl(sum(FrozenQty),0) FrozenQty from T_SpecFrozenHold group by A_HoldNo) b ' ||
                 ' where (a.HoldQty+a.GageQty) > 0 and a.A_HoldNo=b.A_HoldNo(+) and nvl(b.FrozenQty,0)<a.HoldQty and CustomerID=''' || v_CustomerID ||
                 ''' and CommodityID =''' || v_CommodityID || ''' and bs_flag = ' || v_BS_Flag || v_orderby;

            open v_HoldPosition for v_sql;
            loop
                fetch v_HoldPosition into v_overdat,v_a_holdno, v_FirmID, v_price, v_holdqty,v_AtClearDate;
                exit when v_HoldPosition%NOTFOUND;
                if(v_holdqty<=v_unCloseQty) then
                    v_tradedAmount:=v_holdqty;
                else
                    v_tradedAmount:=v_unCloseQty;
                end if;

                --计算应退保证金，根据设置选择开仓价还是昨结算价来算
				if(v_MarginPriceType = 1) then
			        v_MarginPrice := v_YesterBalancePrice;
			    elsif(v_MarginPriceType = 2) then
					--判断是平今仓还是平历史仓
				    if(trunc(v_TradeDate) = trunc(v_AtClearDate)) then
				        v_closeTodayHis := 0;
				    else
				    	v_closeTodayHis := 1;
				    end if;
					if(v_closeTodayHis = 0) then  --平今仓
						v_MarginPrice := v_price;
					else  --平历史仓
				        v_MarginPrice := v_YesterBalancePrice;
				    end if;
				else  -- default type is 0
					v_MarginPrice := v_price;
				end if;

                --v_Margin_one := FN_T_ComputeMargin(v_FirmID,v_CommodityID,v_BS_Flag,v_tradedAmount,v_MarginPrice);
                v_Margin_one := FN_T_ComputeMarginPlus(v_FirmID,v_CommodityID,v_BS_Flag,v_overdat,v_tradedAmount,v_MarginPrice);
                if(v_Margin_one < 0) then
                    Raise_application_error(-20040, 'computeMargin error');
                end if;
		        --计算担保金
		        --v_Assure_one := FN_T_ComputeAssure(v_FirmID,v_CommodityID,v_BS_Flag,v_tradedAmount,v_MarginPrice);
            v_Assure_one := FN_T_ComputeAssurePlus(v_FirmID,v_CommodityID,v_BS_Flag,v_overdat,v_tradedAmount,v_MarginPrice);
		        if(v_Assure_one < 0) then
		            Raise_application_error(-20041, 'computeAssure error');
		        end if;
		        --保证金应加上担保金
		        v_Margin_one := v_Margin_one + v_Assure_one;

                v_Margin:=v_Margin + v_Margin_one;
                v_Assure:=v_Assure + v_Assure_one;
	            --计算应退持仓金额
	            v_HoldFunds := v_HoldFunds + v_tradedAmount*v_price*v_ContractFactor;
              
              ------------------------------------------------ 添加成交信息 2019年3月4日 liuyang start---------------------------------------------------------
              --获取交易商名称
              select t.name into v_customerName from m_firm t where t.firmid=v_FirmID; 
              --获取商品名称
              select t.name into v_commodityName from t_commodity t where t.commodityid = v_CommodityID;
              select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_mtn_opp1 from dual;

              --- 获取委托单号
              select FN_T_ComputeOrderNo(SEQ_T_Orders.nextval) into v_seq_OrderNo from dual;
              select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_seq_TradeNo from dual;
               --平仓    -- 持仓过户tradeType := 15
              insert into T_S_Trade (a_tradeno,  m_tradeno,    a_orderno,a_tradeno_closed,tradetime,Firmid,CommodityID,             bs_flag       ,ordertype,  price,      quantity, close_pl,o_close_PL, tradefee, TradeType,HoldPrice, HoldTime,CustomerID,  CloseAddedTax,  M_TradeNo_Opp, AtClearDate,   TradeAtClearDate,  oppFirmid,                        swapfee                          ,openorclosetype,ocflag,unfrozenFunds,unfrozenFee,tradeMargin,stamptax,fundAcctount,  customerName,o_customerID,o_fundAcctount,   holdNo, o_holdNo,matchNo,matchNo_opp,o_tradeNo,o_orderNo,     ordersqty,  openDateTime,  Commodityname,            Describe       ,F_CLEARDATE)
              select             v_seq_TradeNo, v_mtn_opp1,v_seq_OrderNo,       a_tradeno,holdtime, Firmid,commodityid,decode(bs_flag ,1 ,2 ,2 ,1),    2,      price,v_tradedAmount,     0,        0,      0,           1,       price,  HoldTime,  Firmid,        0,             v_mtn_opp1, AtClearDate,    AtClearDate,        Firmid ,decode(decode(atcleardate,f_cleardate,1,0) ,1,0 ,swapfee),    300     ,       2,          0,         0,          0,         0,       Firmid ,v_customerName,      Firmid,        Firmid, a_holdno,     null,   null,     null,       null,    null ,v_tradedAmount,      holdtime,v_commodityName,    'FN_T_GageQty  平仓_01',F_CLEARDATE
              from t_holdposition t where t.a_holdno=v_a_holdno;
              ------------------------------------------------ 添加成交信息 2019年3月4日 liuyang end---------------------------------------------------------

                --更新持仓记录
		        update T_holdposition
                set holdqty = holdqty - v_tradedAmount,HoldMargin=HoldMargin-v_Margin_one,HoldAssure=HoldAssure-v_Assure_one,GageQty=GageQty+v_tradedAmount
                where a_holdno = v_a_holdno;
                v_unCloseQty:=v_unCloseQty - v_tradedAmount;
                exit when v_unCloseQty=0;
            end loop;
            close v_HoldPosition;
            if(v_unCloseQty>0) then --抵顶数量大于持仓数量，出错
                rollback;
                return -2;
            end if;

        --调用减少交易客户，交易商的持仓合计信息存储，注意参数值与减少持仓不一样   2009-10-15
        if(v_GageMode=1) then
        	v_num := FN_T_SubHoldSum(p_quantity,-p_quantity,v_Margin,v_Assure,v_CommodityID,v_ContractFactor,v_BS_Flag,v_FirmID,0,v_CustomerID,0,v_GageMode,p_quantity);
		else
			v_num := FN_T_SubHoldSum(p_quantity,-p_quantity,v_Margin,v_Assure,v_CommodityID,v_ContractFactor,v_BS_Flag,v_FirmID,v_HoldFunds,v_CustomerID,0,v_GageMode,p_quantity);
		end if;

        --更新保证金和担保金
        update T_Firm
        set runtimemargin = runtimemargin - v_Margin,
            RuntimeAssure = RuntimeAssure - v_Assure
        where Firmid = v_FirmID;
        --更新冻结资金，释放个人部分的保证金
		v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_FirmID,-(v_Margin-v_Assure),'15');

        --modify by yukx 20100421
        --插入生效仓单表
        --insert into T_ValidBill
        --    (ValidID,               ApplyID, CommodityID,   FirmID_S, CustomerID_S,BillID,  Quantity,  BillType,  Status,CreateTime,Creator)
        --values
        --    (SEQ_T_ValidBill.nextval,p_ApplyID,v_CommodityID, v_FirmID, v_CustomerID,p_BillID,p_Quantity,    1,        1  ,  sysdate,  p_Modifier);
        update T_ValidGageBill set Quantity=Quantity-p_Quantity,FrozenQty=FrozenQty-p_Quantity where FirmID=v_FirmID
               and commodityID=p_CommodityID;

    commit;
    --提交后计算此交易商浮亏
    v_FL_ret := FN_T_UpdateFloatingLoss(null,null,null);

    return 1;
exception
    when OTHERS then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_T_GageQty',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

