CREATE function FN_F_IntsTradeLogFunds
return number
/**
 *add by lyf 20150820
 *从高达取来的数据，生成流水
 *返回值1 生成流水成功 2.没有数据，-100失败
**/
is
  v_beginDate date;
  v_Balance f_firmfunds.balance%type;
  v_cnt number(10);
  v_rtn number(10);
  v_errorcode      number;
  v_errormsg       varchar2(200);
begin
  select tradedate into v_beginDate from t_systemstatus;
  select count(*) into v_cnt from f_tradelog_funds  where trunc(createtime)<=v_beginDate and flag=0;
  if v_cnt>0 then
     for pFirmid in (select * from f_tradelog_funds where trunc(createtime)<=v_beginDate and flag=0) loop
     -- dbms_output.put_line('type   '||pFirmid.type);
     -- dbms_output.put_line('firmid     '||pFirmid.firmid);
        if pFirmid.type=1 then   --付货款
            v_Balance := FN_F_UpdateFundsFull_GD(pFirmid.firmid,'31003',pFirmid.amount,null,'gdcmd',null,null);
        elsif pFirmid.type=2 then  --收货款

            v_Balance := FN_F_UpdateFundsFull_GD(pFirmid.firmid,'31002',pFirmid.amount,null,'gdcmd',null,null);
        elsif pFirmid.type=3 then  --收手续费
            v_Balance := FN_F_UpdateFundsFull_GD(pFirmid.firmid,'31001',pFirmid.amount,null,null,null,null);
        else
           insert into T_DBLog(err_date,name_proc,err_code,err_msg)
            values(sysdate,'FN_F_IntsTradeLogFunds',v_errorcode,v_errormsg);
           return -100;
        end if;
        update f_tradelog_funds set flag=1,modifytime=trunc(sysdate) where firmid=pFirmid.firmid;
     end loop;
     return 1;
   end if;
  return 2;
/*exception
   when others then
      rollback;
      insert into T_DBLog(err_date,name_proc,err_code,err_msg)
        values(sysdate,'FN_F_IntsTradeLogFunds',v_errorcode,v_errormsg);
      return -100;*/
end;
/

