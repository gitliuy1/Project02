CREATE VIEW V_T_SETTLEDATA AS
  select "MATCHID","COMMODITYID","QUANTITY","FIRMID_B","NAME_B","FIRMID_S","NAME_S","STATUS","RESULT","SETTLETYPE","SETTLEDATE" ,"CREATETIME"
       ,"PRICE"  ,"SETTLEPRICE"
  from ( select 'aa'||t1.matchId as matchId,t1.commodityId ,t1.quantity ,t1.firmid_b ,t2.name name_b ,t1.firmid_s ,t3.name name_s
                ,t1.status ,t1.result, t1.settletype,t1.settledate ,t1.createtime ,0 price ,0 settleprice
           from T_SettleMatch t1  ,m_firm t2 ,m_firm t3
          where t1.firmid_b=t2.firmid and t1.firmid_s=t3.firmid
       )
       union all
       ( select 'bb'||t1.applyid||'' as matchId ,t1.commodityId ,t1.quantity ,t2.firmid firmid_b ,t2.name name_b ,t3.firmid firmid_s
                ,t3.name name_s ,t1.status ,null  result ,5+t1.settletype as settletype, t1.createtime settledate ,t1.createtime
                ,t1.price ,t1.settleprice
           from T_E_ApplyTreatySettle t1
                ,(select tt1.customerid ,tt1.firmid,tt2.name  from t_customer tt1 ,m_firm tt2  where  tt1.firmid=tt2.firmid) t2
                ,(select tt1.customerid ,tt1.firmid,tt2.name  from t_customer tt1 ,m_firm tt2  where  tt1.firmid=tt2.firmid) t3
          where t1.customerid_b=t2.customerid and t1.customerid_s=t3.customerid
       )
/

