CREATE VIEW V_T_DIRECTFIRMBREED AS
  select d.breedId breedId, --品种代码
 d.firmId firmId, --交易商代码
 a.breedname --品种名称
   from T_E_DirectFirmBreed d, t_a_breed a
  where d.breedId = a.breedId
/

