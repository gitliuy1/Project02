CREATE VIEW V_STOCKID AS
  select nvl(t1.stockid,t2.stockid) stockid
from bi_stock t1 full join bi_stockapply t2
on t1.stockid=t2.stockid
where  t1.stockid is not null or t2.stockid is not null
/

