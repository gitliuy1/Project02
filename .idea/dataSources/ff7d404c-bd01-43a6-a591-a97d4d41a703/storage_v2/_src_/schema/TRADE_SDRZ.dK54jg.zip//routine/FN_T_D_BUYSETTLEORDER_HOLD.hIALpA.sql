CREATE function FN_T_D_BuySettleOrder_hold(p_FirmID           varchar2,    --交易商ID
                                                      p_TraderID         varchar2,    --交易员ID
                                                      p_CommodityID      varchar2,    --商品ID
                                                      p_Quantity         number,      --数量
                                                      p_Price            number,      --委托价格，行情结算价
                                                      p_CustomerID       varchar2,    --交易客户ID
                                                      p_ConsignerID      varchar2,    --代为委托员ID
                                                      p_TradeMargin_B    number,      --应退买方交易保证金
                                                      p_DelayQuoShowType number,      --延期行情显示类型，0：交收申报结束和中立仓申报结束显示； 1：实时显示；
                                                      p_delayMoney       number,      --申报金额
                                                      p_a_holdno         number,      --add by lyf 20160801 指定持仓单号
                                                      p_aholdFlag        number,       --add by lyf 20160801 是否指定持仓单号交收     ‘1’否  ， ‘2’是
                                                      p_p_txFirmId       varchar2,     --特许服务商ID
                                                      p_goodsId          number,       --意向货种id
                                                      p_placeId          number        --意向交收地id
                                                      ) return number
/****
   * add by lyf 20160801
   * 指定持仓买交收申报委托
   * 返回值
   * >0  成功提交，并返回委托单号
   * -1  持仓不足
   * -2  资金余额不足
   * -99  不存在相关数据
   * -100 其它错误
   *  修改： 委托完成后，冻结持仓合计后，持仓明细可用数量为持仓数量减去冻结数量(平仓委托冻结和申报委托冻结) 
   *        参照交易平仓 冻结持仓明细（直接更新持仓明细——会影响均价计算），抵顶数量可用于交收申报  yuansr 2016 10 20
  ****/
 as
  v_version                 varchar2(10) := '1.0.2.2';
  v_HoldSum                 number(10);                       --持仓合计数量
  v_Payout_BSum             number(15, 2) := 0;               --买方向交收货款汇总
  v_SettleMargin_BSum       number(15, 2) := 0;               --买方交收保证金汇总
  v_TradeMargin_BSum        number(15, 2) := 0;               --买方交易保证金汇总
  v_F_Funds                 number(15, 2) := 0;               --应冻结资金
  v_A_Funds                 number(15, 2);                    --可用资金
  v_F_FrozenFunds           number(15, 2);                    --财务冻结资金
  v_A_OrderNo               number(15);                       --委托单号
  v_errorcode               number;
  v_errormsg                varchar2(200);
  v_DelaySettlePriceType    number(10);                       --交收申报交收类型 0：按结算价交收申报 ， 1：按订立价交收  -- add  by zhangjian
  v_price                   number(15, 6);                    -- 交收申报价格
  v_tempQty                 number(15) := 0;                  --中间变量
  v_orderLogNo              number(15) := 0;                  --委托下单日志 ID。
  v_orderSumLogNo           number(15) := 0;                  --委托下单日志合计数据 ID
  v_A_OrderNo_L             number(15);                       --临时委托单号
  v_holdEvenPrice           number(15,6);                     --持仓均价,订立均价
  v_Overdat                 number(10);                       -- 到期天数
  v_Fee                     number(15, 2) := 0;               ---合计交收手续费 yuansr 2017 08 24
begin

  --1 、检查持仓，并锁住持仓合计记录
  begin
    select nvl(a.gageqty +a.HoldQty-nvl(b.FrozenQty,0)-nvl(c.FrozenQty,0) , 0) ,price,nvl(a.overdat,0)  into v_HoldSum,v_price,v_Overdat
      from t_holdposition a,(select A_HoldNo,sum(frozenqty) frozenqty from T_SpecFrozenHold group by A_HoldNo) b 
           ,(select A_HoldNo,sum(frozenqty - unfrozenqty) FrozenQty from T_S_OrderFrozenHold where bs_flag = 1 group by A_HoldNo ) c---有效冻结=冻结-解冻
     where a.A_HoldNo=b.A_HoldNo(+) and a.A_HoldNo=c.A_HoldNo(+) 
       and a.CustomerID = p_CustomerID and a.a_holdno = p_a_holdno and a.CommodityID = p_CommodityID and a.bs_flag = 1
       for update of a.a_holdno;
  exception
    when NO_DATA_FOUND then
      rollback;
      return - 1; --持仓不足
  end;
  if (v_HoldSum < p_Quantity) then
      rollback;
      return - 31; --持仓不足
  end if;

  --创建临时委托代号
  select SEQ_T_S_OrderFrozenHold.nextval into v_A_OrderNo_L from dual;
  --2 、添加冻结持仓记录，计算交易保证金、货款、交收保证金 add by yuansr 2016 10 20
  insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty )
  values ( v_A_OrderNo_L  ,p_a_holdno    ,1   ,p_Quantity   ,p_Quantity     ,0     );
  v_holdEvenPrice:=v_price;--指定持仓，持仓价即冻结持仓的均价
  v_price:= p_delayMoney;-- modify by lyf 20160810 修改申报时候冻结保证金用申报金额来计算
  --计算交收货款
  v_Payout_BSum        := FN_T_ComputePayout(p_FirmID,  p_CommodityID,   1,      p_Quantity,   v_price);
  --计算交收保证金 modify by lyf 20160810 修改交收保证金计算价格去交收申请价格
  v_SettleMargin_BSum  := FN_T_ComputeSettleMargin_ZSS(p_FirmID,   p_CommodityID, 1,   p_Quantity,  v_price);
  --交易保证金必须使用计算交易保证金的交易保证金——只有计算所得才是对应阶段的交易保证金 yuansr 2016 10 25
  v_TradeMargin_BSum  := FN_T_ComputeMargin_ZSSPlus(p_FirmID,  p_CommodityID, 1,v_Overdat,p_Quantity, v_price);
  ---交收手续费 yuansr 2017 08 24
  v_Fee := FN_T_ComputeSettleFee(p_FirmID,p_CommodityID,  1,p_Quantity , v_price);
    
  --3 、根据交收申报价格类型 判断如何冻结资金。0：按结算价交收 ；1：按订立价交收  mod by zhangjian
  v_price := p_delayMoney;--v_price:=p_Price;   modify by lyf 20160810 修改申报时候冻结保证金用申报金额来计算
  select   DelaySettlePriceType into v_DelaySettlePriceType from t_commodity where commodityid=p_CommodityID;
  if(v_DelaySettlePriceType=1) and v_holdEvenPrice>0 then -- 如果是按订立价交收
    v_price:=v_holdEvenPrice;
  end if;

  --应冻结资金
  v_F_Funds := v_Payout_BSum + v_SettleMargin_BSum - v_TradeMargin_BSum+v_Fee;---增加冻结交收手续费 yuansr 2017 08 24;
  --计算可用资金，并锁住财务资金
  v_A_Funds := FN_F_GetRealFunds(p_FirmID, 1);

  --插入延期委托合计表日志   --add by zhangjian  2012年3月2日
  select SEQ_T_D_OrderSumLog.nextval into v_orderSumLogNo from dual;
  insert into T_D_DelayOrderSumLog
  values ( v_orderSumLogNo,     p_firmid,     1,     p_CommodityID,     v_price,     p_Quantity,     v_SettleMargin_BSum,     p_TradeMargin_B
          ,v_Payout_BSum,     v_A_Funds,     v_F_Funds,     Sysdate,     p_a_holdno||'-指定交收-'||p_aholdFlag );

  if (v_A_Funds < v_F_Funds) then
    rollback;
    return - 2; --资金余额不足
  end if;
  --4 、更新交易客户持仓合计的冻结数量 
  update T_CustomerHoldSum
     set frozenQty = frozenQty + p_Quantity
   where CustomerID = p_CustomerID     and CommodityID = p_CommodityID  and bs_flag = 1;
  --5 、更新冻结资金
  v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID, v_F_Funds, '15');
  --6 、插入延期委托表，并返回委托单号
  select SEQ_T_DelayOrders.nextval into v_A_OrderNo from dual;
  insert into T_DelayOrders ( a_orderno  ,  CommodityID, CustomerID ,traderid,bs_flag,DelayOrderType,status, quantity, price, tradeqty,frozenfunds
                              ,unfrozenfunds,  ordertime, withdrawtime, ordererip,  signature, FirmID, ConsignerID, delayMoney, a_holdno, aHoldFlag,Txfirmid,GoodsId,PlaceId )
  values ( v_A_OrderNo,     p_CommodityID,     p_CustomerID,     p_TraderID,     1,     1,     1,     p_Quantity,     v_price,     0,     v_F_Funds
           ,    0,     sysdate,     null,     null,     null,     p_FirmID,     p_ConsignerID,     p_delayMoney,     p_a_holdno,     p_aholdFlag,  p_p_txFirmId, p_goodsId, p_placeId );
  --7 、更新 交收申报委托持仓关系表 ：使用委托单号替换 临时委托代号
  update T_S_OrderFrozenHold t set t.a_orderno=v_A_OrderNo  where t.a_orderno=v_A_OrderNo_L;
  --8 、行情实时显示则要更新行情
  if (p_DelayQuoShowType = 1) then
    update T_DelayQuotation
       set BuySettleQty = BuySettleQty + p_Quantity, CreateTime = sysdate
     where CommodityID = p_CommodityID;
  end if;

  commit;
  return v_A_OrderNo;

exception
  when NO_DATA_FOUND then
    rollback;
    return - 99; --不存在相关数据
  when others then
    v_errorcode := sqlcode;
    v_errormsg  := sqlerrm;
    rollback;
    insert into T_DBLog
      (err_date, name_proc, err_code, err_msg)
    values
      (sysdate, 'FN_T_D_BuySettleOrder_hold', v_errorcode, v_errormsg);
    commit;
    return - 100;
end;
/

