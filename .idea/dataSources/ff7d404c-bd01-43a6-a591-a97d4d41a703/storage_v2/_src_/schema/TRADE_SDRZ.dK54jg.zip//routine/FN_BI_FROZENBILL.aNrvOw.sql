CREATE function fn_bi_frozenBill
(
    p_commodityid varchar2,
    p_firmid varchar2,
    p_quantity number,
    p_matchId  varchar2,
    p_stockid  varchar2
)
return integer is
  /**
  * add by lyf 20160919
  * 冻结交收仓单
  * 返回值： 1 成功、-6.不存在p_stockid持仓单号 -7.仓单用户不匹配  -8. 仓单未注册  -9.  仓单已出库 -11.仓单不是注册状态  -12.仓单已被使用
  **/
  v_cnt            number(4); --数字变量
  v_quantity       bi_stock.quantity%type;
  v_ownerfirm      bi_stock.ownerfirm%type;
  v_stockstatus    bi_stock.stockstatus%type;
  RET_RESULT       integer:=-100;--未知异常
begin
    begin
       select quantity, ownerfirm, stockstatus into v_quantity, v_ownerfirm, v_stockstatus from BI_Stock t where stockID=p_stockid for update;
    exception
       when NO_DATA_FOUND then
       return -6;
    end;
    
    if v_ownerfirm!=p_firmid then
       return -7;
    end if;
    if v_stockstatus=0 then
       return -8;
    end if;
    if v_stockstatus=2 then
       return -9;
    end if;
    if v_stockstatus !=1 then
       return -11;
    end if;
    --select count(*) into v_cnt from BI_StockOperation t where stockID=p_stockid;
    --抵顶可以用于交收 yuansr 2018 01 12
    select count(*) into v_cnt from BI_StockOperation t where stockID=p_stockid and isgage <> 1;
    if v_cnt>0 then
       return -12;
    end if;
    insert into BI_StockOperation(StockID,OperationID) values(p_stockid,3);
     
    insert into BI_TradeStock(TradeStockID,StockID,Moduleid,TradeNO,CreateTime,ReleaseTime,Status) values(SEQ_BI_TradeStock.nextval,p_stockid,15,p_matchId,sysdate,null,0);
    
    return 1;
exception
    when NO_DATA_FOUND then
    --rollback;
    return RET_RESULT;
end;
/

