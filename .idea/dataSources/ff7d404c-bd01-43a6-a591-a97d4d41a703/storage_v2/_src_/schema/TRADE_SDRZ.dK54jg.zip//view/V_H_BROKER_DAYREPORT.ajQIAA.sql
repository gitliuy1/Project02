CREATE VIEW V_H_BROKER_DAYREPORT AS
  select t1.commodityid,t1.brokerid,t1.cleardate,sum(t1.fee) tradefee ,sum(t1.qty) quantity  ,sum(t1.amount) amount
  from br_r_firmcomoditydaytrade t1
 group by t1.commodityid,t1.brokerid,t1.cleardate
/

