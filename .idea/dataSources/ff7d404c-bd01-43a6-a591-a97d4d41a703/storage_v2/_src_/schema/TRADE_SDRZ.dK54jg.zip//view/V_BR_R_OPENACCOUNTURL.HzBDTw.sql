CREATE VIEW V_BR_R_OPENACCOUNTURL AS
  select t2.brokerid,
       '+' openaccounturl,
       t2.brokerlevel grade,
       t3.name brokername
  from br_broker_relation t2, br_broker t3
 where t2.brokerid = t3.brokerid
   --and regexp_like(t3.brokerid, '^[[:digit:]]+$')
   and t3.membertype = 0
/

