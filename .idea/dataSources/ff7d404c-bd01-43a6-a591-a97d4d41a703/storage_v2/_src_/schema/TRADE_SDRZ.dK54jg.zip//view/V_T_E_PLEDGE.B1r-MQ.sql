CREATE VIEW V_T_E_PLEDGE AS
  select p."ID",p."BILLID",p."BILLFUND",p."FIRMID",p."BREEDNAME",p."QUANTITY",p."CREATETIME",p."CREATOR",p."MODIFYTIME",p."MODIFIER",p."STATUS",p."TYPE",m.name name from T_E_Pledge p,m_firm m where p.firmid = m.firmid
/

