CREATE FUNCTION FN_TestUpdateSEQ( p_num number   --序列执行次数
                                           ) RETURN NUMBER
/****
 * 更新序列号
 * 返回值
 * 1 成功
 * -100 失败
****/
as
    v_seqNo number(15) := 1;
    v_tmpNo number(15);
    v_errorcode number;
    v_errormsg  varchar2(200);
begin

    /*select seq_t_holdposition.nextval into v_seqNo from dual;
    v_addNo := v_seqNo+p_num;*/

      WHILE v_seqNo <= 25  LOOP
        BEGIN
          /*select SEQ_MYDEMO.nextval into v_seqNo from dual;*/
          select  seq_t_holdposition.nextval into v_tmpNo from dual;
          select seq_t_trade.nextval into v_tmpNo from dual;
          select seq_t_orders.nextval into v_tmpNo from dual;
          v_seqNo := v_seqNo + 1;
        END;
      END LOOP;
    return 1;
exception
    when OTHERS then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_TestUpdateSEQ',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

