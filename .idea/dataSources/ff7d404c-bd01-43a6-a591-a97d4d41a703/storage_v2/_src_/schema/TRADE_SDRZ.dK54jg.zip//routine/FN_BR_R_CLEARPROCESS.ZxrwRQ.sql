CREATE function fn_br_r_clearprocess return number
/*********************************
 * 佣金计算方法：（验证结算前提）
 *   1 统计交易商成交情况
 *   2 统计会员（下辖交易商合计）成交情况
 *   3 根据设置 计算 对应的佣金
 *   4 返款（首款100%）
 *返回值：
 *   1=结算完成；-1=不是闭市计算完成状态；-2=财务结算已完成；-3=佣金计算中 ；-4=佣金返款中；-5= 已结算；
 *   -6=结算日期异常（存在人为修改数据）； -100= 系统异常，结算失败；
 *
 ********************************/
is
    v_b_date              date;           ---结算系统日期
    v_trade_date          date;           ---结算系统日期
    v_status              number(2,0) ;   --系统状态
    v_result              number(4,0) ;   --系统状态
    v_errorcode           number;
    v_errormsg            varchar2(200);
begin

    ---截止日期 必须是已结算，且系统必须处于结算完成状态：交易日
    select tradedate ,status  into v_trade_date，v_status from t_systemstatus t for update;
    if v_status<>10 then
       return -1;----不是闭市计算完成状态
    end if;

    select status  into v_status from f_systemstatus t for update;

    if v_status=2 then
      return -2;----财务结算已完成
    end if;

    ---update br_r_systemstatus t set t.status=1 where t.status in(0,2) ;
    select status,trunc(b_date) into v_status,v_b_date from br_r_systemstatus t for update nowait;

    if (v_b_date>v_trade_date) then
      return -6;---结算日期异常
    end if;

    if v_status = 1 then
       return -3;----已处于计算中
    elsif v_status = 3 then
      return -4;----已处于返款中
    elsif v_status = 5 then
      return -5;----已完成结算
    end if;

    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=1;
    commit;
    
    if (v_status = 0 ) then
      v_result:=fn_br_r_getreward(v_b_date);
      if(v_result<>1) then
         return v_result ;
      end if;
      v_result:=fn_br_r_financereward(v_b_date);
    elsif (v_status = 2 ) then
       v_result:=fn_br_r_financereward(v_b_date);
    end if;
    
    if(v_result<>1) then
         return v_result ;
      end if;

    ---更新系统状态
    update br_r_systemstatus t set t.status=5;
    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=5;
     
    insert into op_globallog_all(id,operator,operatetime,operatetype, operatecontent,operateresult    ) 
    values ( seq_op_globallog.nextval,'dbfunc',sysdate,5012, '完成佣金结算:'||to_char(v_b_date,'yyyy-mm-dd'),1 );
    
    return 1;
 exception
    when others then
      v_errorcode:=sqlcode;
      v_errormsg :=sqlerrm;
      rollback;
      insert into T_DBLog(err_date,name_proc,err_code,err_msg) values(sysdate,'fn_br_r_clearprocess',v_errorcode,v_errormsg);
      commit;
    return -100;
end;
/

