CREATE VIEW V_SWAPFEEMODEL AS
  select t.firmid,
       t.commodityid,
       t.name,
       t.overdat,
       t.swapfee
       from (select thname.*,tt.name from (select tho.firmid,
       tho.commodityid,
       tho.overdat,
       sum(tho.swapfee) swapfee
       from t_holdposition tho
       where tho.a_holdno in (select thmin.min from ( select max(th.a_holdno) as max, min(th.a_holdno) as min
                  from T_HoldPosition th
                 where th.a_tradeholdno is not null
                   and th.n_tradeno is not null
                   and th.f_cleardate is not null
                   and th.holdqty != 0
                 group by th.a_tradeholdno, th.n_tradeno, th.f_cleardate, th.firmid) thmin where thmin.max != thmin.min)
              group by tho.firmid, tho.commodityid, tho.overdat) thname, t_tx_txfirm tt where thname.firmid = tt.txfirmid ) t
/

