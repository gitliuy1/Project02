CREATE VIEW V_H_FIRM_DAYSUMREPORT AS
  select t1.firmid,t1.commodityid,t1.brokerid,t1.cleardate,t2.developer,t3.name firmname
	     ,t1.fee tradefee ,t1.qty quantity  ,t1.amount amount
    from br_r_firmcomoditydaytrade t1,br_r_firmdeveloper t2, m_firm t3
   where t3.firmid=t2.firmid and t1.firmid=t2.firmid
/

