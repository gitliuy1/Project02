CREATE TYPE              "TYPE_ARRAY_TRADE_ORDER"                                          as table of type_trade_order;
/

