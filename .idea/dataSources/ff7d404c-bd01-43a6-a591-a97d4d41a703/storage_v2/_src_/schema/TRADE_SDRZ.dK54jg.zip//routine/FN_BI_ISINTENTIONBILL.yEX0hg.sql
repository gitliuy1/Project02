CREATE function FN_BI_isIntentionBill
(
    p_StockId varchar2,
    p_CommodityId varchar2,
    p_SettleDate date
)
return number
  /**
  * add by hanqr 2017-9-2
  * 判断传入仓单号在交收日期当天是否是到期意向仓单
  * 返回值： -1不是意向仓单
  *          1是意向仓单
  **/
as
  v_firmId   varchar2(32);     --交易商ID
  v_count    number;
  v_orders   number(15);         --到期意向申报单号
  v_oldStock varchar2(30);     --仓单对应的母单号
begin
    --1.判断当前交易商、商品在交收日期当天是否有到期意向申报
    select s.ownerfirm into v_firmId from bi_stock s where s.stockid = p_StockId;
    begin
      select s.a_orderno into v_orders from t_h_setttleintentions s 
             where s.firmid = v_firmId and s.bs_flag=2 and s.status=1 and s.commodityid = p_CommodityId and s.tradedate = trunc(p_SettleDate);     
        --2.有意向申报，获取到委托单号，判断委托号和仓单号是否对应 
        select count(*) into v_count from t_intentionstocks i where i.stockid=p_StockId and i.a_orderno=v_orders;
        if v_count = 1 --对应,返回1
          then
            return 1;
        else  --3.委托号和仓单号不对应，用当前仓单号去找拆单表
           v_oldStock := p_StockId;
           --for dis in (select count(*) count,d.stockid from bi_dismantle d where d.newstockid = v_oldStock group by d.stockid)
          select count(*) vcount into v_count from bi_dismantle d where d.newstockid = v_oldStock;         
          while v_count = 1
          loop
          --4.找到母单，判断母单和委托单号是否对应
              select d.stockid into v_oldStock from bi_dismantle d where d.newstockid = v_oldStock;  
              select count(*) into v_count from t_intentionstocks i where i.stockid=v_oldStock and i.a_orderno=v_orders;
              if v_count = 1 --对应,返回1
                then
                  return 1;
              else       --不对应，继续用母单找母单
                select count(*) vcount into v_count from bi_dismantle d where d.newstockid = v_oldStock;
              end if; 
         end loop;           
        end if;
        return -1;
    exception
      when NO_DATA_FOUND then
      return -1;
    end;

end;
/

