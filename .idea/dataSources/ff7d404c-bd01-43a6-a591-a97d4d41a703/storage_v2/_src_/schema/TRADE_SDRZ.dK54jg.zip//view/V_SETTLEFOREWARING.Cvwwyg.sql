CREATE VIEW V_SETTLEFOREWARING AS
  select q."COMMODITYID",
       q."FIRMID",
       q."FIRMNAME",
       q."B_HOLDQTYSUM",
       Q."S_HOLDQTYSUM",
       q."STOCKQTYSUM",
       q."MARGINITEM_B",
       q."MARGINITEM_S",
       q."NOWLEAVEBALANCE",
       q."OVERDATE"
       ,
       (case
         when q.STOCKQTYSUM >= q.S_HOLDQTYSUM then
          '正常'
         when q.STOCKQTYSUM < q.S_HOLDQTYSUM then
          '不足'
         else
         '不足'
      end) "MATCHING"
  from (select t.commodityid,
               --trunc(sysdate)+case when (nvl(t.overdat,0)-1)<0 then 0 else nvl(t.overdat,0) end overdate,
               trunc(sysdate) + case when (overdat-1)<0 then 0 else (overdat-1) end overdate,
               t.firmid,
               (select mf.name from m_firm mf where mf.firmid = t.firmid) firmname,
               nvl((select sum(bis.quantity)
                     from bi_stock bis
                    where bis.breedid =
                          (select tc.breedid
                             from t_commodity tc
                            where tc.commodityid = t.commodityid)
                      and bis.ownerfirm = t.firmid
                      and bis.stockstatus = '1'),
                   0) stockqtysum,
               sum(case
                     when t.bs_flag = '1' then
                      t.holdqty
                     else
                      0
                   end) as b_holdqtysum,
               sum(case
                     when t.bs_flag = '2' then
                      t.holdqty
                     else
                      0
                   end) as s_holdqtysum,
               (select (case
                         when t.overdat <= tcd.settledays5 then
                          tcd.marginitem5
                         when t.overdat <= tcd.settledays4 then
                          tcd.marginitem4
                         when t.overdat <= tcd.settledays3 then
                          tcd.marginitem3
                         when t.overdat <= tcd.settledays2 then
                          tcd.marginitem2
                         when t.overdat <= tcd.settledays1 then
                          tcd.marginitem1
                         else
                          0
                       end)
                  from t_commodity tcd
                 where tcd.commodityid = t.commodityid) marginitem_b,
               (select (case
                         when t.overdat <= tcd.settledays5 then
                          tcd.marginitem5_s
                         when t.overdat <= tcd.settledays4 then
                          tcd.marginitem4_s
                         when t.overdat <= tcd.settledays3 then
                          tcd.marginitem3_s
                         when t.overdat <= tcd.settledays2 then
                          tcd.marginitem2_s
                         when t.overdat <= tcd.settledays1 then
                          tcd.marginitem1_s
                         else
                         0
                       end)
                  from t_commodity tcd
                 where tcd.commodityid = t.commodityid) marginitem_s,
               (select (nvl(nvl(balance, 0) + nvl((-1) * FrozenFunds, 0), 0))
                  from F_FirmFunds fff
                 where fff.firmid = t.firmid) nowleavebalance
          from t_holdposition t
         group by t.commodityid, t.overdat, t.firmid) q
/

