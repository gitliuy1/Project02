CREATE function FN_T_D_BuySettleOrder_WD(  p_FirmID          varchar2,   --交易商ID
                                                      p_CustomerID      varchar2,   --交易客户ID
                                                      p_CommodityID     varchar2,   --商品ID
                                                      p_Quantity        number ,    --委托数量
                                                      p_TradeQty        number ,    --已成交数量
                                                      p_Price           number ,    --委托价格，行情结算价
                                                      p_A_OrderNo_W     number,     --被撤委托单号
                                                      p_quantity_wd     number,     --撤单数量
                                                      p_frozenfunds     number,     --冻结资金
                                                      p_unfrozenfunds   number      --解冻资金
) return number
/****
 * 买交收申报委托撤单
 * 返回值
 * 1 成功
 *修改： 解冻冻结持仓合计后，同时解冻冻结持仓明细(按持仓单号降序),交易保证金始终根据持仓明细中计算求和 yuansr 2016 10 20
 *      交易保证金 按持仓到期天数 所处阶段 设置参数 计算       yuansr 2016 10 30
****/
as
    v_version               varchar2(10):='1.0.2.2';
    v_Margin                number(15,2);             --应收保证金
    v_Payout_B              number(15,2);             --买方交收货款
    v_SettleMargin_B        number(15,2);             --买方交收保证金
    v_to_unfrozenF          number(15,2);
    v_F_FrozenFunds         number(15,2);             --交易商冻结资金
    v_MarginPriceType       number(1);                --计算成交保证金结算价类型 0:实时和闭市时都按开仓价；1:实时按昨结算价，闭市按当日结算价
    v_LastPrice             number(15,2);             --昨结算价
    v_alreadyQty            number(15):=0;            --已完成解冻数量
    v_Margin_hold           number(15,2);             --持仓冻结应收保证金
    v_tempQty               number(15):=0;            --中间变量
begin
   --1、释放剩余的冻结持仓   modiyf by lyf 20160801 增加释放指定持仓单号的撤单
   update T_CustomerHoldSum set frozenQty = frozenQty - p_quantity_wd
    where CustomerID = p_CustomerID and CommodityID = p_CommodityID
      and bs_flag = 1;
  
   select MarginPriceType,LastPrice  into v_MarginPriceType,v_LastPrice from T_Commodity where CommodityID=p_CommodityID;
   if v_MarginPriceType <> 1 then 
     v_LastPrice:=p_Price;--不按结算价，则按委托价计算保证金
   end if;
   
   --更新持仓冻结记录，完撤单解冻(包括指定持仓 委托 撤单) yuansr 2016 10 21
   v_alreadyQty     := 0;
   v_tempQty        := 0;
   for v_FrozenHold in (select t1.a_holdno  ,t1.bs_flag	 ,t1.qty    ,t1.frozenqty ,t1.unfrozenqty  ,t2.overdat
                          from T_S_OrderFrozenHold t1 ,t_holdposition t2 
                         where t1.bs_flag=t2.bs_flag and t1.a_holdno=t2.a_holdno and t1.ordertype=0
                           and t1.bs_flag=1 and t1.a_orderno=p_A_OrderNo_W order by t1.a_holdno desc for update )---按持仓单号倒序依次解冻
   loop
       v_tempQty := v_FrozenHold.frozenqty-v_FrozenHold.unfrozenqty;---有效冻结数量
       if v_alreadyQty+v_tempQty <= p_quantity_wd  then
          --已处理数量 加上 当前持仓冻结数 仍小于或等于 撤单数，当前持仓冻结数全部 解冻，并更新持仓明细
          --update T_S_OrderFrozenHold set unfrozenqty=unfrozenqty+v_tempQty where a_orderno=p_A_OrderNo_W and a_holdno=v_FrozenHold.a_holdno;
          delete from T_S_OrderFrozenHold where ordertype=0 and a_orderno=p_A_OrderNo_W and a_holdno=v_FrozenHold.a_holdno;--全部撤销的冻结 记录 直接删除
          v_alreadyQty   :=  v_alreadyQty+v_tempQty;
          v_Margin_hold  :=  FN_T_ComputeMarginPlus(p_FirmID,p_CommodityID,1,v_FrozenHold.overdat,v_tempQty,v_LastPrice);
          v_Margin       :=  v_Margin+v_Margin_hold;
       else --解冻部分冻结数量
          v_tempQty  := p_quantity_wd-v_alreadyQty ;---解冻数量=撤单数-已撤单数
          update T_S_OrderFrozenHold set unfrozenqty=unfrozenqty+v_tempQty 
           where ordertype=0 and a_orderno=p_A_OrderNo_W and a_holdno=v_FrozenHold.a_holdno;
          v_alreadyQty:=p_quantity_wd;
          v_Margin_hold:= FN_T_ComputeMarginPlus(p_FirmID,p_CommodityID,1,v_FrozenHold.overdat,v_tempQty,v_LastPrice);
          v_Margin:=v_Margin+v_Margin_hold;
       end if;

       if v_alreadyQty = p_quantity_wd then --完成解冻，退出
          exit;
       end if;
   end loop;

   if v_alreadyQty <> p_quantity_wd then --解冻失败，抛出异常
      Raise_application_error(-20040, 'T_S_OrderFrozenHold unfrozenqty error');
   end if;
 
   --2、释放剩余的冻结资金，根据未成交数量
   if(p_Quantity - p_TradeQty = p_quantity_wd) then
      v_to_unfrozenF := p_frozenfunds - p_unfrozenfunds;
   else--冻结资金：冻结买方交收货款+买方交收保证金-买方占用的交易保证金
      --计算交收货款
      v_Payout_B := FN_T_ComputePayout(p_FirmID,p_CommodityID,1,p_quantity_wd,p_Price);
      --计算交收保证金
      v_SettleMargin_B := FN_T_ComputeSettleMargin(p_FirmID,p_CommodityID,1,p_quantity_wd,p_Price);
      if(v_Margin < 0) then
          Raise_application_error(-20040, 'computeMargin error');
      end if;
      v_to_unfrozenF := v_Payout_B + v_SettleMargin_B - v_Margin;
   end if;

   update T_DelayOrders set unfrozenfunds = unfrozenfunds + v_to_unfrozenF
    where A_orderNo = p_a_orderno_w;
   --更新冻结资金
   v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID,-v_to_unfrozenF,'15');

   return 1;
end;
/

