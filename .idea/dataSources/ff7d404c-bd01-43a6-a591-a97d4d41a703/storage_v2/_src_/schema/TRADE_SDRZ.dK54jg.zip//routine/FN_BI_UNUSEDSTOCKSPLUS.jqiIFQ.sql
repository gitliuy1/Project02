CREATE function FN_BI_UnusedStocksPlus
(
    p_commodityid varchar2,
    p_firmid varchar2,
    p_quantity number,
    p_matchId  varchar2,
    p_goodsId  number,
    p_placeId  number
)
return integer is
  /**
  * add by lyf 20160919
  * 检查卖方交易商可用持仓
  * 返回值： -1没有符合的持仓信息
  **/
  TYPE v_billids IS TABLE OF VARCHAR2(30) INDEX BY BINARY_INTEGER;
  TYPE v_sck IS TABLE OF VARCHAR2(200) INDEX BY BINARY_INTEGER;
  TYPE v_qty IS TABLE OF VARCHAR2(200) INDEX BY BINARY_INTEGER;
  v_cnt                  bi_stock.stockid%type; --数字变量
  v_breedid              t_commodity.breedid%type;
  v_billid               v_billids;
  v_quantity             bi_stock.quantity%type:=0;
  --v_stockids             TYPE_BILL_STOCKID;
  v_stockids             v_sck;
  v_quantitys            v_qty;
  i                      number:=1;
  --v_propertyname         bi_goodsproperty.propertyname%type;
  RET_RESULT integer:=-10;--可配仓单不存在


begin
    select breedid into v_breedid from t_commodity where commodityid=p_commodityid;

    --添加意向货种和意向交收地匹配  2017-7-6 hanqr

      for st in (select a.* from (select *
                                    from bi_stock
                                   where stockstatus = 1
                                     and breedid = v_breedid
                                     and ownerfirm = p_firmid
                                     and quantity <= p_quantity) a,
                                 (select *
                                    from bi_stock
                                   where stockstatus = 1
                                     and breedid = v_breedid
                                     and ownerfirm = p_firmid
                                     and quantity <= p_quantity
                                     and goodsid = p_goodsId
                                     and placeid = p_placeId) b
                   where a.stockid = b.stockid(+)
                   order by b.goodsid, b.placeid, a.stockid)  loop
       for bi in (select g.propertyname from bi_stock s,bi_goodsproperty g where g.stockID(+)=s.stockID and not exists (select stockid from BI_StockOperation so where so.stockID=s.stockid) and s.stockid=st.stockid order by g.propertyname) loop
          for pr in (select p.* from m_breed b,m_property p where p.categoryid=b.categoryid and breedid=v_breedid order by propertyname) loop
              if pr.stockcheck='Y' then
                 if bi.propertyname=pr.propertyname then
                     v_quantitys(i) := st.quantity;
                     v_stockids(i) := st.stockid;
                     i:=i + 1;
                 else
                     exit;
                 end if;
              elsif pr.stockcheck='M' then
                  if bi.propertyname=pr.propertyname then
                     v_quantitys(i) := st.quantity;
                     v_stockids(i) := st.stockid;
                     i:=i + 1;
                     exit;
                 end if;
              else
                 v_quantitys(i) := st.quantity;
                 v_stockids(i) := st.stockid;
                 i:=i + 1;
              end if;
          end loop;
        end loop;
      end loop;

    for i in 1..v_stockids.count LOOP
      v_quantity := v_quantity+v_quantitys(i);
      v_billid(i):=v_stockids(i);
      if v_quantity=p_quantity then
         exit;
      end if;
    end loop;
    if v_quantity=p_quantity then
      for i in 1..v_billid.count LOOP
        insert into t_billfrozen (id, operation, billid, operationtype, modifytime) values (SEQ_T_BILLFROZEN.NEXTVAL, p_matchId, v_billid(i), 2, sysdate);
        v_cnt:=fn_bi_frozenBill(p_commodityid,p_firmid,p_quantity,p_matchId,v_billid(i)) ;
        if(v_cnt<=0)then
           return v_cnt;
        end if;
      end loop;
    else
      return RET_RESULT;
    end if;

    return 1;
exception
    when NO_DATA_FOUND then
    --rollback;
    return -100;  --不存在相关数据
end;
/

