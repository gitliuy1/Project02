CREATE function FN_T_D_CloseOrder_WD return number
/****
 * 撤销到期申报未全部成交的委托 yuansr 2017 09 04
 * 返回值
 * 1 成功   
****/
as
    v_quantity_wd           number(10)	;
    --v_WithdrawType:= 4       number(2)  ; 
    v_status                number(2)  ;
    v_ret                   number(4)  ;
begin

   for ItemOrder in (select * from t_delayorders t1 
                      where t1.status not in(3,5,6) and t1.delayordertype=3  for update )---按持仓单号倒序依次解冻
   loop

      v_quantity_wd := ItemOrder.quantity  - ItemOrder.tradeqty ;
      if(ItemOrder.bs_flag = 1) then  --买
        v_ret := FN_T_D_BuySettleOrder_WD( ItemOrder.FirmID     ,ItemOrder.CustomerID   ,ItemOrder.CommodityID  ,ItemOrder.Quantity 
                                           ,ItemOrder.TradeQty  ,ItemOrder.Price        ,ItemOrder.A_OrderNo 
                                           ,v_quantity_wd       ,ItemOrder.frozenfunds  ,ItemOrder.unfrozenfunds );
      else  --卖
        v_ret := FN_T_D_SellCloseOrder_WD( ItemOrder.FirmID    ,ItemOrder.CustomerID   ,ItemOrder.CommodityID  ,ItemOrder.Quantity 
                                           ,ItemOrder.TradeQty ,ItemOrder.Price        ,ItemOrder.A_OrderNo 
                                           ,v_quantity_wd      ,ItemOrder.frozenfunds  ,ItemOrder.unfrozenfunds );
      end if;

      --更新委托状态
      if(ItemOrder.tradeqty = 0) then
        v_status := 5; --全部撤单
      else
        v_status := 6; --部分成交后撤单
      end if;
 
      update T_DelayOrders set status=v_status,WithdrawType=4,WithdrawTime=sysdate,WithdrawerID='auto' where A_orderNo = ItemOrder.a_orderno ;
    end loop;

   return 1;
end;
/

