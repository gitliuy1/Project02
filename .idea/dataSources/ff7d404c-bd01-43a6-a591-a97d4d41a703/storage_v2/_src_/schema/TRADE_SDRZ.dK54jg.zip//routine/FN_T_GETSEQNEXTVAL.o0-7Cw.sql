CREATE FUNCTION FN_T_getSeqNextVal
(
    p_seq_name varchar2  --结算日期
)
RETURN varchar2
/****
 * 获取序列下一值
****/
as

  SeqNextVal varchar2(32);

begin
    execute immediate 'select '|| p_seq_name|| '.nextval from dual' into SeqNextVal ;

    return SeqNextVal;
end;
/

