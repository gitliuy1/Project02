CREATE VIEW V_BROKERAGEANDFIRM AS
  select "BROKERAGEID","FIRMID","BINDTYPE","BINDTIME" from br_brokerageandfirm b where  b.bindtype = '0'
/

