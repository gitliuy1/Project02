CREATE VIEW V_F_FIRMCURFUNDS AS
  select firmId,          --交易商代码
       name,            --交易商名称
       f_balance+FrozenGDFunds+frozenzgfunds f_balance,       --交易系统当前余额
       l_balance+FrozenGDFunds+frozenzgfunds l_balance,       --财务结算余额
       y_balance,       --财务未结算金额
       balanceSubtract, --差额
       lastwarranty,    --担保金
       frozenFunds,     --临时资金
       user_balance,     --可用资金
       -FrozenGDFunds FrozenGDFunds,    --调拨到高达的资金
       -frozenzgfunds frozenzgfunds     --调拨到直供的资金
  from (select z.*,
               f_balance - l_balance - y_balance balanceSubtract,
               f_balance + FrozenFunds+FrozenGDFunds+frozenzgfunds user_balance
          from (select f.firmid,
                       (select name from m_firm where firmId = f.firmId) name,
                       f.balance f_balance,
                       nvl(h.todaybalance, 0) l_balance,
                       nvl(e.y_balance, 0) y_balance,
                       nvl(f.lastwarranty, 0) lastwarranty,
                       nvl(-1 * (FrozenFunds), 0) FrozenFunds,
                       nvl(-1 * (FrozenGDFunds), 0) FrozenGDFunds,
                       nvl(-1 * (frozenzgfunds), 0) frozenzgfunds
                  from F_FirmFunds f,
                       (select h1.firmid, h1.todaybalance
                          from f_firmbalance h1
                         where h1.b_date =
                               (select nvl(max(b_date),
                                           to_date('2009-01-01', 'yyyy-MM-dd'))
                                  from f_firmbalance)) h,
                       (select d.firmid,
                               0 + nvl(b.c_balance, 0) - nvl(c.d_balance, 0) y_balance
                          from F_FirmFunds d,
                               (select a.firmid, sum(a.amount) c_balance
                                  from f_fundflow a
                                 where a.oprcode in
                                       (select t.summaryno
                                          from f_summary t
                                         where t.funddcflag = 'C')
                                 group by firmid) b,
                               (select a.firmid, sum(a.amount) d_balance
                                  from f_fundflow a
                                 where a.oprcode in
                                       (select t.summaryno
                                          from f_summary t
                                         where t.funddcflag = 'D')
                                 group by firmid) c
                         where d.firmid = b.firmid(+)
                           and d.firmid = c.firmid(+)) e
                 where f.firmid = h.firmid(+)
                   and f.firmid = e.firmid(+)) z)
/

