CREATE function FN_T_GetOverQtyInDays
(
       i_OverDate          number,  ---到期天数
       i_startDays         number, ---指定起始天数（包含）
       i_endDays           number, ---指定截止天数（不包含）
       i_bs_flag           number, ---买卖标识 ,null 表示非净持
       i_qty               number  ---数量 
)
return number
/****
 *  计算交收净持仓情况
 *
 *  yuansr 2017 04 23
****/
as
begin

    ---当设定天数范围起始天数不为1时, 且到期天数小于 设定天数范围起始天数 则返回0 ；
    if ( (i_startDays != 1) and ( i_OverDate<i_startDays) ) then
       return 0;
    end if;
    ---到期天数小于1,大于等于设定天数范围截止天数 则返回0 ；
    if ( i_OverDate>=i_endDays ) then
       return 0;
    end if;
    
    if i_bs_flag is null then --非净持
      return i_qty;
    elsif i_bs_flag = 1 then --净持，买
      return i_qty;
    elsif i_bs_flag = 2 then --净持，卖
      return 0-i_qty;
    elsif i_bs_flag = 11 then --非净持，只计算买
      return i_qty;
    elsif i_bs_flag = 22 then --非净持，只计算卖
      return i_qty;
    else 
      return 0;
    end if;
end;
/

