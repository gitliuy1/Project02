CREATE function FN_T_UpdateTradeMTO(
    p_A_OrderNo_m     number,  --大单委托单号
    p_Price         number,  --成交价
    p_arr_trade_order     TYPE_ARRAY_TRADE_ORDER, --小单成交委托数组
  p_repeatSubmit         number  --重复提交标志：0:非重复提交;1:重复提交(防止成交处理出错，交易核心重试3次，用此标志);
) return number
/****
 * 大单吃小单成交处理
 * 返回值
 * 1 成功
 * -1 成交数量大于未成交数量
 * -2 成交数量大于冻结数量
 * -3 平仓成交数量大于持仓数量
 * -100 其它错误
****/
as
  v_version varchar2(10):='1.0.2.1';
    v_CommodityID varchar2(16);
    v_FirmID     varchar2(32);
    v_TraderID       varchar2(40);
    v_bs_flag        number(2);
    v_status         number(2);
    v_orderQty       number(10);
    v_orderPrice          number(15,2);
    v_orderTradeQty       number(10);
    v_frozenfunds    number(15,2);
    v_unfrozenfunds  number(15,2);
  v_CustomerID        varchar2(40);
  v_OrderType      number(2);
    v_closeMode      number(2);
    v_specPrice      number(15,2);
    v_timeFlag       number(1);
    v_CloseFlag      number(1);
  v_contractFactor T_Commodity.contractfactor%type;
  v_MarginPriceType         number(1);     --计算成交保证金结算价类型 0:实时和闭市时都按开仓价；1:实时按昨结算价，闭市按当日结算价
    v_marginAlgr         number(2);
    v_marginRate_b         number(10,4);
    v_marginRate_s         number(10,4);
    v_marginAssure_b         number(10,4);
    v_marginAssure_s         number(10,4);
    v_feeAlgr       number(2);
    v_feeRate_b         number(15,9);
    v_feeRate_s         number(15,9);
    v_TodayCloseFeeRate_B         number(15,9);
    v_TodayCloseFeeRate_S         number(15,9);
    v_HistoryCloseFeeRate_B         number(15,9);
    v_HistoryCloseFeeRate_S         number(15,9);
    v_ForceCloseFeeAlgr       number(2);
    v_ForceCloseFeeRate_B         number(15,9);
    v_ForceCloseFeeRate_S         number(15,9);
    v_AddedTaxFactor T_Commodity.AddedTaxFactor%type;--增值税率系数=AddedTax/(1+AddedTax)
    v_YesterBalancePrice    number(15,2);
    v_num            number(10);
    v_ret            number(4);
    v_FL_ret            number(4);
    v_FirmID_o     varchar2(32);
    v_errorcode      number;
    v_errormsg       varchar2(200);
    v_GageMode number(2);--抵顶模式，分0全抵顶和1半抵顶，半抵顶时要计算浮亏，2009-10-14
    v_CloseAlgr        number(2);    --平仓算法(0先开先平；1后开先平；2持仓均价平仓)
    v_TradeDate date;
    v_BillTradeType number(2);   --仓单交易类型 0：正常默认；  1：卖仓单；    3：抵顶转让
    v_BillTradeType_o number(2);   --仓单交易类型 0：正常默认；  1：卖仓单；    3：抵顶转让

    v_TraderID_o       varchar2(40);
    v_bs_flag_o        number(2);
    v_status_o         number(2);
    v_orderQty_o       number(10);
    v_orderPrice_o          number(15,2);
    v_orderTradeQty_o       number(10);
    v_frozenfunds_o    number(15,2);
    v_unfrozenfunds_o  number(15,2);
  v_CustomerID_o        varchar2(40);
  v_OrderType_o      number(2);
    v_closeMode_o      number(2);
    v_specPrice_o      number(15,2);
    v_timeFlag_o       number(1);
    v_CloseFlag_o      number(1);

    v_marginAlgr_o         number(2);
    v_marginRate_b_o         number(10,4);
    v_marginRate_s_o         number(10,4);
    v_marginAssure_b_o         number(10,4);
    v_marginAssure_s_o         number(10,4);
    v_feeAlgr_o       number(2);
    v_feeRate_b_o         number(15,9);
    v_feeRate_s_o         number(15,9);
    v_TodayCloseFeeRate_B_o         number(15,9);
    v_TodayCloseFeeRate_S_o         number(15,9);
    v_HistoryCloseFeeRate_B_o         number(15,9);
    v_HistoryCloseFeeRate_S_o         number(15,9);
    v_ForceCloseFeeAlgr_o       number(2);
    v_ForceCloseFeeRate_B_o         number(15,9);
    v_ForceCloseFeeRate_S_o         number(15,9);

    v_marginAlgr_m         number(2);
    v_marginRate_b_m         number(10,4);
    v_marginRate_s_m         number(10,4);
    v_marginAssure_b_m         number(10,4);
    v_marginAssure_s_m         number(10,4);
    v_feeAlgr_m       number(2);
    v_feeRate_b_m         number(15,9);
    v_feeRate_s_m         number(15,9);
    v_TodayCloseFeeRate_B_m         number(15,9);
    v_TodayCloseFeeRate_S_m         number(15,9);
    v_HistoryCloseFeeRate_B_m         number(15,9);
    v_HistoryCloseFeeRate_S_m         number(15,9);
    v_ForceCloseFeeAlgr_m       number(2);
    v_ForceCloseFeeRate_B_m         number(15,9);
    v_ForceCloseFeeRate_S_m         number(15,9);

    v_tradeQty_m_temp       number(10);
    v_to_order_unfrozenF_temp  number(15,2);
    v_frozenMargin   number(15,2);
    v_frozenFee      number(15,2);
  v_unfrozenPrice    number(15,2);  --计算释放冻结保证金，手续费的价格

    v_OrderNo  number(15);  --小单委托单号
    v_Quantity  number(15);  --小单委托成交数量
    v_M_TradeNo_m  number(15);  --大单撮合成交号
    v_M_TradeNo_o  number(15);  --小单撮合成交号
begin
	insert into t_closelog(err_date,name_proc,err_code,err_msg)
    values(systimestamp(6),'FN_T_UpdateTradeMTO开始',p_A_OrderNo_m,systimestamp(6));
    --获取平仓算法,抵顶模式
    select CloseAlgr,GageMode into v_CloseAlgr,v_GageMode from T_A_Market;
    --取结算日期
  select TradeDate into v_TradeDate from T_SystemStatus;
  --更新一方成交
    select CommodityID,   Firmid,  TraderID, bs_flag, status, quantity, price, tradeqty, frozenfunds, unfrozenfunds,CustomerID,OrderType,closeMode,specPrice,timeFlag,CloseFlag,billTradeType
    into v_CommodityID,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderPrice,v_orderTradeQty,v_frozenfunds,v_unfrozenfunds,v_CustomerID,v_OrderType,v_closeMode,v_specPrice,v_timeFlag,v_CloseFlag,v_BillTradeType
    from T_Orders
    where A_OrderNo = p_A_OrderNo_m ;--for update;去掉for update 因为小单成交都会commit，成交和撤单的锁控制在java中，此处不需要锁，这样也能分次提交
    --获取商品信息
    select contractfactor,MarginPriceType,marginalgr,marginrate_b,marginrate_s,marginAssure_b,marginAssure_s,feealgr,feerate_b,feerate_s,TodayCloseFeeRate_B,TodayCloseFeeRate_S,HistoryCloseFeeRate_B,HistoryCloseFeeRate_S,ForceCloseFeeAlgr,ForceCloseFeeRate_B,ForceCloseFeeRate_S,AddedTaxFactor,LastPrice
    into v_contractFactor,v_MarginPriceType,v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s,v_feeAlgr,v_feeRate_b,v_feeRate_s,v_TodayCloseFeeRate_B,v_TodayCloseFeeRate_S,v_HistoryCloseFeeRate_B,v_HistoryCloseFeeRate_S,v_ForceCloseFeeAlgr,v_ForceCloseFeeRate_B,v_ForceCloseFeeRate_S,v_AddedTaxFactor,v_YesterBalancePrice
    from T_Commodity where CommodityID=v_CommodityID;
    --获取特户的交易保证金，保证金算法
    begin
        select marginalgr,marginrate_b,marginrate_s,marginAssure_b,marginAssure_s
      into v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m
        from T_A_FirmMargin
        where FirmID=v_FirmID and CommodityID=v_CommodityID;
    exception
        when NO_DATA_FOUND then
            v_marginAlgr_m := v_marginAlgr;
      v_marginRate_b_m := v_marginRate_b;
      v_marginRate_s_m := v_marginRate_s;
      v_marginAssure_b_m := v_marginAssure_b;
      v_marginAssure_s_m := v_marginAssure_s;
    end;

    --获取特户的交易手续费，手续费算法
    begin
        select feealgr,feerate_b,feerate_s,TodayCloseFeeRate_B,TodayCloseFeeRate_S,HistoryCloseFeeRate_B,HistoryCloseFeeRate_S,ForceCloseFeeAlgr,ForceCloseFeeRate_B,ForceCloseFeeRate_S
      into v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m
        from T_A_FirmFee
        where FirmID=v_FirmID and CommodityID=v_CommodityID;
    exception
        when NO_DATA_FOUND then
      --获取交易商对应套餐手续费系数，手续费算法
      begin
        select feealgr,feerate_b,feerate_s,TodayCloseFeeRate_B,TodayCloseFeeRate_S,HistoryCloseFeeRate_B,HistoryCloseFeeRate_S,ForceCloseFeeAlgr,ForceCloseFeeRate_B,ForceCloseFeeRate_S
        into v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m
        from T_A_Tariff
        where TariffID=(select TariffID from t_firm where FirmID=v_FirmID) and CommodityID=v_CommodityID;
      exception
        when NO_DATA_FOUND then
          v_feeAlgr_m := v_feeAlgr;
          v_feeRate_b_m := v_feeRate_b;
          v_feeRate_s_m := v_feeRate_s;
          v_TodayCloseFeeRate_B_m := v_TodayCloseFeeRate_B;
          v_TodayCloseFeeRate_S_m := v_TodayCloseFeeRate_S;
          v_HistoryCloseFeeRate_B_m := v_HistoryCloseFeeRate_B;
          v_HistoryCloseFeeRate_S_m := v_HistoryCloseFeeRate_S;
          v_ForceCloseFeeAlgr_m := v_ForceCloseFeeAlgr;
          v_ForceCloseFeeRate_B_m := v_ForceCloseFeeRate_B;
          v_ForceCloseFeeRate_S_m := v_ForceCloseFeeRate_S;
      end;
    end;

    v_tradeQty_m_temp := v_orderTradeQty;
    v_to_order_unfrozenF_temp := v_unfrozenfunds;
  for i in 1..p_arr_trade_order.count LOOP
    v_OrderNo := p_arr_trade_order(i).OrderNo;  --小单委托单号
    v_Quantity := p_arr_trade_order(i).Quantity;  --小单委托成交数量
    v_M_TradeNo_m := p_arr_trade_order(i).M_TradeNo_m;  --大单撮合成交号
    v_M_TradeNo_o := p_arr_trade_order(i).M_TradeNo_o;  --小单撮合成交号
    insert into t_closelog(err_date,name_proc,err_code,err_msg,err_order)
    values(systimestamp(6),'FN_T_UpdateTradeMTO小单成交',p_A_OrderNo_m,systimestamp(6),v_OrderNo);
    --判断是否已处理过
    if(p_repeatSubmit = 1) then
      select count(m_tradeno) into v_num from T_Trade where m_tradeno=v_M_TradeNo_m or m_tradeno=v_M_TradeNo_o;
    else
      v_num := 0;
    end if;
    --如果重复提交，则已成交过的跳过
    if(v_num =0) then
      --查找另一方委托信息，委托单号和交易商不一样
      select   Firmid,  TraderID, bs_flag, status, quantity, price, tradeqty, frozenfunds, unfrozenfunds,CustomerID,OrderType,closeMode,specPrice,timeFlag,CloseFlag,billTradeType
      into v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderPrice_o,v_orderTradeQty_o,v_frozenfunds_o,v_unfrozenfunds_o,v_CustomerID_o,v_OrderType_o,v_closeMode_o,v_specPrice_o,v_timeFlag_o,v_CloseFlag_o,v_BillTradeType_o
      from T_Orders
      where A_OrderNo = v_OrderNo ;--for update;去掉for update 因为小单成交都会commit，成交和撤单的锁控制在java中，此处不需要锁
      --获取特户的交易保证金，保证金算法
      begin
          select marginalgr,marginrate_b,marginrate_s,marginAssure_b,marginAssure_s
        into v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o
          from T_A_FirmMargin
          where FirmID=v_FirmID_o and CommodityID=v_CommodityID;
      exception
          when NO_DATA_FOUND then
        v_marginAlgr_o := v_marginAlgr;
        v_marginRate_b_o := v_marginRate_b;
        v_marginRate_s_o := v_marginRate_s;
        v_marginAssure_b_o := v_marginAssure_b;
        v_marginAssure_s_o := v_marginAssure_s;
      end;

      --获取特户的交易手续费，手续费算法
      begin
          select feealgr,feerate_b,feerate_s,TodayCloseFeeRate_B,TodayCloseFeeRate_S,HistoryCloseFeeRate_B,HistoryCloseFeeRate_S,ForceCloseFeeAlgr,ForceCloseFeeRate_B,ForceCloseFeeRate_S
        into v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o
          from T_A_FirmFee
          where FirmID=v_FirmID_o and CommodityID=v_CommodityID;
      exception
          when NO_DATA_FOUND then
        --获取交易商对应套餐手续费系数，手续费算法
        begin
          select feealgr,feerate_b,feerate_s,TodayCloseFeeRate_B,TodayCloseFeeRate_S,HistoryCloseFeeRate_B,HistoryCloseFeeRate_S,ForceCloseFeeAlgr,ForceCloseFeeRate_B,ForceCloseFeeRate_S
          into v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o
          from T_A_Tariff
          where TariffID=(select TariffID from t_firm where FirmID=v_FirmID_o) and CommodityID=v_CommodityID;
        exception
          when NO_DATA_FOUND then
            v_feeAlgr_o := v_feeAlgr;
            v_feeRate_b_o := v_feeRate_b;
            v_feeRate_s_o := v_feeRate_s;
            v_TodayCloseFeeRate_B_o := v_TodayCloseFeeRate_B;
            v_TodayCloseFeeRate_S_o := v_TodayCloseFeeRate_S;
            v_HistoryCloseFeeRate_B_o := v_HistoryCloseFeeRate_B;
            v_HistoryCloseFeeRate_S_o := v_HistoryCloseFeeRate_S;
            v_ForceCloseFeeAlgr_o := v_ForceCloseFeeAlgr;
            v_ForceCloseFeeRate_B_o := v_ForceCloseFeeRate_B;
            v_ForceCloseFeeRate_S_o := v_ForceCloseFeeRate_S;
        end;
      end;
      
     
    if(v_FirmID <= v_FirmID_o) then
      v_ret := FN_T_UpdateTradeByArgs(
      v_CommodityID,v_contractFactor,v_MarginPriceType,v_AddedTaxFactor,v_YesterBalancePrice,v_GageMode,v_CloseAlgr,v_TradeDate,v_Quantity,p_Price,

      p_A_OrderNo_m,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderPrice,v_tradeQty_m_temp,v_frozenfunds,v_to_order_unfrozenF_temp,v_CustomerID,
      v_OrderType,v_closeMode,v_specPrice,v_timeFlag,v_CloseFlag,v_BillTradeType,
      v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,
      v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m,v_M_TradeNo_m,

      v_OrderNo,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderPrice_o,v_orderTradeQty_o,v_frozenfunds_o,v_unfrozenfunds_o,v_CustomerID_o,
      v_OrderType_o,v_closeMode_o,v_specPrice_o,v_timeFlag_o,v_CloseFlag_o,v_BillTradeType_o,
      v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,
      v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o,v_M_TradeNo_o
      );
    else
      v_ret := FN_T_UpdateTradeByArgs(
      v_CommodityID,v_contractFactor,v_MarginPriceType,v_AddedTaxFactor,v_YesterBalancePrice,v_GageMode,v_CloseAlgr,v_TradeDate,v_Quantity,p_Price,

      v_OrderNo,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderPrice_o,v_orderTradeQty_o,v_frozenfunds_o,v_unfrozenfunds_o,v_CustomerID_o,
      v_OrderType_o,v_closeMode_o,v_specPrice_o,v_timeFlag_o,v_CloseFlag_o,v_BillTradeType_o,
      v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,
      v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o,v_M_TradeNo_o,

      p_A_OrderNo_m,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderPrice,v_tradeQty_m_temp,v_frozenfunds,v_to_order_unfrozenF_temp,v_CustomerID,
      v_OrderType,v_closeMode,v_specPrice,v_timeFlag,v_CloseFlag,v_BillTradeType,
      v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,
      v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m,v_M_TradeNo_m
      );
    end if;
    insert into t_closelog(err_date,name_proc,err_code,err_msg,err_order)
    values(systimestamp(6),'FN_T_UpdateTradeMTO成交函数调用完毕',p_A_OrderNo_m,systimestamp(6),v_OrderNo);
    --计算大单上次解冻的委托资金和成交数量，省的下次再查委托
    if(v_OrderType = 1) then --开仓
          if(v_MarginPriceType = 1) then
            v_unfrozenPrice := v_YesterBalancePrice;
        else  -- default type is 0
          v_unfrozenPrice := v_orderPrice;
        end if;
            v_frozenMargin := FN_T_ComputeMarginByArgs(v_bs_flag,v_Quantity,v_unfrozenPrice,v_contractFactor,v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m);
            if(v_frozenMargin < 0) then
                Raise_application_error(-20040, 'computeMargin error');
            end if;
            v_frozenFee := FN_T_ComputeFeeByArgs(v_bs_flag,v_Quantity,v_orderPrice,v_contractFactor,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m);
            if(v_frozenFee < 0) then
                Raise_application_error(-20030, 'computeFee error');
            end if;
            v_to_order_unfrozenF_temp := v_to_order_unfrozenF_temp + v_frozenMargin + v_frozenFee;
    end if;

    v_tradeQty_m_temp := v_tradeQty_m_temp + v_Quantity;

  --更新双方成交成功后分别计算双方的浮亏，由浮亏计算线程去轮询计算
  if(v_ret = 1) then
  insert into t_closelog(err_date,name_proc,err_code,err_msg,err_order)
    values(systimestamp(6),'FN_T_UpdateTradeMTO准备提交',p_A_OrderNo_m,systimestamp(6),v_OrderNo);
    
    commit;
    insert into t_closelog(err_date,name_proc,err_code,err_msg,err_order)
    values(systimestamp(6),'FN_T_UpdateTradeMTO提交完毕',p_A_OrderNo_m,systimestamp(6),v_OrderNo);
    commit;
  else
    rollback;
    return v_ret;
  end if;
  end if;
  end LOOP;
  return 1;
exception
    when OTHERS then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_T_UpdateTradeMTO',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

