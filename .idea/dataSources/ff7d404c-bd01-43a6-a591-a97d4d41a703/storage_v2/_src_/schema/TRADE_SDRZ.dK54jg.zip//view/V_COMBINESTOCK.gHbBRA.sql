CREATE VIEW V_COMBINESTOCK AS
  select bs."STOCKID",bs."REALSTOCKCODE",bs."BREEDID",bs."WAREHOUSEID",bs."QUANTITY",bs."UNIT",bs."OWNERFIRM",bs."LASTTIME",bs."CREATETIME",bs."STOCKSTATUS",bs."ALLOWANCE",bs."INDEXALLOWANCE",bs."STOCKTYPE",bs."WAREHOUSETYPE",bs."ISEXWAREHOUSE",bd.stockid originstockid from bi_stock bs,bi_dismantle bd where bs.stockid = bd.newstockid and bd.status='1'
/

