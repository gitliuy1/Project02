CREATE function FN_F_UpdateFirmFunds(p_firmid f_firmfunds.firmid%type,
                                                p_money f_firmfunds.frozenGDFunds%type,
                                                p_inoutMoney number) return number
/**
   *add by lyf 20150820
   *从高达出金操作
  **/
 is
  v_beginDate date;
  v_Balance   f_firmfunds.balance%type;
  v_cnt       number(10);
  v_rtn       number(10);
  v_errorcode number;
  v_errormsg  varchar2(200);
begin

  if p_inoutMoney = 1 then
    --入金
    update f_firmfunds
       set frozenGDFunds = frozenGDFunds + p_money
     where firmid = p_firmid;
  elsif p_inoutMoney = 2 then
    --出金
    update f_firmfunds
       set frozenGDFunds = frozenGDFunds - p_money
     where firmid = p_firmid;
  else
    insert into T_DBLog
      (err_date, name_proc, err_code, err_msg)
    values
      (sysdate, 'FN_F_UpdateFirmFunds', v_errorcode, v_errormsg);
    return - 100;
  end if;

  return 2;
exception
  when others then
    rollback;
    insert into T_DBLog
      (err_date, name_proc, err_code, err_msg)
    values
      (sysdate, 'FN_F_UpdateFirmFunds', v_errorcode, v_errormsg);
    return - 100;
end;
/

