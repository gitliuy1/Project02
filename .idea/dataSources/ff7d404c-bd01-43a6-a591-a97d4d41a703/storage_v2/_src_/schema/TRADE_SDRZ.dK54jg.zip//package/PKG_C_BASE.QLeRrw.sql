CREATE package PKG_C_Base is

    -- Author  : XUEJT
    -- Created : 2012/12/28 9:33:00
    -- Purpose : 公共包

    -- Public type declarations
    FIRM_STATUS_NORMAL constant m_firm.Status%type := 'N'; --正常 Normal
    FIRM_STATUS_DISABLE constant m_firm.Status%type := 'D'; --禁用 Disable
    FIRM_STATUS_ERASE constant m_firm.Status%type := 'E'; --删除 Erase


end PKG_C_Base;
/

