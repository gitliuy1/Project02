CREATE function FN_F_IntsTradeLogFundsZG
return number
/**
 *从直供取来的数据，生成流水
 *返回值1 生成流水成功 2.没有数据，-100失败
**/
is
  v_beginDate date;
  v_Balance f_firmfunds.balance%type;
  v_cnt number(10);
  v_errorcode      number;
  v_errormsg       varchar2(200);
  v_Balance_zg f_firmfunds_zg.balance%type;
  v_frozenzgfunds  f_firmfunds.frozenzgfunds%type;
  v_flag number:=0;
begin
  select tradedate into v_beginDate from t_systemstatus;
  --首先进行资金核对
  /*for fbalance in(select t.firmid,sum(decode(t.type,1,t.amount,-1*t.amount)) amount from f_tradelog_funds_zg t where trunc(t.createtime)<=v_beginDate and t.flag=0 group by t.firmid) loop

    begin
      select balance into v_Balance_zg from f_firmfunds_zg where firmId = fbalance.firmid;
      select frozenzgfunds into v_frozenzgfunds from f_firmfunds where firmId = fbalance.firmid;
      if(v_Balance_zg<>v_frozenzgfunds+fbalance.amount) then
        --将核对未通过的交易商放入表中
        insert into f_firmfundslog values(seq_f_firmfundslog.nextval,fbalance.firmid,'交易商直供资金为:'||v_frozenzgfunds||',直供系统期末权益为:'||v_Balance_zg||',资金变动为:'||fbalance.amount,sysdate);
        v_flag := -1;
      end if;
    exception when NO_DATA_FOUND then
      --交易商不存在
      continue;
    end;

  end loop;
  --如果资金核对未通过，直接返回
  if(v_flag=-1)then
      return 3;
  end if;*/

  select count(*) into v_cnt from f_tradelog_funds_zg  where trunc(createtime)<=v_beginDate and flag=0;
  if v_cnt>0 then
     for pFirmid in (select t.* from f_tradelog_funds_zg t,f_firmfunds f where t.firmid=f.firmid and trunc(t.createtime)<=v_beginDate and t.flag=0) loop
        if pFirmid.type=1 then   --付货款
              v_Balance := FN_F_UpdateFundsFull_ZG(pFirmid.firmid,'41003',pFirmid.amount,null,'zgcmd',null,null);
          elsif pFirmid.type=2 then  --收货款
              v_Balance := FN_F_UpdateFundsFull_ZG(pFirmid.firmid,'41002',pFirmid.amount,null,'zgcmd',null,null);
          elsif pFirmid.type=3 then  --收手续费
              v_Balance := FN_F_UpdateFundsFull_ZG(pFirmid.firmid,'41001',pFirmid.amount,null,null,null,null);
          elsif pFirmid.type=4 then  --收待返佣手续费
              v_Balance := FN_F_UpdateFundsFull_ZG(pFirmid.firmid,'41004',pFirmid.amount,null,null,null,null);
          else
             insert into T_DBLog(err_date,name_proc,err_code,err_msg)
              values(sysdate,'FN_F_IntsTradeLogFundsZG',v_errorcode,pFirmid.Id||'没有对应的科目');
             return -100;
          end if;
          update f_tradelog_funds_zg set flag=1,modifytime=trunc(sysdate) where id=pFirmid.Id;
     end loop;
     --更新版本号
     update f_tradelog_version_zg set lastVersion=currentVersion;
     return 1;
   end if;
  return 2;
end;
/

