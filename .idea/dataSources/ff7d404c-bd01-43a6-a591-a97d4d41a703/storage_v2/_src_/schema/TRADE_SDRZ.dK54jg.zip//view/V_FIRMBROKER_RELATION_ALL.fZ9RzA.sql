CREATE VIEW V_FIRMBROKER_RELATION_ALL AS
  select fb.firmid,fb.bindtime,b1.brokerid,b1.brokerlevel,b1.parentid,b1.rootbrokerid
  from br_firmandbroker fb,v_broker_relation_all b1
 where b1.brokerid=fb.brokerid
 order by b1.rootbrokerid,b1.brokerid,b1.brokerlevel
/

