CREATE function FN_BI_UnusedStocksPlusNew
(
    p_commodityid varchar2,
    p_firmid varchar2,
    p_quantity number,
    p_matchId  varchar2,
    p_goodsId  number,
    p_placeId  number
)
return integer is
  /**
  * add by lyf 20160919
  * 检查卖方交易商可用持仓
  * 返回值： -1没有符合的持仓信息
  **/
  v_cnt                  bi_stock.stockid%type; --数字变量
  v_breedid              t_commodity.breedid%type;
  v_count                number(10):=0;
  v_stockQty             number(16 ,2):=0;
  --v_propertyname         bi_goodsproperty.propertyname%type;
  RET_RESULT integer:=-10;--可配仓单不存在


begin
    select breedid into v_breedid from t_commodity where commodityid=p_commodityid;

    --添加意向货种和意向交收地匹配  2017-7-6 hanqr

      for st in (select a.stockid ,a.quantity ,a.goodsid ,a.placeid 
                   from (select t11.stockid ,t11.quantity ,t11.goodsid ,t11.placeid 
                           from bi_stock t11
                          where not exists ( select stockid from BI_StockOperation so
                                              where so.stockID = t11.stockid	
                                                and so.isgage <> 1
                                           )   
                           and stockstatus = 1
                           and breedid = v_breedid
                           and ownerfirm = p_firmid
                           and quantity <= p_quantity
                         ) a,
                         (select t21.stockid  ,t21.goodsid ,t21.placeid 
                            from bi_stock t21
                           where stockstatus = 1
                             and breedid = v_breedid
                             and ownerfirm = p_firmid
                             and quantity <= p_quantity
                             and goodsid = p_goodsId
                             and placeid = p_placeId
                          ) b
                  where a.stockid = b.stockid(+)
                  order by b.goodsid , b.placeid, a.stockid
                 ) --查询所有可用仓单
      loop

       ---验证仓单属性是否符合交收品种属性
       ---验证必须的属性
       select sum(decode(t2.propertyname,null,1,0)) into v_count  
         from (select p.propertyname,p.stockcheck from m_breed b,m_property p
                 where p.categoryid=b.categoryid and p.stockcheck='Y' and b.breedid=v_breedid order by propertyname
               ）t1
               ,(select g.stockID,g.propertyname 
                   from bi_goodsproperty g 
                  where g.stockID=st.stockid
                  order by g.stockID,g.propertyname
              )t2
        where t1.propertyname=t2.propertyname(+);
        if v_count > 0 then
           CONTINUE;
        end if;
        
       ---验证至少提供一个的属性
       select sum(decode(t2.propertyname,null,0,1)) into v_count  
         from (select p.propertyname,p.stockcheck from m_breed b,m_property p
                 where p.categoryid=b.categoryid and p.stockcheck='M' and b.breedid=v_breedid order by propertyname
               ）t1
               ,(select g.stockID,g.propertyname 
                   from bi_goodsproperty g 
                  where g.stockID=st.stockid
                  order by g.stockID,g.propertyname
              )t2
        where t1.propertyname=t2.propertyname(+);
        
        if v_count = 0 then
           CONTINUE;
        end if;
       

        v_stockQty:=v_stockQty+st.quantity;       
        ---冻结仓单
        insert into t_billfrozen (id, operation, billid, operationtype, modifytime) values (SEQ_T_BILLFROZEN.NEXTVAL, p_matchId, st.stockid, 2, sysdate);
        v_cnt:=fn_bi_frozenBill(p_commodityid,p_firmid,p_quantity,p_matchId,st.stockid) ;
        if(v_cnt<=0)then
           return v_cnt;
        end if;
           
        if (v_stockQty=p_quantity) then
          return 1;
        elsif (v_stockQty>p_quantity) then
          rollback;
          return RET_RESULT;----可配仓单不存在
        end if;
      end loop;
      
      rollback;
      return RET_RESULT;----可配仓单不存在(不足)
      
exception
    when NO_DATA_FOUND then
    --rollback;
    return -100;  --不存在相关数据
end;
/

