CREATE function FN_T_ComputeAssurePlus(
    p_FirmID               varchar2,      --交易商代号
    p_CommodityID          varchar2,      --商品代号
    p_bs_flag              number,        --买卖标识
    p_overdat              number,        --持仓到期天数，为空表示今日新增持仓
    p_quantity             number,        --数量
    p_price                number         --价格
) return number
/****
 * 根据持仓到期天数计算担保金 yuansr 2016 10 08
 * 返回值 成功返回担保金;-1 计算所需数据不全;-100 其它错误
****/
as
   v_version              varchar2(10):='1.0.0.1';
   v_marginAssure_b       number(10,4);             ---买担保金系数
   v_marginAssure_s       number(10,4);             ---卖担保金系数
   v_marginAlgr           number(2);                ---保证金算法
   v_contractFactor       number(12,2);             ---合约因子
   v_margin               number(15,2) default 0;   ---担保金
   v_getmarginsql         varchar2(2000);           ---持仓天数对应保证金阶段设置查询语句
   v_marginsetsql         varchar2(200);            --持仓天数对应保证金阶段查询语句
begin    
    --根据持仓日期 获取对应阶段的交易保证金算法设置,计算保证金 
    select case when settleDays1 is null or p_overdat is null
                then 'marginAssure_b,marginAssure_s'
                when settleDays1 is not null and p_overdat<=settleDays1 and (settleDays2 is null or p_overdat>settleDays2)
                then 'marginitemassure1 ,marginitemassure1_s'
                when settleDays2 is not null and p_overdat<=settleDays2 and (settleDays3 is null or p_overdat>settleDays3)
                then 'marginitemassure2 ,marginitemassure2_s'
                when settleDays3 is not null and p_overdat<=settleDays3 and (settleDays4 is null or p_overdat>settleDays4)
                then 'marginitemassure3 ,marginitemassure3_s'
                when settleDays4 is not null and p_overdat<=settleDays4 and (settleDays5 is null or p_overdat>settleDays5)
                then 'marginitemassure4 ,marginitemassure4_s'
                when settleDays5 is not null and p_overdat<=settleDays5
                then 'marginitemassure5 ,marginitemassure5_s'
           else 'marginAssure_b,marginAssure_s' end
      into v_marginsetsql
      from t_commodity
     where commodityid=p_CommodityID ;
    v_getmarginsql:='select marginalgr,contractfactor ,'||v_marginsetsql||'  from t_commodity where commodityid='''||p_CommodityID||'''' ;
    --dbms_output.put_line(v_getmarginsql);
    execute immediate v_getmarginsql into v_marginAlgr,v_contractFactor, v_marginAssure_b,v_marginAssure_s;

    begin
        --获取特户的交易担保金，保证金算法
        v_getmarginsql:='select marginalgr,'||v_marginsetsql||'  from T_A_FirmMargin where FirmId='''||p_FirmID||''' and commodityid='''||p_CommodityID||'''' ;
        execute immediate v_getmarginsql into v_marginAlgr, v_marginAssure_b,v_marginAssure_s;
    exception
        when NO_DATA_FOUND then
            null;
    end;

    if(v_marginAlgr=1) then  --应收保证金=数量*合约因子*价格*担保金
    	  if(p_bs_flag = 1) then  --买
        	v_margin:=p_quantity*v_contractFactor*p_price*v_marginAssure_b;
        elsif(p_bs_flag = 2) then  --卖
        	v_margin:=p_quantity*v_contractFactor*p_price*v_marginAssure_s;
        end if;
    elsif(v_marginAlgr=2) then  --应收保证金=数量*担保金
    	  if(p_bs_flag = 1) then  --买
        	v_margin:=p_quantity*v_marginAssure_b;
        elsif(p_bs_flag = 2) then  --卖
        	v_margin:=p_quantity*v_marginAssure_s;
        end if;
    end if;
    if(v_margin is null) then
    	rollback;
        return -1;
    end if;
    return v_margin;
exception
    when no_data_found then
    	rollback;
        return -1;
    when others then
    	rollback;
    	return -100;
end;
/

