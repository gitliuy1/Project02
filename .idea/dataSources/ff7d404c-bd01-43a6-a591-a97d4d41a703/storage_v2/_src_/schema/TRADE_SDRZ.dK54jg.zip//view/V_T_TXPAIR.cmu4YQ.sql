CREATE VIEW V_T_TXPAIR AS
  select h.a_holdno,
       h.CustomerID,
       h.CommodityID,
       h.BS_Flag,
       h.Price,
       h.overdat,
       h.a_tradeno,
       h.holdqty,
       h.openqty,
       h.holdtime,
       h.holdmargin,
       h.gageqty,
       h.holdassure,
       h.floatingloss,
       h.holdtype,
       h.atcleardate,
       trunc(sysdate) + case
         when (overdat - 1) < 0 then
          0
         else
          (overdat - 1)
       end deadline,
       h.remainday,
       h.firmid,
       nvl(s.ratio, 0) * nvl(h.HoldQty + h.GageQty, 0) swapfee,
       nvl(h.holdkind, 0) holdkind
  from T_HoldPosition h, swapfee s
 where h.commodityid = s.commodityid(+)
   and h.overdat = s.swapday(+)
   and h.bs_flag = s.bs_flag(+)
      --and h.firmid = '63300666'
   and h.a_holdno in
       (select t.min
          from (select max(th.a_holdno) as max, min(th.a_holdno) as min
                  from T_HoldPosition th
                 where th.a_tradeholdno is not null
                   and th.n_tradeno is not null
                   and th.f_cleardate is not null
                   and th.holdqty != 0
                --and th.firmid = '63300666'
                 group by th.a_tradeholdno, th.n_tradeno, th.f_cleardate
                 ,th.firmid
                 ) t
         where t.max != t.min)
         and h.firmid in (select t.txfirmid  from t_tx_txfirm t)
/

