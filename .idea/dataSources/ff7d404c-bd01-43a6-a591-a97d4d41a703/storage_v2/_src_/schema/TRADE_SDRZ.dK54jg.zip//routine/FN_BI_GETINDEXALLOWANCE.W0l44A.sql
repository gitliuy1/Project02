CREATE function FN_BI_getIndexAllowance( i_goodsid      varchar2       ---交易商
                                                    ,i_applyid     varchar2       ---对手交易商
)
return number as
/****
 * 功能：计算（属性）指标升贴水 yuansr 2017 06 13
 * 返回值:  指标升贴水
 *
****/
  v_indexAllowance           Bi_Stockapply.Indexallowance%type:=0;
  v_itemAllowance            Bi_Stockapply.Indexallowance%type:=0;
  v_propertyvalue            BI_GoodsPropertyApply.propertyvalue%type;
  v_count                    number(2);
  v_breedid                  Bi_Stockapply.Breedid%type;
begin
  ---1
  select t.breedid into v_breedid from bi_stockapply t where t.applyid=i_applyid;

  ---逐个计算（属性）启用的指标升贴水
  for item in (select propertyid,standardvalue,id  from M_PropertyAllowance t where t.stauts=1 and t.breedid=t.breedid and t.goodsid=i_goodsid  )
  loop
    ---获取属性值
    select t1.propertyvalue into v_propertyvalue from BI_GoodsPropertyApply t1
     where t1.propertytypeid=item.propertyid and t1.applyid=i_applyid;
    ---获取是否有对应的范围
    select count(t1.rangehigher) into v_count  from m_propertyallowanceset t1
     where t1.rangelower<=v_propertyvalue and t1.rangehigher>v_propertyvalue and t1.paid=item.id;

    if v_count>0 then
      select t1.ratio*(v_propertyvalue-t1.rangelower)  into v_itemAllowance
        from m_propertyallowanceset t1
       where t1.rangelower<=v_propertyvalue and t1.rangehigher>v_propertyvalue
         and t1.paid=item.id;
    else
      select t1.ratio*(v_propertyvalue-t1.rangelower)  into v_itemAllowance
        from m_propertyallowanceset t1
       where t1.rangelower<v_propertyvalue and t1.rangehigher>=v_propertyvalue
         and t1.paid=item.id;
    end if;

    v_indexAllowance:=v_indexAllowance+v_itemAllowance;
  end loop;

  return v_indexAllowance;

end;
/

