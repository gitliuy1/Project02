CREATE function FN_T_D_SellSettleOrder(  p_FirmID              varchar2,    --交易商ID
                                                    p_TraderID            varchar2,    --交易员ID
                                                    p_CommodityID         varchar2,    --商品ID
                                                    p_Quantity            number,      --数量
                                                    p_Price               number,      --委托价格，行情结算价
                                                    p_CustomerID          varchar2,    --交易客户ID
                                                    p_ConsignerID         varchar2,    --代为委托员ID
                                                    p_DelayQuoShowType    number,      --延期行情显示类型，0：交收申报结束和中立仓申报结束显示；
                                                                                       --- 1：实时显示；
                                                    p_DelayNeedBill       number,      --延期交收是否需要仓单，0：不需要； 1：需要；
                                                    p_delayMoney          number,       --申报金额
                                                    p_txFirmId            varchar2      --特许服务商ID
                                                    ,p_preStockids        varchar2     ---意向仓单 yuansr 2017 07 07
) return number
/****
 * 卖交收申报委托
 * 根据配置修改申报数量判断，用净订货量还是单边总持仓判断 by chenxc 2011-09-20
 * 返回值
 * >0  成功提交，并返回委托单号
 * -2  资金余额不足
 * -31  持仓不足
 * -32  仓单数量不足
 * -33  意向仓单不可用
 * -51  冻结意向仓单失败
 * -99  不存在相关数据
 * -100 其它错误
 * 修改：冻结持仓明细——yuansr 2016 10 24
 * 原因：交易保证金 按持仓到期天数确认对应阶段，再按照对应阶段计算交易保证金，需要必须冻结持仓明细 
****/
as
    v_version               varchar2(10):='1.0.2.3';
    v_HoldSum               number(10):=0;                 --卖方持仓合计数量
    v_SettleMargin_S        number(15,2);                  --卖方交收保证金
    v_SettleMargin_SSum     number(15,2):=0;               --卖方交收保证金汇总
    v_TradeMargin_S         number(15,2);                  --卖方交易保证金
    v_TradeMargin_SSum      number(15,2):=0;               --卖方交易保证金汇总
    v_F_Funds               number(15,2):=0;               --应冻结资金
    v_A_Funds               number(15,2);                  --可用资金
    v_F_FrozenFunds         number(15,2);                  --财务冻结资金
    v_ret                   number(4);
    v_A_OrderNo             number(15);                    --委托单号
    v_HoldOrderNo           number(15):=0;                 --持仓委托单号
    v_errorcode             number;
    v_errormsg              varchar2(200);
    v_DelayOrderIsPure      number(1);                     --交收申报是否按净订货量申报
    v_HoldSum_S             number(10):=0;                 --卖方持仓合计数量
    v_DelaySettlePriceType  number(10);                    --交收申报交收类型 0：按结算价交收申报 ， 1：按订立价交收  -- add  by zhangjian
    v_sql                   varchar2(1200);
    v_qtySum                number(15):=0;                 --已委托的交收申报冻结数量
    v_price                 number(15,6);                  --交收申报价格
    v_theOrderPriceSum      number(15,6):=0;               --本次交收申报订立价格汇总
    v_holdQty               number(15):=0;                 --每笔持仓明细中的持仓数量
    v_tempQty               number(15):=0;                 --中间变量
    v_alreadyQty            number(15):=0;                 --本次委托已冻结数量
    type cur_T_HoldPosition is ref cursor;
    v_HoldPosition          cur_T_HoldPosition;
    v_orderLogNo            number(15):=0;                 --委托下单日志 ID。
    v_orderSumLogNo         number(15):=0;                 --委托下单日志合计数据 ID；
    v_HoldSum_B             number;
    v_breedid               varchar2(12);
    v_billQty               number(12):=0;
    v_A_OrderNo_L           number(15);                    --临时委托单号
    v_holdUsedQty           number(15):=0;                 --每笔持仓明细中的可用持仓数量
    v_holdEvenPrice         number(15,6);                  --持仓均价,订立均价
    v_Overdat               number(10);                    -- 到期天数
    v_Fee                   number(15, 2) := 0;      --- 合计交收手续费 yuansr 2017 04 21
    v_Fee_one               number(15, 2) := 0;      ---一条记录的交收手续费
    v_contractfactor        number(12,2);            ---合约因子 用于计算仓单手数 yuansr 2017 06 30
    type c_item is ref cursor;                       ----增加意向仓单处理 yuansr 2017 07 07
    v_item                  c_item;
    v_result                number(2);
    v_stockId               bi_stock.stockid%type;
    v_stockids              T_DelayOrders.Stockids%type :=''; 
    v_gageqty                 number(15) ;                --抵顶数量
    v_frozengageqty           number(15) ;                --抵顶交收数量
    v_purposebillQty          number(15) ;                --意向仓单数量
begin
  --1 、检查持仓并冻结持仓
  begin
      select nvl(holdQty - frozenQty, 0) into v_HoldSum
        from T_CustomerHoldSum
       where CustomerID = p_CustomerID  and CommodityID = p_CommodityID and bs_flag = 2 for update;
  exception
        when NO_DATA_FOUND then
           rollback;
           return -31;  --持仓不足
  end;
  --2 、获取市场净订货量申报设置，交收申报是否按净订货量申报
  select DelayOrderIsPure into v_DelayOrderIsPure from T_A_Market;
  
  if(v_DelayOrderIsPure = 1) then --按净订货量申报
      begin
        select holdQty+GageQty into v_HoldSum_B
        from T_CustomerHoldSum
        where CustomerID = p_CustomerID and CommodityID = p_CommodityID and bs_flag = 1 ;
    exception
          when NO_DATA_FOUND then
              v_HoldSum_S := 0;
      end;
      if(v_HoldSum-v_HoldSum_B < p_Quantity) then
          rollback;
          return -31;  --净订货量不足
      end if;
  else
      if(v_HoldSum < p_Quantity) then
          rollback;
          return -31;  --持仓不足
      end if;
  end if;

  /***************冻结持仓（持仓合计、持仓明细），计算合计交易保证金、交收保证金,计算平均订立价格 yuansr 2016 10 24**********************************/
  v_qtySum              :=0;                --初始 已完成委托（冻结持仓明细持仓）的数量；
  v_alreadyQty          :=0;                --初始已遍历持仓明细 持仓合计 
  v_theOrderPriceSum    :=0;
  v_TradeMargin_SSum    :=0;
  v_SettleMargin_SSum   :=0;
  v_holdEvenPrice       :=0;
  v_Fee                 :=0;
  --创建临时委托代号
  select SEQ_T_S_OrderFrozenHold.nextval into v_A_OrderNo_L from dual;
  ---锁持仓明细表（上面 已锁），再从持仓明细查询可用持仓（持仓+抵顶-交易冻结-申报冻结）,抵顶数量可做交收，根据持仓单号，先入先出
  v_sql:=' select a.price ,a.overdat,a.HoldQty ,a.gageqty +a.HoldQty-nvl(b.FrozenQty,0)-nvl(c.FrozenQty,0) ,a.A_HoldNo ' 
             ||'  ,nvl(a.GageQty,0)-nvl(frozengageqty,0) ' 
       ||'   from T_holdposition a,(select A_HoldNo,sum(frozenqty) frozenqty from T_SpecFrozenHold group by A_HoldNo) b '
       ||'        ,(select A_HoldNo,sum(frozenqty - unfrozenqty + frozengageqty - unfrozengageqty ) FrozenQty '
       ||'                 ,sum(frozengageqty - unfrozengageqty) frozengageqty  '
       ||'            from T_S_OrderFrozenHold group by A_HoldNo) c'---有效冻结=冻结-解冻
       ||'  where (a.HoldQty+a.gageqty) > (nvl(b.FrozenQty,0)+nvl(c.FrozenQty,0)) and a.A_HoldNo=b.A_HoldNo(+) and a.A_HoldNo=c.A_HoldNo(+) '
       ||'    and CustomerID='''||  p_CustomerID ||'''  and CommodityID ='''|| p_CommodityID||''' and bs_flag =  2   '
       ||'  order by a.A_HoldNo  for update of a.A_HoldNo ';---并锁住持仓
  open v_HoldPosition for v_sql;
  loop
      fetch v_HoldPosition into v_price,v_Overdat,v_holdQty,v_holdUsedQty,v_HoldOrderNo ,v_gageqty;
       exit when v_HoldPosition%NOTFOUND;
      v_alreadyQty:=v_holdQty+v_alreadyQty;--已遍历持仓明细 持仓合计 
      v_tempQty:=0; --每次清空应冻结数量
      --v_TradeMargin_S := 0;
      --v_SettleMargin_S := 0;

      if(p_Quantity>v_qtySum)then --计算交收货款以及交收保证金累积，必须是大于当前延期委托表中已经存在的。
         if(p_Quantity>=(v_qtySum+v_holdUsedQty))then
             v_tempQty:=v_holdUsedQty;--可用数量全部冻结
             v_qtySum:=v_tempQty+v_qtySum;             
         else  --如果不满足当前条件则退出遍历
             v_tempQty:=p_Quantity-v_qtySum;--可用数量部分冻结
             v_qtySum:=p_Quantity;
         end if;
       end if;
       
       v_frozengageqty:=0;
       if v_gageqty>0 then ---有抵顶，优先使用抵顶进行交收 yuansr 2017 07 27
         v_frozengageqty:=v_gageqty;
         if v_tempQty<v_gageqty then 
           v_frozengageqty:=v_tempQty; ---抵顶数大于交收数，使用交收数量的抵顶；
         end if;
       end if;

       ---冻结持仓明细，记录冻结详情
       v_price:= p_delayMoney;--modify by lyf 20160810 修改申报时候冻结保证金用申报金额来计算
       --计算交易保证金,抵顶部因为没有收保证金，所以也不退交易保证金 yuansr 2017 07 27
       v_TradeMargin_S := FN_T_ComputeMargin_ZSSPlus(p_FirmID,p_CommodityID,2,v_Overdat,v_tempQty-v_frozengageqty,v_price);
       --计算交收保证金 modify by lyf 20160810 修改交收保证金计算价格 取交收申请价格（申报金额）
       --抵顶部分，继续做交收抵顶，不收交收保证金 yuansr 2017 07 27
       v_SettleMargin_S := FN_T_ComputeSettleMargin_ZSS(p_FirmID,p_CommodityID,2,v_tempQty-v_frozengageqty,v_price);
       v_TradeMargin_SSum :=v_TradeMargin_SSum+v_TradeMargin_S;--累加交易保证金
       v_SettleMargin_SSum :=v_SettleMargin_SSum+v_SettleMargin_S;--累加交收保证金
       
       v_Fee_one := FN_T_ComputeSettleFee(p_FirmID,p_CommodityID,  2,v_tempQty , v_price);---交收手续费 yuansr 2017 04 21
       v_Fee     := v_Fee+v_Fee_one;--累加交收手续费 yuansr 2017 04 21

       --添加冻结持仓记录，更新交易客户持仓明细表 冻结数量 add by yuansr 2016 10 24
       insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty ,Frozengageqty )
       values( v_A_OrderNo_L  ,v_HoldOrderNo  ,2  ,v_tempQty-v_frozengageqty   ,v_tempQty-v_frozengageqty  ,0   ,v_frozengageqty   );

       --循环每笔持仓明细都要插入委托日志  add by zhangjian 2012年3月2日
       select SEQ_T_D_OrderLog.nextval into v_orderLogNo  from dual  ;
       insert into T_D_DelayOrderLog  values ( v_orderLogNo,p_firmid,2,p_CommodityID,v_HoldOrderNo,v_price,v_tempQty
                                               ,v_SettleMargin_S,v_TradeMargin_S,0,Sysdate,null );

       v_theOrderPriceSum :=v_theOrderPriceSum+v_price*v_tempQty;--累加订立金额       
       if(v_qtySum=p_Quantity)then--完成委托数量的冻结，退出循环则计算平均订立价格
         v_holdEvenPrice:=v_theOrderPriceSum/p_Quantity;
         exit;
       end if;
  end loop;

  --3 、获取交收申报价格类型设置，判断如何冻结资金。0：按结算价交收 ；1：按订立价交收  mod by zhangjian
  select DelaySettlePriceType ,contractfactor ,breedid   
    into v_DelaySettlePriceType ,v_contractfactor ,v_breedid ---合约因子 用于计算仓单手数 yuansr 2017 06 30
    from t_commodity where commodityid=p_CommodityID;
  if(v_DelaySettlePriceType=1) and v_holdEvenPrice>0 then -- 如果是按订立价交收,使用订立均价
    v_price:=v_holdEvenPrice;
  end if;

  --4 、计算、更新冻结资金
  v_F_Funds := v_SettleMargin_SSum - v_TradeMargin_SSum +v_Fee;---增加冻结交收手续费 yuansr 2017 04 21
  --计算可用资金，并锁住财务资金
  v_A_Funds := FN_F_GetRealFunds(p_FirmID,1);

  if(v_A_Funds < v_F_Funds) then
    rollback;
    return -2;  --资金余额不足
  end if;

  --插入延期委托合计表日志   --add by zhangjian  2012年3月2日
  select SEQ_T_D_OrderSumLog.nextval  into v_orderSumLogNo from dual;
  insert into  T_D_DelayOrderSumLog values (v_orderSumLogNo,p_firmid,2,p_CommodityID,v_price,p_Quantity,v_SettleMargin_SSum,v_TradeMargin_SSum
               ,0,v_A_Funds,v_F_Funds,Sysdate,null);

  --5 、更新交易客户持仓合计的冻结数量
  update T_CustomerHoldSum set frozenQty = frozenQty + p_Quantity
   where CustomerID = p_CustomerID and CommodityID = p_CommodityID and bs_flag = 2;

  --6 、根据参数是否需要检查并冻结仓单
  if(p_DelayNeedBill = 1) then
    v_ret := FN_T_D_CheckAndFrozenBill(p_FirmID,p_CommodityID,p_Quantity*v_contractfactor);
    if(v_ret = -1) then
          rollback;
          return -32;  --仓单数量不足
    end if;
  end if;

  --start add by lyf 20160802 判断该交收申请人是否有可用仓单
  --select breedid into v_breedid from t_commodity where commodityid=p_CommodityID;
  begin
    select nvl(a.quantity, 0) - nvl(b.frozen, 0) into v_billQty
     from  (select sum(quantity) quantity, breedid, ownerfirm from bi_stock s 
             where not exists (select stockid from BI_StockOperation so  where so.stockID = s.stockid ) and s.stockstatus = 1 
               --and IsInSplitArray(s.stockid,p_preStockids,',')=1 --意向仓单 yuansr 2017 08 07
             group by breedid, ownerfirm
           ) a,
           (select nvl(sum(frozen), 0) frozen, firmid, breedid from br_billQtyFrozen  group by breedid, firmid) b
     where b.breedid(+) = a.breedid  and b.firmid(+) = a.ownerfirm and ownerfirm = p_FirmID and a.breedid = v_breedid;
    
    if v_billQty <= 0 then
        rollback;
        return -32;  --仓单数量不足
    elsif v_billQty-(p_Quantity*v_contractfactor)<0 then
        rollback;
        return -32;  --仓单数量不足
    end if;
  exception
  when NO_DATA_FOUND then
       begin
        select nvl(sum(quantity),0) into v_billQty from bi_stock s
        where not exists (select stockid from BI_StockOperation so where so.stockID = s.stockid)
        and s.stockstatus = 1 and s.breedid = v_breedid and s.ownerfirm = p_FirmID ;
        if v_billQty <= 0 then
            rollback;
            return -32;  --仓单数量不足
        end if;
      exception
      when NO_DATA_FOUND then
           rollback;
           return -32;  --仓单数量不足
      end;
  end;

--单独验证意向仓单数量 2017-8-30 hanqr
  begin
    select nvl(sum(quantity),0) quantity into v_purposebillQty from bi_stock s 
        where not exists (select stockid from BI_StockOperation so  where so.stockID = s.stockid) and s.stockstatus = 1 
        and IsInSplitArray(s.stockid,p_preStockids,',')=1; 

    if v_purposebillQty <= 0 then
        rollback;
        return -33;  --意向仓单不可用
    elsif v_purposebillQty-(p_Quantity*v_contractfactor)<0 then
        rollback;
        return -33;  --意向仓单不可用
    end if;
  exception
  when NO_DATA_FOUND then
       rollback;
       return -33;  --意向仓单不可用
        
  end;

  --7 、更新冻结资金
  v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID,v_F_Funds,'15');
  -->>======================================================================
  --8 、插入延期委托表，并返回委托单号
  select SEQ_T_DelayOrders.nextval into v_A_OrderNo from dual;
  --记录委托信息
  insert into T_DelayOrders
    ( a_orderno,    CommodityID,   CustomerID,    traderid,   bs_flag, DelayOrderType, status, quantity, price, tradeqty, frozenfunds, unfrozenfunds, ordertime, withdrawtime, ordererip, signature,  FirmID ,ConsignerID,  delayMoney,a_holdno,aHoldFlag,txFirmId)
  values
    (v_A_OrderNo,  p_CommodityID, p_CustomerID,  p_TraderID,     2,           1,          1,  p_Quantity, v_price,  0,      v_F_Funds,         0,         sysdate,      null,       null,     null,     p_FirmID ,p_ConsignerID,p_delayMoney,'-1',2,p_txFirmId);
  --9 、更新 交收申报委托持仓关系表 ：使用委托单号替换 临时委托代号
  update T_S_OrderFrozenHold t set t.a_orderno=v_A_OrderNo  where t.a_orderno=v_A_OrderNo_L;
  -- add by lyf 20160804 增加冻结仓单
  -- 意向仓单会添加业务表bi_stockoperation，计算可用数量时会排除掉，不需要再次冻结
  --insert into br_billQtyFrozen values(v_A_OrderNo,p_TraderID,p_Quantity*v_contractfactor,p_CommodityID,v_breedid,sysdate,'');

  --10 、行情实时显示则要更新行情
  if(p_DelayQuoShowType = 1) then
    update T_DelayQuotation set SellSettleQty=SellSettleQty + p_Quantity,CreateTime=sysdate where CommodityID = p_CommodityID;
  end if;

  ---11 验证是否有指定意向仓单，有则冻结、记录指定意向仓单 yuansr 2017 07 07
  v_sql:='select t.stockid  from bi_stock t where t.ownerfirm='''||p_FirmID||''''
       ||'   and t.stockstatus=1 and t.stockid in('''|| replace(p_preStockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND; 
       --冻结意向仓单
       v_result:=FN_BI_FrozenPurposeBill(p_FirmID ,'15'  ,v_stockId);
       --记录意向仓单
       insert into T_D_PurposeBill (a_orderno, stockid, status, kind ) values ( v_A_OrderNo ,v_stockId,1,1);
       if v_result<>1 then
          rollback;
          return -33;
       end if;
       v_stockids:=v_stockids||','||v_stockId;
  end loop;
  close v_item;

  if (p_preStockids is not null and length(p_preStockids )>0 )  then
    if( length(','||p_preStockids) = length(v_stockids) ) then
        v_stockids:=p_preStockids;
     else
       rollback;
        return -33; 
     end if;
  else
    v_stockids:=p_preStockids;
  end if;
  ---委托表记录意向仓单 yuansr 2017 07 07
  update T_DelayOrders t set t.stockids=v_stockids where t.a_orderno=v_A_OrderNo;
  
  commit;
  return v_A_OrderNo;

exception
    when NO_DATA_FOUND then
        rollback;
        return -99;  --不存在相关数据
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_T_D_SellSettleOrder',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

