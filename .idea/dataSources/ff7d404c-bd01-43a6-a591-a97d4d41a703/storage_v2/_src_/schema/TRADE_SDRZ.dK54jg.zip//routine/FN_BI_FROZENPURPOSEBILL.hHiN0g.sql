CREATE function FN_BI_FrozenPurposeBill
(
    p_firmid   varchar2,
    p_modelid  varchar2,
    p_stockid  varchar2
)
return integer is
/****
  * 功能：冻结意向仓单
  * 返回值： 1 成功、-6.不存在p_stockid持仓单号 -7.仓单用户不匹配  -8. 仓单未注册  -9.  仓单已出库 -11.仓单不是注册状态  -12.仓单已被使用
  **/
  v_cnt            number(4); --数字变量
  v_quantity       bi_stock.quantity%type;
  v_ownerfirm      bi_stock.ownerfirm%type;
  v_stockstatus    bi_stock.stockstatus%type;
  RET_RESULT       integer:=-100;--未知异常
begin
    begin
       select quantity, ownerfirm, stockstatus into v_quantity, v_ownerfirm, v_stockstatus from BI_Stock t where stockID=p_stockid for update;
    exception
       when NO_DATA_FOUND then
       return -6;
    end;

    if v_ownerfirm!=p_firmid then
       return -7;
    end if;
    if v_stockstatus=0 then
       return -8;
    end if;
    if v_stockstatus=2 then
       return -9;
    end if;
    if v_stockstatus !=1 then
       return -11;
    end if;
    select count(*) into v_cnt from BI_StockOperation t where stockID=p_stockid and isgage <> 1;
    if v_cnt>0 then
       return -12;
    end if;
    insert into BI_StockOperation(StockID,OperationID) values(p_stockid,5);
    ---写冻结记录
    insert into BI_FrozenStock(FrozenStockID,StockID,moduleid,Status,CreateTime)
    values (SEQ_BI_FROZENSTOCK.nextval ,p_stockid ,p_modelid ,0,sysdate );
    ---写冻结日志
    insert into c_globallog_all(id,operator,operatetime,operatetype,operatecontent,operateresult,logType)
    values (SEQ_C_GLOBALLOG.Nextval,'db', sysdate,1301,'串换冻结'||p_stockid,1,3);

    return 1;
exception
    when NO_DATA_FOUND then
    --rollback;
    return RET_RESULT;
end;
/

