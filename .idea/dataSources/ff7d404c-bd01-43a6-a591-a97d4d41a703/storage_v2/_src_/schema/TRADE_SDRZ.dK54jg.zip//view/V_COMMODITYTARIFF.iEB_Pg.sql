CREATE VIEW V_COMMODITYTARIFF AS
  select tariffID,
    decode(t.FEEALGR,1,to_char(t.FEERATE_B * 100, 'fm9999999990.009999') || '%',to_char(t.FEERATE_B, 'fm9999999990.009999')) newFeeRate_B,
    decode(t.FEEALGR,1,to_char(t.FEERATE_S * 100, 'fm9999999990.009999') || '%',to_char(t.FEERATE_S, 'fm9999999990.009999')) newFeeRate_S,
    decode(t.FEEALGR,1,to_char(t.TodayCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(t.TodayCloseFeeRate_B, 'fm9999999990.009999')) newTodayCloseFeeRate_B,
    decode(t.FEEALGR,1,to_char(t.TodayCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(t.TodayCloseFeeRate_S, 'fm9999999990.009999')) newTodayCloseFeeRate_S,
    decode(t.FEEALGR,1,to_char(t.HistoryCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(t.HistoryCloseFeeRate_B, 'fm9999999990.009999')) newHistoryCloseFeeRate_B,
    decode(t.FEEALGR,1,to_char(t.HistoryCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(t.HistoryCloseFeeRate_S, 'fm9999999990.009999')) newHistoryCloseFeeRate_S,
    decode(t.ForceCloseFeeAlgr,1,to_char(t.ForceCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(t.ForceCloseFeeRate_B, 'fm9999999990.009999')) newForceCloseFeeRate_B,
    decode(t.ForceCloseFeeAlgr,1,to_char(t.ForceCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(t.ForceCloseFeeRate_S, 'fm9999999990.009999')) newForceCloseFeeRate_S,
    decode(c.FEEALGR,1,to_char(c.FEERATE_B * 100, 'fm9999999990.009999') || '%',to_char(c.FEERATE_B, 'fm9999999990.009999')) oldFeeRate_B,
    decode(c.FEEALGR,1,to_char(c.FEERATE_S * 100, 'fm9999999990.009999') || '%',to_char(c.FEERATE_S, 'fm9999999990.009999')) oldFeeRate_S,
    decode(c.FEEALGR,1,to_char(c.TodayCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(c.TodayCloseFeeRate_B, 'fm9999999990.009999')) oldTodayCloseFeeRate_B,
    decode(c.FEEALGR,1,to_char(c.TodayCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(c.TodayCloseFeeRate_S, 'fm9999999990.009999')) oldTodayCloseFeeRate_S,
    decode(c.FEEALGR,1,to_char(c.HistoryCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(c.HistoryCloseFeeRate_B, 'fm9999999990.009999')) oldHistoryCloseFeeRate_B,
    decode(c.FEEALGR,1,to_char(c.HistoryCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(c.HistoryCloseFeeRate_S, 'fm9999999990.009999')) oldHistoryCloseFeeRate_S,
    decode(c.ForceCloseFeeAlgr,1,to_char(c.ForceCloseFeeRate_B * 100, 'fm9999999990.009999') || '%',to_char(c.ForceCloseFeeRate_B, 'fm9999999990.009999')) oldForceCloseFeeRate_B,
    decode(c.ForceCloseFeeAlgr,1,to_char(c.ForceCloseFeeRate_S * 100, 'fm9999999990.009999') || '%',to_char(c.ForceCloseFeeRate_S, 'fm9999999990.009999')) oldForceCloseFeeRate_S,
     t.MODIFYTIME,t.createUser,t.TariffName,TariffRate * 100 || '%' TARIFFRATE,c.name,t.commodityID from T_A_Tariff t, T_COMMODITY c where t.commodityid = c.commodityid
/

