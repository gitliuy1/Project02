CREATE function fn_br_r_getrewardproportions (
       p_grade           number  ---加盟商级别
       ,p_topbrokerid    varchar2  ---设置返佣比例的加盟商，市场为 null 或‘-1’
       ,p_brokerid       varchar2  ---加盟商代号
) return number
/*********************************
 * 获取佣金比例 yuansr 2017 02 08
 *  1 特殊佣金比例 > 通用返佣比例优先
 *  2 当对应级别没有设置佣金比例时，返回0
 *返回值：
 *   佣金比例
 *
 ********************************/
is
    v_proportion      br_r_rewardproportions.proportion%type;
    v_topbrokerid     br_r_rewardproportions.memberid%type:=p_topbrokerid;---默认时市场设置

begin

    if (p_grade is null) or (p_grade<1) then
         Raise_application_error(-19061, 'p_grade value error!');---参数错误
    end if;
    
    begin
        select t.proportion into v_proportion from  br_r_rewardproportionssep t  
         where t.brokerid=p_brokerid for update;
    exception
          when NO_DATA_FOUND then --无特殊设置
               v_proportion:=null;
    end;
    
    if(v_proportion is not null ) then
        return v_proportion;
    end if;

    --无特殊设置则获取通用设置
    if( p_grade=1 ) then --市场设置
        select nvl(proportion,0) into v_proportion  from br_r_rewardproportions t
         where t.grade=p_grade and t.memberid='-1'  for update;
    else--综合会员设置
        begin
            select nvl(proportion,0) into v_proportion from br_r_rewardproportions t
             where t.grade=p_grade and t.memberid=v_topbrokerid   for update;
        exception
              when NO_DATA_FOUND then 
                   v_proportion:=0;
        end;
    end if;

    return v_proportion;

end;
/

