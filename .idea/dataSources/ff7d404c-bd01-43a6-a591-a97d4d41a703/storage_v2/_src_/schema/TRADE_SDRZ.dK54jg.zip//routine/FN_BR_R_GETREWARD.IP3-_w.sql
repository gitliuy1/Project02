CREATE function fn_br_r_getreward (
       --p_startDate         date,  ---计算开始日期
       p_endDate           date  ---计算截止日期
) return number
/*********************************
 * 佣金计算方法：（验证计算前提）
 *   1 统计交易商成交情况
 *   2 统计会员（下辖交易商合计）成交情况
 *   3 根据设置 计算 对应的佣金
 *返回值：
 *   1=计算成功；-1=不是闭市计算完成状态；-2=财务结算已完成；-3=佣金已结算；-100= 系统异常，计算失败；
 *
 ********************************/
is
    v_b_date              date;           ---结算系统日期
    v_max_grade           number(2,0);    ---会员最大级别
    v_trade_date          date;           ---结算系统日期
    v_status              number(2,0) ;   --系统状态
    v_errorcode           number;
    v_errormsg            varchar2(200);
begin

    ---截止日期 必须是已结算，且系统必须处于结算完成状态：交易日
    select tradedate ,status  into v_trade_date，v_status from t_systemstatus t for update;
    if p_endDate>v_trade_date or v_status<>10 then
       return -1;----不是闭市计算完成状态
    end if;

    select status  into v_status from f_systemstatus t for update;

    if v_status=2 then
      return -2;----财务结算已完成
    end if;

    ---update br_r_systemstatus t set t.status=1 where t.status in(0,2) ;
    select status,b_date into v_status,v_b_date from br_r_systemstatus t for update nowait;

    if v_status not in (0,2) then
       return -3;----已处于结算返款后,或计算中
    end if;

    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=1;
    update br_r_systemstatus t set t.status=1;
    commit;

    select status,b_date into v_status,v_b_date from br_r_systemstatus t for update nowait;

    ----删除数据，再重新统计
    delete br_r_firmcomoditydaytrade t where t.cleardate=p_endDate;
    ---统计交易商数据
    insert into br_r_firmcomoditydaytrade (cleardate  ,firmid   , commodityid  ,brokerid    ,fee   ,qty   ,amount ,appendfee  )
    select t1.cleardate ,t1.firmid ,t1.commodityid  ,t3.brokerid  ,sum(t1.tradefee) ,sum(t1.quantity)
           ,sum(t1.price*t1.quantity*t2.contractfactor)
           ,sum(FN_BR_BrokerEveryTradeReward(t1.commodityid,t1.quantity,t1.tradefee,t1.price*t1.quantity*t2.contractfactor,t1.atcleardate
                                             ,t1.tradeatcleardate,t1.bs_flag,t1.ordertype, t1.tradetype, 0)) ---加收手续费
      from t_h_trade t1 ,t_h_commodity t2 ,br_firmandbroker t3
     where t1.commodityid=t2.commodityid and t1.firmid=t3.firmid and t1.cleardate=p_endDate  and t2.cleardate=p_endDate
     group by t1.cleardate,t1.commodityid,t1.firmid,t3.brokerid;

    ---更新交易商所属顶级会员,佣金
    update br_r_firmcomoditydaytrade t
       set (t.topbrokerid,t.reward)
         = ( select b2.brokerid,trunc(nvl(prs.proportion,pr.proportion)*(t.fee-nvl(t.appendfee,0)),2)+nvl(t.appendfee,0) ---必须保留两位小数向下取值，才能保证下级比例佣金合计不会超过上级
               from br_broker_relation b2,br_broker_relation b1,br_r_rewardproportions pr,br_r_rewardproportionssep prs
              where b1.brokerid in
                    ( select b.brokerid
                        from br_broker_relation b
                     CONNECT BY b.parentid = prior b.brokerid AND b.brokerid != b.parentid
                       start with b.brokerid=b2.brokerid  and b.brokerlevel=1
                     )
                and prs.brokerid(+)=b2.brokerid
                and b2.brokerlevel =1 and b1.brokerid=t.brokerid
                and pr.grade=1
            )
    where t.cleardate=p_endDate;

    ---更新交易商市场留存，首款为0 ,尾款100%(默认手动付款方式,系统自动返款时更新此项)
    update br_r_firmcomoditydaytrade t set t.marketreward = t.fee-t.reward  ,t.firstpay = 0 ,t.secondpay=t.reward
    where t.cleardate=p_endDate;
    
    ----删除数据，再重新统计
    delete BR_R_FIRMSALEREWARD t where t.cleardate=p_endDate;
    ---统计交易商直供返佣数据
    insert into BR_R_FIRMSALEREWARD (cleardate  ,firmid  ,brokerid    ,fee  )
    select p_endDate ,t1.firmid ,t3.brokerid  ,sum(t1.amount) 
      from f_fundflow t1 ,br_firmandbroker t3
     where t1.firmid=t3.firmid and t1.oprcode = 41004 --and trunc(t1.createtime)=p_endDate  --摘要号41004直供收待返佣手续费
     group by t1.firmid,t3.brokerid;
     
    ---更新交易商所属顶级会员,佣金
    update BR_R_FIRMSALEREWARD t
       set (t.topbrokerid,t.reward)
         = ( select b2.brokerid,trunc(nvl(prs.proportion,pr.proportion)*(t.fee),2) ---必须保留两位小数向下取值，才能保证下级比例佣金合计不会超过上级
               from br_broker_relation b2,br_broker_relation b1,br_r_rewardproportions pr,br_r_rewardproportionssep prs
              where b1.brokerid in
                    ( select b.brokerid
                        from br_broker_relation b
                     CONNECT BY b.parentid = prior b.brokerid AND b.brokerid != b.parentid
                       start with b.brokerid=b2.brokerid  and b.brokerlevel=1
                     )
                and prs.brokerid(+)=b2.brokerid
                and b2.brokerlevel =1 and b1.brokerid=t.brokerid
                and pr.grade=1
            )
    where t.cleardate=p_endDate;  
    
     ---更新交易商市场留存，首款为0 ,尾款100%(默认手动付款方式,系统自动返款时更新此项)
    update BR_R_FIRMSALEREWARD t set t.marketreward = t.fee-t.reward  ,t.firstpay = 0 ,t.secondpay=t.reward
    where t.cleardate=p_endDate;   
    

    ----删除数据，再重新统计
    delete br_r_rewardinfo t where t.cleardate=p_endDate;
    ---获取最大（最底层）会员级别，便于循环
    select max(t.brokerlevel) into v_max_grade from br_broker_relation t;
    ---从低到高逐层处理
    for igrade in 0..v_max_grade-1 loop
        ---统计会员相关交易数据
        insert into br_r_rewardinfo ( brokerid ,cleardate ,parentid ,grade ,fee ,amount ,qty ,subreward,appendfee,appendfeesum,topbrokerid,salefee,salesubreward )
        select t1.brokerid,p_endDate,t1.parentid,t1.brokerlevel,nvl(sum(t2.fee),0)+nvl(sum(t4.fee),0)
               ,nvl(sum(t2.amount),0)+nvl(sum(t4.amount),0) ,nvl(sum(t2.qty),0)+nvl(sum(t4.qty),0),nvl(sum(t4.allreward),0)
               ,nvl(sum(t2.appendfee),0) ,nvl(sum(t2.appendfee),0)+nvl(sum(t4.appendfeesum),0)
               ,decode(t2.topbrokerid,null,decode(t4.topbrokerid,null,t3.topbrokerid,t4.topbrokerid),t2.topbrokerid)
               ,nvl(sum(t3.fee),0)+nvl(sum(t4.salefee),0) ,nvl(sum(t4.saleallreward),0)
          from br_broker_relation t1
               ,( select brokerid,topbrokerid , sum(fee) fee, sum(qty) qty,  sum(amount) amount ,nvl(sum(nvl(appendfee,0)),0) appendfee
                    from br_r_firmcomoditydaytrade  where cleardate = p_endDate
                group by brokerid ,topbrokerid
               ) t2
               ,( select brokerid,topbrokerid , sum(fee) fee
                    from BR_R_FIRMSALEREWARD  where cleardate = p_endDate
                group by brokerid ,topbrokerid
               ) t3
               ,( select parentid ,topbrokerid , sum(fee) fee, sum(qty) qty,  sum(amount) amount,sum(allreward) allreward 
                    ,nvl(sum(nvl(appendfeesum,0)),0) appendfeesum ,sum(salefee) salefee ,sum(saleallreward) saleallreward 
                    from br_r_rewardinfo where grade=v_max_grade-igrade+1 and cleardate = p_endDate
                   group by parentid ,topbrokerid
               ) t4
         where t1.brokerid=t2.brokerid(+) and t1.brokerid=t3.brokerid(+) and t1.brokerid=t4.parentid(+) and t1.brokerlevel= v_max_grade-igrade
           and (t4.parentid is not null or t2.brokerid is not null or t3.brokerid is not null) ----去除无相关成交数据的会员记录
         group by t1.brokerid,t1.parentid,t1.brokerlevel,decode(t2.topbrokerid,null,decode(t4.topbrokerid,null,t3.topbrokerid,t4.topbrokerid),t2.topbrokerid);
         ---获取返佣比例统计会员相关交易数据
        update br_r_rewardinfo t
           set t.proportion= fn_br_r_getrewardproportions(v_max_grade-igrade ,topbrokerid,t.brokerid )
         where t.grade=v_max_grade-igrade and t.cleardate = p_endDate;
        update br_r_rewardinfo t
         set t.allreward=trunc( ( t.fee- nvl(t.appendfeesum,0) )*t.proportion ,2 )  ---必须保留两位小数向下取值，才能保证下级比例佣金合计不会超过上级
             ,t.saleallreward = trunc( t.salefee * t.proportion , 2 )
       where t.grade=v_max_grade-igrade and t.cleardate = p_endDate;
    end loop;
    ---计算佣金
    update br_r_rewardinfo t set t.reward = nvl(t.allreward,0) - nvl(t.subreward,0) + nvl(t.appendfee,0)
           ,t.salereward = nvl(t.saleallreward,0) - nvl( t.salesubreward,0)
     where t.cleardate = p_endDate;

    ---更新系统状态
    update br_r_systemstatus t set t.status=2;
    update br_r_clearstatus t set t.status=2,t.updatetime=sysdate where t.actionid=2;
    commit;

    return 1;

 exception
    when others then
      v_errorcode:=sqlcode;
      v_errormsg :=sqlerrm;
      rollback;
      insert into T_DBLog(err_date,name_proc,err_code,err_msg) values(sysdate,'fn_br_r_getreward',v_errorcode,v_errormsg);
      update br_r_systemstatus t set t.status=0;
      commit;
    return -100;
end;
/

