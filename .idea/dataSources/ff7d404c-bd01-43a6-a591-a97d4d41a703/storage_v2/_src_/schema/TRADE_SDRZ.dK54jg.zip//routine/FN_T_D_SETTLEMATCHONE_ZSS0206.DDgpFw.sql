CREATE function FN_T_D_SettleMatchOne_ZSS0206(p_CommodityID varchar2, --商品代码
                                                     p_a_orderno   t_delayorders.a_orderno%type)
  return number
/****
   * 某商品交收申报配对
   * 返回值
   * 1 成功
   * -1  买方成交数量出错
   * -3  交收持仓数量大于可交收持仓数量
   * -4  交收抵顶数量大于可抵顶数量
   * -5  做市商不存在  3300555
  ****/
 as
  v_version              varchar2(10) := '1.0.2.2';
  v_ret                  number(4);
  v_OrderTradeQty        number(10) := 0;
  v_TradeDate            date;
  v_Balance              number(15, 2) := 0;
  v_UnfrozenFunds        number(15, 2);
  v_F_FrozenFunds        number(15, 2);
  v_Status               number(2);
  v_num                  number(10);
  v_DelayNeedBill        number(2); --延期交收是否需要仓单，0：不需要； 1：需要；
  v_tradedAmount         number(10) := 0; --成交数量
  v_unCloseQty           number(10); --未平数量，用于中间计算
  v_NeutralMatchPriority number(2); --中立仓反向持仓是否优先撮合,0:不优先；1：优先
  v_bs_flag              t_delayorders.bs_flag%type;
  v_A_OrderNo            t_delayorders.a_orderno%type;
  v_A_TradeNo            t_trade.a_tradeno%type;
  v_t_holdqty              t_holdposition.holdqty%type;
  v_overdat                t_commodity.overdat%type;
  v_contractFactor         t_commodity.contractfactor%type;
  v_A_HoldNo               t_holdposition.a_holdno%type;
begin
  --检查做市商是否存在
  select count(*) into v_num from m_firm where firmid='63300555';
  if v_num = 0 then
     return -5;
  end if;
  --1、如果交收商品表中没有此商品则插入
  select count(*)
    into v_num
    from T_SettleCommodity
   where CommodityID = p_CommodityID;
  if (v_num = 0) then
    select TradeDate into v_TradeDate from T_SystemStatus;
    insert into T_SettleCommodity
      select v_TradeDate, a.*
        from T_Commodity a
       where a.CommodityID = p_CommodityID;
  end if;
  select overdat,contractFactor into v_overdat,v_contractFactor from t_commodity where commodityid=p_CommodityID;
  select DelayNeedBill into v_DelayNeedBill from T_A_Market;
  select NEUTRALMATCHPriority into v_NeutralMatchPriority from t_a_market;
  --2、轮询买委托记录（中立仓反向持仓优先撮合时有反向持仓的会员委托优先排序，不优先时只按委托号排序）
  --for delayOrder_B in(select A_OrderNo,CommodityID,CustomerID,BS_Flag,(Quantity-TradeQty) NotTradeQty,Price,FrozenFunds,UnfrozenFunds,Quantity,FirmID from T_DelayOrders where DelayOrderType=1 and Status in(1,2) and BS_Flag=1 and CommodityID=p_CommodityID order by A_OrderNo for update)
  for delayOrder_B in (select A_OrderNo,
                              CommodityID,
                              CustomerID,
                              T_DelayOrders.BS_Flag BS_Flag,
                              (Quantity - TradeQty) NotTradeQty,
                              Price,
                              FrozenFunds,
                              UnfrozenFunds,
                              Quantity,
                              FirmID,
                              delaymoney
                         from T_DelayOrders,
                              (select distinct (t.FirmID) as FID,
                                               1 as OrderType,
                                               BS_Flag
                                 from T_HoldPosition t
                                where -- t.BS_Flag = 1 and 轮询委托记录
                                   t.HoldType =
                                      decode(v_NeutralMatchPriority, 1, 2, 1)
                                  and t.CommodityID = p_CommodityID) hp
                        where DelayOrderType = 1 and T_DelayOrders.BS_Flag=hp.BS_Flag
                          and Status in (1, 2)
                          /*and BS_Flag = 1*/
                          and CommodityID = p_CommodityID
                          and firmid = hp.FID(+)
                          and A_OrderNo = p_a_orderno
                        order by nvl(hp.OrderType, 0) desc, A_OrderNo
                          for update of A_OrderNo) loop
    v_unCloseQty := delayOrder_B.NotTradeQty;
    --轮询卖委托记录，成交完买委托的数量
    --for delayOrder_S in(select A_OrderNo,CommodityID,CustomerID,BS_Flag,(Quantity-TradeQty) NotTradeQty,Price,FrozenFunds,UnfrozenFunds,Quantity,FirmID from T_DelayOrders where DelayOrderType=1 and Status in(1,2) and BS_Flag=2 and CommodityID=p_CommodityID order by A_OrderNo for update)
    /*for delayOrder_S in(select A_OrderNo,CommodityID,CustomerID,BS_Flag,(Quantity-TradeQty) NotTradeQty,Price,FrozenFunds,UnfrozenFunds,Quantity,FirmID from T_DelayOrders,(select distinct(t.FirmID) as FID,1 as OrderType from T_HoldPosition t where t.BS_Flag=2 and t.HoldType=decode(v_NeutralMatchPriority,1,2,0) and t.CommodityID=p_CommodityID) hp where DelayOrderType=1 and Status in(1,2) and BS_Flag=2 and CommodityID=p_CommodityID and firmid=hp.FID(+) order by nvl(hp.OrderType,0) desc,A_OrderNo for update of A_OrderNo)
    loop
      if(delayOrder_S.NotTradeQty <= v_unCloseQty) then  --全部成交
        v_tradedAmount:=delayOrder_S.NotTradeQty;
        v_Status := 3;
        v_UnfrozenFunds:=delayOrder_S.FrozenFunds-delayOrder_S.UnfrozenFunds;
          else  --部分成交
              v_tradedAmount:=v_unCloseQty;
              v_Status := 2;
        v_UnfrozenFunds:=delayOrder_S.FrozenFunds*v_tradedAmount/delayOrder_S.Quantity;
      end if;*/

    v_tradedAmount  := v_unCloseQty;
    v_Status        := 3;
    v_UnfrozenFunds := delayOrder_B.FrozenFunds -
                       delayOrder_B.UnfrozenFunds;

    for delayOrder_S in (select *
                           from t_delayorders
                          where a_orderno = p_a_orderno
                            and commodityid = p_CommodityID) loop
      if delayOrder_S.bs_flag = 1 then
        v_bs_flag := 2;
      else
        v_bs_flag := 1;
      end if;
      /*select SEQ_T_DelayOrders.nextval into v_A_OrderNo from dual;
      insert into t_delayorders
        (a_orderno,
         commodityid,
         customerid,
         traderid,
         bs_flag,
         delayordertype,
         status,
         withdrawtype,
         quantity,
         price,
         tradeqty,
         frozenfunds,
         unfrozenfunds,
         ordertime,
         withdrawtime,
         ordererip,
         signature,
         firmid,
         consignerid,
         withdrawerid)
      values
        (v_A_OrderNo,
         p_CommodityID,
         '6330055500',
         '63300555',
         v_bs_flag,
         delayOrder_S.delayordertype,
         v_status,
         delayOrder_S.withdrawtype,
         v_tradedAmount,
         delayOrder_S.price,
         delayOrder_S.tradeqty,
         delayOrder_S.frozenfunds,
         delayOrder_S.unfrozenfunds,
         delayOrder_S.ordertime,
         delayOrder_S.withdrawtime,
         delayOrder_S.ordererip,
         delayOrder_S.signature,
         '63300555',
         delayOrder_S.consignerid,
         delayOrder_S.withdrawerid);*/

      /*update T_DelayOrders set Status=v_Status,TradeQty=TradeQty+v_tradedAmount,UnfrozenFunds=UnfrozenFunds+v_UnfrozenFunds where A_OrderNo=delayOrder_S.A_OrderNo;*/
      --更新冻结资金
      v_F_FrozenFunds := FN_F_UpdateFrozenFunds(delayOrder_S.FirmID,
                                                -v_UnfrozenFunds,
                                                '15');
      /*if(v_DelayNeedBill = 1) then
        v_ret := FN_T_D_TradeBill(delayOrder_S.FirmID,delayOrder_S.CommodityID,v_tradedAmount);
      end if;*/
      for th in (select * from t_holdposition where commodityid=p_CommodityID and firmid=delayOrder_B.firmid and holdqty>0 order by overdat,holdqty) loop
       -- select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_A_TradeNo from dual;
        v_t_holdqty:=th.holdqty-v_tradedamount;
        if v_t_holdqty>=0 then

           v_t_holdqty:=v_tradedamount;
           --1 insert 生成做市商持仓明细用来和申报的客户交收
            select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
           insert into t_holdposition
            (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat)
           values
            (v_A_HoldNo, th.A_TradeNo, '6330055500', p_CommodityID, v_bs_flag, th.price, v_t_holdqty, v_t_holdqty, sysdate, th.holdmargin, '63300555', th.gageqty, th.holdassure, th.floatingloss, th.holdtype, trunc(sysdate), th.deadline, th.remainday, th.overdat);
            --2 insert 生成新的持仓明细，买卖方向和交收的客户一样，并且合约到期天数为90
            select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
            insert into t_holdposition
            (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat)
           values
            (v_A_HoldNo, th.A_TradeNo, '6330055500', p_CommodityID, delayOrder_S.bs_flag, delayOrder_B.delaymoney, v_t_holdqty, v_t_holdqty, sysdate, th.holdmargin, '63300555', th.gageqty, th.holdassure, th.floatingloss, th.holdtype, trunc(sysdate), th.deadline, th.remainday,v_overdat);
              --1更新交易客户持仓合计表
              select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=v_bs_flag;
              if v_num>0 then
                 update T_CustomerHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                  where CustomerID = '6330055500'
                  and CommodityID = p_CommodityID
                  and bs_flag = v_bs_flag;
              else
                insert into T_CustomerHoldSum
                  (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                values
                  ('6330055500', p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price,0,0,0,'63300555');
              end if;
              --2更新交易商持仓合计表
               select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=v_bs_flag;
              if v_num>0 then
                 update T_FirmHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                  where Firmid = '63300555'
                  and CommodityID = p_CommodityID
                  and bs_flag = v_bs_flag;
              else
                  insert into T_FirmHoldSum
                  (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                values
                  ('63300555', p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price, 0, 0);
              end if;
               --3 更新交易客户持仓合计表
              select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;
              if v_num>0 then
                 update T_CustomerHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                  where CustomerID = '6330055500'
                  and CommodityID = p_CommodityID
                  and bs_flag = delayOrder_S.bs_flag;
              else
                insert into T_CustomerHoldSum
                  (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                values
                  ('6330055500', p_CommodityID, delayOrder_S.bs_flag, v_t_holdqty, delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,0, th.price,0,0,0,'63300555');
              end if;
              --4 更新交易商持仓合计表
               select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;
              if v_num>0 then
                 update T_FirmHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                  where Firmid = '63300555'
                  and CommodityID = p_CommodityID
                  and bs_flag = delayOrder_S.bs_flag;
              else
                  insert into T_FirmHoldSum
                  (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                values
                  ('63300555', p_CommodityID, delayOrder_S.bs_flag, v_t_holdqty, delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,0, th.price, 0, 0);
              end if;
          exit;
        else
            v_tradedamount:=v_tradedamount-th.holdqty;
            v_t_holdqty:=th.holdqty;
            select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
            insert into t_holdposition
            (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat)
           values
            (v_A_HoldNo,  th.A_TradeNo, '6330055500', p_CommodityID, v_bs_flag, th.price, v_t_holdqty, v_t_holdqty, sysdate, th.holdmargin, '63300555', th.gageqty, th.holdassure, th.floatingloss, th.holdtype, trunc(sysdate), th.deadline, th.remainday, th.overdat);
            select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo from dual;
            insert into t_holdposition
            (a_holdno, a_tradeno, customerid, commodityid, bs_flag, price, holdqty, openqty, holdtime, holdmargin, firmid, gageqty, holdassure, floatingloss, holdtype, atcleardate, deadline, remainday, overdat)
           values
            (v_A_HoldNo, th.A_TradeNo, '6330055500', p_CommodityID, delayOrder_S.bs_flag,delayOrder_B.delaymoney, v_t_holdqty, v_t_holdqty, sysdate, th.holdmargin, '63300555', th.gageqty, th.holdassure, th.floatingloss, th.holdtype, trunc(sysdate), th.deadline, th.remainday, v_overdat);
            ------------
            --1 更新交易客户持仓合计表
              select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=v_bs_flag;
              if v_num>0 then
                 update T_CustomerHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                  where CustomerID = '6330055500'
                  and CommodityID = p_CommodityID
                  and bs_flag = v_bs_flag;
              else
                insert into T_CustomerHoldSum
                  (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                values
                  ('6330055500', p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price,0,0,0,'63300555');
              end if;
              --2 更新交易商持仓合计表
               select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=v_bs_flag;
              if v_num>0 then
                 update T_FirmHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                  where Firmid = '63300555'
                  and CommodityID = p_CommodityID
                  and bs_flag = v_bs_flag;
              else
                  insert into T_FirmHoldSum
                  (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                values
                  ('63300555', p_CommodityID, v_bs_flag, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price, 0, 0);
              end if;
            --3 更新交易客户持仓合计表
              select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;
              if v_num>0 then
                 update T_CustomerHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
                  where CustomerID = '6330055500'
                  and CommodityID = p_CommodityID
                  and bs_flag = delayOrder_S.bs_flag;
              else
                insert into T_CustomerHoldSum
                  (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
                values
                  ('6330055500', p_CommodityID, delayOrder_S.bs_flag, v_t_holdqty, delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,0, th.price,0,0,0,'63300555');
              end if;
              --4 更新交易商持仓合计表
               select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;
               dbms_output.put_line( v_t_holdqty );
              if v_num>0 then
                 update T_FirmHoldSum
                  set holdQty = holdQty + v_t_holdqty,
                  holdFunds = holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,
                  HoldMargin = HoldMargin + 0,
                  HoldAssure = HoldAssure + 0,
                  evenprice = (holdFunds + delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
                  where Firmid = '63300555'
                  and CommodityID = p_CommodityID
                  and bs_flag = delayOrder_S.bs_flag;
              else
                  insert into T_FirmHoldSum
                  (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
                values
                  ('63300555', p_CommodityID, delayOrder_S.bs_flag, v_t_holdqty,delayOrder_B.delaymoney*v_t_holdqty*v_contractFactor,0, th.price, 0, 0);
              end if;

        end if;
      end loop;
       /*   --更新交易客户持仓合计表
        select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;  --买
        dbms_output.put_line('-----t_customerholdsum-00-----'||v_num);
        if v_num>0 then
           update T_CustomerHoldSum
            set holdQty = holdQty + v_unCloseQty,
            holdFunds = holdFunds + th.price*v_unCloseQty*v_contractFactor,
            HoldMargin = HoldMargin + 0,
            HoldAssure = HoldAssure + 0,
            evenprice = (holdFunds + th.price*v_unCloseQty*v_contractFactor)/((holdQty + v_unCloseQty)*v_contractFactor)
            where CustomerID = '6330055500'
            and CommodityID = p_CommodityID
            and bs_flag = delayOrder_S.bs_flag;
        else
          insert into T_CustomerHoldSum
            (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
          values
            ('6330055500', p_CommodityID, delayOrder_S.bs_flag, v_unCloseQty, th.price*v_unCloseQty*v_contractFactor,0, th.price,0,0,0,'63300555');
        end if;
        \*select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=2;  --卖
        if v_num>0 then
             update T_CustomerHoldSum
            set holdQty = holdQty + v_t_holdqty,
            holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
            HoldMargin = HoldMargin + 0,
            HoldAssure = HoldAssure + 0,
            evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty)*v_contractFactor)
            where CustomerID = '6330055500'
            and CommodityID = p_CommodityID
            and bs_flag =2;
        else
           insert into T_CustomerHoldSum
            (CustomerID, CommodityID, bs_flag, holdQty, holdFunds,FloatingLoss, evenprice,FrozenQty,HoldMargin,HoldAssure,FirmID)
          values
            ('6330055500', p_CommodityID, 2, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price,0,0,0,'63300555');
        end if;*\
        --更新交易商持仓合计表
         select count(*) into v_num from T_FirmHoldSum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=delayOrder_S.bs_flag;  --买
          dbms_output.put_line('-----T_FirmHoldSum-00-----'||v_num);
        if v_num>0 then
           update T_FirmHoldSum
            set holdQty = holdQty + v_unCloseQty,
            holdFunds = holdFunds + th.price*v_unCloseQty*v_contractFactor,
            HoldMargin = HoldMargin + 0,
            HoldAssure = HoldAssure + 0,
            evenprice = (holdFunds + th.price*v_unCloseQty*v_contractFactor)/((holdQty + v_unCloseQty )*v_contractFactor)
            where Firmid = '63300555'
            and CommodityID = p_CommodityID
            and bs_flag = 1;
        else
            insert into T_FirmHoldSum
            (FirmID, CommodityID,      bs_flag,  holdQty,        holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
          values
            ('63300555', p_CommodityID, delayOrder_S.bs_flag, v_unCloseQty, th.price*v_unCloseQty*v_contractFactor,0, th.price, 0, 0);
        end if;
         select count(*) into v_num from T_FirmHoldSum  where FirmID = '63300555' ;
          dbms_output.put_line('-----v_num-00-----'||v_num);*/
       /* select count(*) into v_num from t_customerholdsum where commodityid=p_CommodityID and firmid='63300555' and bs_flag=2;  --卖
        if v_num>0 then
           update T_FirmHoldSum
            set holdQty = holdQty + v_t_holdqty,
            holdFunds = holdFunds + th.price*v_t_holdqty*v_contractFactor,
            HoldMargin = HoldMargin + 0,
            HoldAssure = HoldAssure + 0,
            evenprice = (holdFunds + th.price*v_t_holdqty*v_contractFactor)/((holdQty + v_t_holdqty )*v_contractFactor)
            where Firmid = '63300555'
            and CommodityID = p_CommodityID
            and bs_flag = 2;
        else
             insert into T_FirmHoldSum
            (FirmID, CommodityID, bs_flag,  holdQty, holdFunds,FloatingLoss, evenprice,HoldMargin,HoldAssure)
          values
            ('63300555', p_CommodityID, 2, v_t_holdqty, th.price*v_t_holdqty*v_contractFactor,0, th.price, 0, 0);
        end if;*/
       v_tradedAmount  := v_unCloseQty;
      --卖方持仓交收，涉及持仓明细，持仓合计，资金
      v_ret := FN_T_D_SettleOne_ZSS(delayOrder_S.CommodityID,
                                    delayOrder_S.Price,
                                    v_bs_flag,
                                    '6330055500',
                                    v_tradedAmount,
                                    0);
      if (v_ret < 0) then
      dbms_output.put_line('wolailema ');
        rollback;
        return v_ret;
      end if;
      v_unCloseQty := v_unCloseQty - v_tradedAmount;
      exit when v_unCloseQty = 0;
    end loop;
    /*end loop;*/

    v_OrderTradeQty := delayOrder_B.NotTradeQty - v_unCloseQty;
    if (v_unCloseQty = 0) then
      --全部成交
      v_Status        := 3;
      v_UnfrozenFunds := delayOrder_B.FrozenFunds -
                         delayOrder_B.UnfrozenFunds;
    elsif (v_unCloseQty > 0 and v_unCloseQty < delayOrder_B.NotTradeQty) then
      --部分成交
      v_Status        := 2;
      v_UnfrozenFunds := delayOrder_B.FrozenFunds * v_OrderTradeQty /
                         delayOrder_B.Quantity;
    elsif (v_unCloseQty = delayOrder_B.NotTradeQty) then
      --无卖方配对记录，成功返回
      return 1;
    else
      --出错回滚，要交收数量为负数了
      rollback;
      return - 1;
    end if;
    update T_DelayOrders
       set Status        = v_Status,
           TradeQty      = TradeQty + v_OrderTradeQty,
           UnfrozenFunds = UnfrozenFunds + v_UnfrozenFunds
     where A_OrderNo = delayOrder_B.A_OrderNo;
    --更新冻结资金
    v_F_FrozenFunds := FN_F_UpdateFrozenFunds(delayOrder_B.FirmID,
                                              -v_UnfrozenFunds,
                                              '15');
    --买方持仓交收，涉及持仓明细，持仓合计，资金
    v_ret := FN_T_D_SettleOne_ZSS(delayOrder_B.CommodityID,
                                  delayOrder_B.Price,
                                  delayOrder_B.BS_Flag,
                                  delayOrder_B.CustomerID,
                                  v_OrderTradeQty,
                                  0);
    if (v_ret < 0) then
      rollback;
      return v_ret;
    end if;
  end loop;

  return 1;

end;
/

