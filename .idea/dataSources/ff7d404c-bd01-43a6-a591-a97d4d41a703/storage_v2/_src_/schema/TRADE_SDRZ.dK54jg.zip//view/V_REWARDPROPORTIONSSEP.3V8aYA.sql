CREATE VIEW V_REWARDPROPORTIONSSEP AS
  select b.brokerid,
       b.brokerlevel        brokerlevel,
       a.proportion,
       b.parentid,
       a.memberid     rootbrokerid,
       a.updateuserid
  from br_r_rewardProportionsSep a, br_broker_relation b
 where a.brokerid = b.brokerid
/

