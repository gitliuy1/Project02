CREATE VIEW V_H_FIRM_DAYREPORT AS
  select t1.commodityid,t1.firmid,t1.brokerid,t1.cleardate,t2.developer,sum(t1.fee) tradefee ,sum(t1.qty) quantity  ,sum(t1.amount) amount
  from br_r_firmcomoditydaytrade t1,br_r_firmdeveloper t2
 where t1.firmid=t2.firmid(+)
 group by t1.commodityid,t1.firmid,t1.brokerid,t1.cleardate,t2.developer
/

