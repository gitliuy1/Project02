CREATE function FN_OP_AddOperationCenter(p_operationcenterid varchar2,
                                                    p_name varchar2,
                                                    p_fullname varchar2,
                                                    p_contactman varchar2,
                                                    p_phone varchar2,
                                                    p_parentid varchar2,
                                                    p_type number,
                                                    p_password  varchar2,
                                                    p_note varchar2
                                                    )
return number is v_result number;
begin
  insert into op_user(id,name,password,type,description)values(p_operationcenterid,p_name,p_password,'ADMIN',p_name||'管理员');
  if p_type=1 then
     insert into op_operationcenter values(p_operationcenterid,p_name,p_fullname,p_contactman,p_phone,sysdate,null,p_type,null,p_note);
     insert into op_user_role(roleid,userid) values(-1,p_operationcenterid);

  else
     insert into op_operationcenter values(p_operationcenterid,p_name,p_fullname,p_contactman,p_phone,sysdate,p_parentid,p_type,null,p_note);
     insert into op_user_role (roleid,userid)values(-2,p_operationcenterid);
  end if;
  return 1;
  exception
    when others then
      rollback;
      return -1;

end;
/

