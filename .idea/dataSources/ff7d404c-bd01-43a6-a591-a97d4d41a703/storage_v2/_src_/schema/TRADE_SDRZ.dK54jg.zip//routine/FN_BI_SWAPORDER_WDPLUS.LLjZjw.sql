CREATE function FN_BI_SwapOrder_WDPlus( p_orderno_wd  varchar2       ---委托单号
                                               ,p_wdType     number  			  ---撤单类型 1交易商撤单;3 初审驳回撤单;4 终审驳回撤单;5 自动撤单
                                               ,p_auditor    varchar2       ---操作人
                                               ,p_remark     varchar2       ---备注
)
return number as
/****
 * 功能：入串换委托 yuansr 2017 06 16
 * 返回值:  -1=当前状态，不能撤单; -2=初审撤单; -4=对立委托解冻仓单失败;
            -51自动撤单
 *          -100=其它错误
****/
  v_result           number(2);
  v_errorcode        number;
  v_errormsg         varchar2(200);

  v_F_FrozenFunds    F_FIRMBALANCE.LASTBALANCE%type;
  v_status           BI_SWAPSTOCKORDERS.STATUS%type;

  v_firmid           BI_SWAPSTOCKORDERS.FIRMID%type;
  v_stockids         BI_SWAPSTOCKORDERS.STOCKIDS%type;
  v_compensate       BI_SWAPSTOCKORDERS.COMPENSATE%type;  

  v_o_firmid         BI_SWAPSTOCKORDERS.FIRMID%type;
  v_o_stockids       BI_SWAPSTOCKORDERS.STOCKIDS%type;
  v_o_compensate     BI_SWAPSTOCKORDERS.COMPENSATE%type;
  v_sql              varchar2(500);
  type c_item is ref cursor;
  v_item             c_item;
  v_stockId          bi_stock.stockid%type;
begin
  ---1 获取委托信息
  select t.status   ,t.firmid ,t.stockids ,t.compensate  ,t.o_firmid ,t.o_stockids ,t.o_compensate 
    into v_status   ,v_firmid ,v_stockids ,v_compensate  ,v_o_firmid ,v_o_stockids ,v_o_compensate
    from bi_swapstockorders t 
   where t.orderno=p_orderno_wd for update ;

  ---2 验证当前状态是否可以撤单
  --委托不是发起或拒绝状态，交易商不可自主撤单
  if p_wdType=1 and  v_status not in (1,2)  then
     return -1;  
  end if;
  
  --不是待初审状态，不可初审驳回撤单
  if p_wdType=3 and v_status <> 3  then
     return -1;  
  end if;
  
  ---不是待终审状态，不可终审驳回撤单
  if p_wdType=4 and v_status <> 4  then
     return -1;  
  end if;
  
  ---成交状态或已撤单状态，不可撤单
  if v_status>4  then
     return -1;  
  end if;

  ---3 开始进行撤单处理，若处理失败，直接回滚数据；
  --发起交易商仓单解冻处理
  v_sql:='select t.stockid  from bi_stock t where  t.ownerfirm='''||v_firmid||''''
       ||'   and t.stockid in('''|| replace(v_stockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND; 
      v_result:=fn_bi_unfrozenbill(15,v_stockId);
      if(v_result != 1) then
        rollback;
        return -3;--解冻仓单失败
      end if;
  end loop;
  close v_item;
  --发起交易商附加资金解冻处理
  if (v_compensate is not null) and (v_compensate>0) then
     --解冻更新冻结资金
     v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_firmid,0-v_compensate,'15');
  end if;

  if (v_status>=3) then ---经过确认交易商，确认流程的委托即确认状态处于以后的委托，对确认交易商数据处理
      --确认交易商仓单解冻处理
      v_sql:='select t.stockid  from bi_stock t where  t.ownerfirm='''||v_o_firmid||''''
           ||'   and t.stockid in('''|| replace(v_o_stockids,',',''',''') ||''')  for update ';
      open v_item for v_sql;
      loop
           fetch v_item into v_stockId ;
            exit when v_item%NOTFOUND; 
          v_result:=fn_bi_unfrozenbill(15,v_stockId);
          if(v_result != 1) then
            rollback;
            return -3;--解冻仓单失败
          end if;
      end loop;
      close v_item;
      --确认交易商附加资金解冻处理
      if (v_o_compensate is not null) and (v_o_compensate>0) then
         --解冻更新冻结资金
         v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_o_firmid,0-v_o_compensate,'15');
      end if;
   end if;
 
  ---更新状态为撤销，记录撤销方式、备注、更新时间
  update bi_swapstockorders t 
     set t.status=6 ,t.modifytime=sysdate ,t.wdkind=p_wdType ,t.remark=t.remark||';'||p_remark,t.auditor=decode(p_wdType,4,p_auditor,t.auditor)
   where t.orderno=p_orderno_wd ;

  ---4 撤单处理完成，返回处理结果；
  return 1;
  
  exception
    when others then
    v_errorcode:=sqlcode;

    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_BI_SwapOrder_WDPlus',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

