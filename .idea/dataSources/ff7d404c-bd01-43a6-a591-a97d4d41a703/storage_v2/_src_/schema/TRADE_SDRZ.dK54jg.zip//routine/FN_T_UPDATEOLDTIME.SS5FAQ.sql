CREATE function fn_t_updateoldtime(
p_commodityid varchar2,
p_ClearDate Date)--系统当前交易日
/**
  * add by lyf 201607028
  * 更新指定商品的所有持仓的 合约 到期日期、到期天数
  */
 return number is
  v_date       date;
  v_overDate   number;   --合约到期天数
  v_ret        number;
begin
     -- modify by lyf 20160803 增加检查今天是否初始化过
     select count(*) into v_ret from t_updateholdlog  where trunc(createdate)=trunc(p_ClearDate/*sysdate如果当日多次开市，取系统当前日期，那么持仓到期天数都会是同一天*/) and commodityid=p_commodityid ;
     if v_ret<=0 then
        --计算到下一个交易日的天数
        v_overDate := FN_t_ComputeTrustDays(p_ClearDate);
        for days in (select atcleardate from t_holdposition where commodityid = p_commodityid group by atcleardate) loop
            --更新所有符合该条件的持仓
            update t_holdposition t set t.overdat=t.overdat-v_overDate where t.atcleardate = days.atcleardate and commodityid = p_commodityid and overdat>0;
        end loop;
        insert into t_updateholdlog values(SEQ_T_updateholdLOG.Nextval,p_commodityid,v_overDate,p_ClearDate/*sysdate如果当日多次开市，取系统当前日期，那么持仓到期天数都会是同一天*/);
     end if;
  return(0);
end;
/

