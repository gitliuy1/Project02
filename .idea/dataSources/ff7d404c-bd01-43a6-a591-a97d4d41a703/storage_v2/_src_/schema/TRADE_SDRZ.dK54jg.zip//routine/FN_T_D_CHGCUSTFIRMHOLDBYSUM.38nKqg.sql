CREATE FUNCTION FN_T_D_ChgCustFirmHoldBySum
(
  p_CustomerID             varchar2,   --交易客户代码
  p_FirmID                 varchar2,   --交易商代码
  p_CommodityID            varchar2,   --商品代码
  p_ContractFactor         number,     --商品合约因子
  p_BS_Flag                number,     --买卖标志
  p_TradeQty               number,     --数量
  p_TradeGageQty           number,     --抵顶数量 yuansr 2017 08 23
  p_holdfunds              number,     --资金
  p_HoldMargin             number,     --保证金
  p_HoldAssure             number,     --担保金
  p_GageMode               number      --是否包含抵顶数量：1 包含，反之不包含
)  return number
/***
 * 更新交易客户持仓合计和交易商持仓合计信息 yuansr 2017 04 26
 *
 * 返回值：1成功
 ****/
is
  v_version             varchar2(10):='1.0.0.0';
  v_ContractFactor      number(12,2):=p_ContractFactor;
  v_TradeQty            number(10)  :=nvl(p_TradeQty,0)+nvl(p_TradeGageQty,0);
  
begin
    ----商品合约因子无效则重新获取商品合约因子
    if p_ContractFactor is null or p_ContractFactor<=0 then
       select ContractFactor into v_ContractFactor from T_Commodity where CommodityID = p_CommodityID;
    end if;
    
    if p_GageMode=1 then
        --更改交易客户持仓合计表中的持仓记录
        update T_CustomerHoldSum
         set holdqty = holdqty - p_TradeQty   ,holdfunds = holdfunds - p_holdfunds        ,HoldMargin = HoldMargin - nvl(p_HoldMargin,0)
             ,HoldAssure = HoldAssure - nvl(p_HoldAssure,0)          ,FrozenQty = FrozenQty - decode(sign(p_TradeQty),-1,0,p_TradeQty)
             ,EvenPrice = decode(HoldQty+GageQty-v_TradeQty,0,0,(HoldFunds-p_holdfunds)/((HoldQty+GageQty-v_TradeQty)*v_ContractFactor))
             ,gageqty =gageqty-p_TradeGageQty  --,gagefrozenqty = gagefrozenqty - decode(sign(p_TradeGageQty),-1,0,p_TradeGageQty)
       where CustomerID = p_CustomerID
         and CommodityID = p_CommodityID
         and bs_flag = p_BS_Flag;
         
        --更改交易客户持仓合计表中的持仓记录
        update T_FirmHoldSum
         set holdqty = holdqty - p_TradeQty   ,holdfunds = holdfunds - p_holdfunds        ,HoldMargin = HoldMargin - nvl(p_HoldMargin,0)
             ,HoldAssure = HoldAssure - nvl(p_HoldAssure,0)
             ,EvenPrice = decode(HoldQty+GageQty-p_TradeQty,0,0,(HoldFunds-p_holdfunds)/((HoldQty+GageQty-p_TradeQty)*v_ContractFactor))
             ,gageqty =gageqty-p_TradeGageQty  
       where FirmId = p_FirmID
         and CommodityID = p_CommodityID
         and bs_flag = p_BS_Flag;
    else
      --更改交易客户持仓合计表中的持仓记录
        update T_CustomerHoldSum
         set holdqty = holdqty - p_TradeQty   ,holdfunds = holdfunds - p_holdfunds        ,HoldMargin = HoldMargin - nvl(p_HoldMargin,0)
             , HoldAssure = HoldAssure - nvl(p_HoldAssure,0)          ,FrozenQty = FrozenQty - decode(sign(p_TradeQty),-1,0,p_TradeQty)
             ,EvenPrice = decode(HoldQty-p_TradeQty,0,0,(HoldFunds-p_holdfunds)/((HoldQty-p_TradeQty)*v_ContractFactor))
             ,gageqty =gageqty-p_TradeGageQty	 --,gagefrozenqty = gagefrozenqty - decode(sign(p_TradeGageQty),-1,0,p_TradeGageQty)
       where CustomerID = p_CustomerID
         and CommodityID = p_CommodityID
         and bs_flag = p_BS_Flag;
         
        --更改交易客户持仓合计表中的持仓记录
        update T_FirmHoldSum
         set holdqty = holdqty - p_TradeQty   ,holdfunds = holdfunds - p_holdfunds        ,HoldMargin = HoldMargin - nvl(p_HoldMargin,0)
             ,HoldAssure = HoldAssure - nvl(p_HoldAssure,0)
             ,EvenPrice = decode(HoldQty-v_TradeQty,0,0,(HoldFunds-p_holdfunds)/((HoldQty-v_TradeQty)*v_ContractFactor))
             ,gageqty =gageqty-p_TradeGageQty
       where FirmId = p_FirmID
         and CommodityID = p_CommodityID
         and bs_flag = p_BS_Flag;
     end if;

   return 1;
end;
/

