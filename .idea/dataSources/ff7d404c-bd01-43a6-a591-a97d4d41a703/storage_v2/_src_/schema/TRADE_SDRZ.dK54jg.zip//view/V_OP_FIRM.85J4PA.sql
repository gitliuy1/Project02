CREATE VIEW V_OP_FIRM AS
  select c.firmid firmid,c.name name,d.brokerid memberno,m.name membername,o.operationcenterid opcenterid,o.type type,o.parentid parentid,
o.name operationcenter,c.note note,c.createtime createtime,c.contactman contactman,c.email email,c.phone phone
 from m_firm c
 left join br_firmandbroker d on c.firmid=d.firmid
 left join br_broker m on d.brokerid=m.brokerid
 left join op_member p on d.brokerid = p.memberno
 left join op_operationcenter o on p.operationcenterid = o.operationcenterid
/

