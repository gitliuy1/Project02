CREATE VIEW V_T_HOLDPOSITION AS
  select h.a_holdno,
       h.CustomerID,
       h.CommodityID,
       h.BS_Flag,
       h.Price,
       h.overdat,
       h.a_tradeno,
       h.holdqty,
       h.openqty,
       h.holdtime,
       h.holdmargin,
       h.gageqty,
       h.holdassure,
       h.floatingloss,
       h.holdtype,
       h.atcleardate,
       (select trunc(tradedate) from t_systemstatus) + case when (overdat-1)<0 then 0 else (overdat-1) end deadline,
       h.remainday,
       h.firmid,
       --nvl(s.ratio,0)* nvl(h.HoldQty + h.GageQty,0) swapfee,
       (case when (select trunc(tradedate) from t_systemstatus) = h.atcleardate then 0 else FN_T_ComputeSwapFee( h.a_holdno ,nvl(h.HoldQty + h.GageQty, 0) ,decode(h.bs_flag,1,2,1) ) end) swapfee,
       nvl(h.holdkind,0) holdkind
  from T_HoldPosition h,swapfee s
 where h.commodityid=s.commodityid(+) and h.overdat=s.swapday(+) and h.bs_flag=s.bs_flag(+)
/

