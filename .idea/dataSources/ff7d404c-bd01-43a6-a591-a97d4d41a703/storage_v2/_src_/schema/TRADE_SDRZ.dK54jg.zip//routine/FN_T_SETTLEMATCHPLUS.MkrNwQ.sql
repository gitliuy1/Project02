CREATE function FN_T_SettleMatchPlus(p_commodityId varchar2, --商品代码
                                                p_quantity    number, --交收数量
                                                p_status      number, --状态
                                                p_result      number, --履约状态
                                                p_firmID_B    varchar2, --买方交易商代码
                                                p_firmID_S    varchar2, --卖方交易商代码
                                                p_settleDate  varchar2, --交收日期
                                                p_matchId     varchar2, --配对编号
                                                p_operator    varchar2, --操作人
                                                p_gageQty     number, --卖方交收抵顶数量
                                                p_settleType  number --交收类型
                                                ) return number
/****
 *
 *  轮询持仓时过滤交收类型为到期交收持仓
 *  添加配对时交收类型只看商品设置的交收类型与持仓的交收类型无关
 * 返回值
 *  1 成功
 * -1 买方持仓不足
 * -2 卖方持仓不足
 * -3 卖方抵顶不足
****/
as
  v_contractFactor       number; --合约因子
  v_buypayout_ref        number(15, 2) := 0; --买方参考货款
  v_buyPayout            number(15, 2) := 0; --已收买方货款
  v_sellincom_ref        number(15, 2) := 0; --卖方参考货款
  v_buyMargin            number(15, 2) := 0; --买方交收保证金
  v_sellMargin           number(15, 2) := 0; --卖方交收保证金
  v_everybuyPayout       number(15, 2) := 0; --买方每笔持仓已收货款
  v_everybuyMargin       number(15, 2) := 0; --买方每笔持仓交收保证金
  v_everysellMargin      number(15, 2) := 0; --卖方每笔持仓交收保证金
  v_price                number;
  v_settleprice_b        number := 0;
  v_settleprice_s        number := 0;
  v_weight               number(15, 4);
  v_gageweight           number(15, 4);
  v_amountQty_s          number(10);
  v_amountQty_b          number(10);
  v_amountGageQty_s      number(10);   --抵顶持仓，只有卖方有
  v_quantity             number(10);
  v_gagequantity         number(10);
  v_settlePriceType      number(2); --到期交收价格计算 0,1,3 统一价 2订立价
  v_delaySettlePriceType number(2); --延期交收申报交收价格类型 0统一价 1订立价
  v_settleType           number(2); --配对表的交收方式 1到期 3延期
  v_settleDate           varchar2(20); --交收日期 （到期交收取持仓明细的交收处理日期，延期为p_settleDate）
  v_settleWay            number(2); --商品表交收方式0中远期（到期） 1连续现货（延期） 2专场交易 （到期）
  v_count                number;
  v_matchsSatus          number(2):=0;
  v_frozen               number(15);
begin
    --到历史商品表查询商品参数 如果历史查不到查当前商品（因为交易结算时商品导历史，所以在交易结算前做当天的延期申报配对时只能查当前商品表）
    select count(*) into v_count from t_h_commodity where commodityid=p_commodityId and trunc(cleardate)=to_date(p_settleDate,'yyyy-MM-dd');
    if v_count=0 then
       select settlepricetype,delaySettlePriceType,contractFactor,settleWay 
         into v_settlePriceType,v_delaySettlePriceType,v_contractFactor,v_settleWay 
         from t_commodity where commodityid=p_commodityId;
    else
       select settlepricetype,delaySettlePriceType,contractFactor,settleWay 
         into v_settlePriceType,v_delaySettlePriceType,v_contractFactor,v_settleWay
         from t_h_commodity where commodityid=p_commodityId and trunc(cleardate)=to_date(p_settleDate,'yyyy-MM-dd');
    end if;

    if v_settleWay=1 then
       v_settleType:=nvl(p_settleType,1);--默认为到期交收类型 yuansr 2017 08 28
       if v_delaySettlePriceType=1 then
          v_settlePriceType:=2;
       end if;
    else
        v_settleType:=1;
    end if;
    --查询买卖双方的可配对数量
    select nvl(sum(HoldQty+GageQty-happenMATCHQTY-happenmatchgageqty  ),0)  into v_amountQty_b from t_settleholdposition t
     where CommodityID=p_commodityId and BS_Flag=1 and FirmID=p_firmID_B and settletype=v_settleType ---1=到期交收，3=调期交收
       and trunc(SettleProcessDate)=to_date(p_settleDate,'yyyy-MM-dd') ;
    select nvl(sum(HoldQty+GageQty-happenMATCHQTY-happenmatchgageqty ),0)，sum( nvl(GageQty,0)-nvl(happenmatchgageqty,0)) into v_amountQty_s ,v_amountGageQty_s from t_settleholdposition t
     where CommodityID=p_commodityId and BS_Flag=2 and FirmID=p_firmID_S and settletype=v_settleType ---1=到期交收，3=调期交收
       and trunc(SettleProcessDate)=to_date(p_settleDate,'yyyy-MM-dd') ;
    if(v_amountQty_b<p_quantity)then
        return -1;--买方持仓不足
    end if;
    if(v_amountQty_s<p_quantity)then
        return -2;--卖方持仓不足
    end if;
    
    if (v_amountGageQty_s<p_gageQty) then
      return -3; --卖方抵顶不足
    end if;

   --买方,无抵顶
   v_weight:=p_quantity;--配对数量
   for debit in (select * from t_settleholdposition t where CommodityID=p_commodityId and BS_Flag=1 and FirmID=p_firmID_B
                    and settletype=v_settleType and trunc(SettleProcessDate)=to_date(p_settleDate,'yyyy-MM-dd') order by a_holdno asc )
    loop
       v_settleDate:=p_settleDate;
       v_quantity:=debit.HoldQty-debit.happenmatchqty;
       if(v_settlePriceType=2)then
          v_price:=debit.price;
       else
          v_price:=debit.settlePrice;
       end if;
      v_settleprice_b:=debit.settlePrice;
      if v_quantity > v_weight and debit.HoldQty>0 then
          v_buypayout_ref:=v_buypayout_ref+v_price*v_weight*v_contractFactor;
          v_everybuyPayout:=debit.Payout/debit.HoldQty*v_weight;
          v_everybuyMargin:=debit.SettleMargin/debit.HoldQty*v_weight;
          v_buyPayout:=v_buyPayout+v_everybuyPayout;
          v_buyMargin:=v_buyMargin+v_everybuyMargin;
          --修改交收持仓明细配对状态=部分配对，已配对数量，已配对货款，已配对保证金
          update T_SettleHoldPosition set MATCHStatus=1,happenmatchqty = happenmatchqty + v_weight,happenMatchPayout=happenMatchPayout+v_everybuyPayout
                                          ,happenMatchSettleMargin=happenMatchSettleMargin+v_everybuyMargin where id=debit.id;
          --插入交收配对关联表
          insert into T_MatchSettleholdRelevance (MatchID, SettleID, Quantity, Price, SettlePayOut, Settlemargin)
          values (p_matchId, debit.id, v_weight, v_price, v_everybuyPayout, v_everybuyMargin);
          v_weight:=0;
      else
         if v_quantity > 0 then
          v_buypayout_ref:=v_buypayout_ref+v_price*v_quantity*v_contractFactor;
          v_weight:=v_weight - v_quantity;
          --最后一笔持仓用减法换算已配对货款和保证金
          v_everybuyPayout:=debit.Payout-debit.happenMatchPayout;
          v_everybuyMargin:=debit.SettleMargin-debit.happenMatchSettleMargin;
          v_buyPayout:=v_buyPayout+v_everybuyPayout;
          v_buyMargin:=v_buyMargin+v_everybuyMargin;
          --修改交收持仓明细配对状态=全部配对，已配对数量，已配对货款，已配对保证金
          update T_SettleHoldPosition 
             set MATCHStatus=2,happenmatchqty = debit.HoldQty ,happenMatchPayout=happenMatchPayout+v_everybuyPayout
                 ,happenMatchSettleMargin=happenMatchSettleMargin+v_everybuyMargin
           where id=debit.id;
          --插入交收配对关联表
          insert into T_MatchSettleholdRelevance (MatchID, SettleID, Quantity, Price, SettlePayOut, Settlemargin)
          values (p_matchId, debit.id, v_quantity, v_price, v_everybuyPayout, v_everybuyMargin);
        end if;
      end if;
      exit when v_weight=0;
    end loop;

    --卖方，非抵顶持仓配对数量
    v_weight:=p_quantity-p_gageQty;--配对数量
    v_gageweight:=p_gageQty;
    for debit in (select * from t_settleholdposition t where CommodityID=p_commodityId and BS_Flag=2 and FirmID=p_firmID_S 
                     and settletype=v_settleType and trunc(SettleProcessDate)=to_date(p_settleDate,'yyyy-MM-dd') order by a_holdno asc )
    loop
      v_settleDate:=p_settleDate;
      v_quantity:=debit.HoldQty-debit.happenmatchqty;
      v_gagequantity:=debit.gageqty-debit.happenmatchgageqty;
      if(v_settlePriceType=2)then
          v_price:=debit.price;
      else
          v_price:=debit.settlePrice;
      end if;
      v_settleprice_s:=debit.settlePrice;
      v_matchsSatus:=2;
      if v_quantity > v_weight then
        v_quantity:=v_weight;
        v_matchsSatus:=1;
      end if;      
      if v_gagequantity>v_gageweight then
        v_gagequantity:=v_gageweight;
        v_matchsSatus:=1;
      end if;
      
      v_weight:=v_weight - v_quantity;
      v_gageweight:=v_gageweight - v_gagequantity;
      v_sellincom_ref:=v_sellincom_ref+v_price*(v_quantity+v_gagequantity)*v_contractFactor;
      if debit.holdqty>0 then
         v_everysellMargin:=debit.SettleMargin/(debit.holdqty)*v_quantity;---抵顶不计保证金 yuansr 2017 08 14
      else
         v_everysellMargin:=0;
      end if;
      v_sellMargin:=v_sellMargin+v_everysellMargin;
      --修改交收持仓明细配对状态=部分配对，已配对数量，已配对保证金
      update T_SettleHoldPosition
         set MATCHStatus=v_matchsSatus   ,happenmatchqty = happenmatchqty + v_quantity  ,happenmatchgageqty = happenmatchgageqty + v_gagequantity
             ,happenMatchSettleMargin=happenMatchSettleMargin+v_everysellMargin
       where id=debit.id;
      --插入交收配对关联表
      insert into T_MatchSettleholdRelevance (MatchID, SettleID, Quantity, Price, SettlePayOut, Settlemargin ,Gageqty)
      values (p_matchId, debit.id, v_quantity+v_gagequantity, v_price, 0, v_everysellMargin ，v_gagequantity);

      exit when v_weight=0 and v_gageweight=0;
    end loop;
    
    if(v_weight>0) then
       RAISE_APPLICATION_ERROR(-20000,'交收数据配对处理失败');
    end if;
    if(v_gageweight>0) then
       RAISE_APPLICATION_ERROR(-20000,'交收数据抵顶配对处理失');
    end if;
 
    --插入交收配对表
    insert into T_SettleMatch ( MatchID,  CommodityID,  ContractFactor,  Quantity,Status,Result,SettleType, FirmID_B,  BuyPrice,  BuyPayout_Ref,  BuyPayout
                                ,BuyMargin, FirmID_S,SellPrice,SellIncome_Ref,SellIncome,SellMargin,CreateTime,ModifyTime,SettleDate, Modifier )
    values ( p_matchId,p_commodityId,v_contractFactor,p_quantity,p_status,p_result,v_settleType,p_firmID_B,v_settleprice_b,v_buypayout_ref,v_buyPayout
             ,v_buyMargin,p_firmID_S,v_settleprice_s,v_sellincom_ref,0,v_sellMargin,sysdate, sysdate,to_date(v_settleDate,'yyyy-MM-dd'),p_operator);
    --插入交收配对日志表
    insert into T_SettleMatchLog(id,Matchid,operator,Operatelog,Updatetime)
    values ( seq_t_settlematchlog.nextval,p_matchId,p_operator,'添加交收配对：配对数量'||p_quantity||',买方：'||p_firmID_B||',价格：'
             ||v_settleprice_b||',卖方:'||p_firmID_S||'价格：'||v_settleprice_s,sysdate );
    --add by lyf 20160804 添加配对后减去冻结数据
    v_quantity:=p_quantity;
    begin
       for bl in (select firmid, commodityid,delay_orderno,frozen from br_billQtyFrozen where firmid=p_firmID_S and commodityid=p_commodityId order by delay_orderno )
       loop
           v_frozen:=bl.frozen;
           if v_quantity<=v_frozen then
              --add by lyf 20160804 撤单的时候减去冻结仓单
              update br_billQtyFrozen set frozen = frozen - v_quantity,modifydate=sysdate where delay_orderno = bl.delay_orderno;  
              exit;
           else
              update br_billQtyFrozen set frozen = frozen - v_quantity,modifydate=sysdate where delay_orderno = bl.delay_orderno;
              v_quantity:=v_quantity-bl.frozen;
           end if;
       end loop;
    exception
      when NO_DATA_FOUND then
      RAISE_APPLICATION_ERROR(-20000,'不存在数据');
    end;
return 1;
end;
/

