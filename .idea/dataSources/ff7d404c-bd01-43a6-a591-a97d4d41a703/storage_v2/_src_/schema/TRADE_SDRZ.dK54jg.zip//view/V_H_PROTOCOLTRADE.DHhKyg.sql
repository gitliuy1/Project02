CREATE VIEW V_H_PROTOCOLTRADE AS
  select CLEARDATE,
       Q.A_TRADENO,
       A_ORDERNO,
       TRADETIME,
       CUSTOMERID,
       COMMODITYID,
       BS_FLAG,
       case
         when TRADETYPE = 6 then
          '协议交收'
       end ORDERTYPE,
       PRICE,
       QUANTITY,
       CLOSE_PL,
       TRADEFEE,
       SWAPFEE,
       TRADETYPE,
       HOLDPRICE,
       HOLDTIME,
       FIRMID,
       CLOSEADDEDTAX,
       FIRMNAME,
       Q.OPPCUSTOMERID,
       null TIMEFLAG,
       ATCLEARDATE,
       TRADEATCLEARDATE,
       '' OPPCUSTOMERNAME
  from (select a.*, m.name FirmName, a.oppFirmId oppCustomerID-- ,o.timeflag ,om.name OPPCUSTOMERNAME
          from T_H_TRADE a, M_firm m -- , t_h_orders o ,M_firm om
         where m.firmID = a.firmID -- and om.firmid=a.oppfirmid
         and a.tradetype = 6
           -- and a.a_orderno = o.a_orderno
         order by a.firmID, a.a_orderno) Q
/

