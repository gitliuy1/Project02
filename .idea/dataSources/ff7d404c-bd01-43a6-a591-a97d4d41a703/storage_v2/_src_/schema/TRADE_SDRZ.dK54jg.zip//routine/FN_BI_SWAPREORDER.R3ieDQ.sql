CREATE function FN_BI_SwapReOrder(    p_firmId        varchar2       ---发起方交易商
                                                ,p_stockids     varchar2       ---发起方仓单
                                                ,p_compensate   number         ---发起方补贴资金
                                                ,p_swapway      number         ---过户方式：1串换，2 转让 3质押
                                                ,p_clearWay     number         ---结算方式：1现金结算, 2自行结算
                                                ,p_o_firmId     varchar2       ---对手交易商
                                                ,p_o_stockids   varchar2       ---对手仓单
                                                ,p_o_compensate number         ---对手补贴资金
                                                ,p_auditor      varchar2       ---操作人，委托人，合同拟定人
                                                ,p_remark       varchar2       ---备注
                                                ,p_orderNo       varchar2      ---委托号
)
return number as
/****
 * 功能：重新入仓单过户(串换、转让、抵押)委托 yuansr 2017 06 16
 * 返回值:  >0 =委托号 ;-1=委托交易商非法 ;-2=委托对手交易商非法 ;-3=未指定串换仓单;-4=发起方仓单不可用;-5=发起方资金不足
 *          ; -6=不是可重新委托状态；-7=重新委托前撤单失败    -100=其它错误
****/
  v_result           number(2);
  v_count            number(6);
  v_stockids         BI_SWAPSTOCKORDERS.STOCKIDS%type :=''; ---串换仓单
  v_errorcode        number;
  v_errormsg         varchar2(200);
  v_F_FrozenFunds    F_FIRMBALANCE.LASTBALANCE%type;
  v_A_Funds          number(15,2);   --可用资金
  v_status           BI_SWAPSTOCKORDERS.Status%type;
  v_sql              varchar2(500);
  type c_item is ref cursor;
  v_item             c_item;
  v_stockId          bi_stock.stockid%type;
begin
  
  select t.status into v_status from  bi_swapstockorders t where  t.orderno=p_orderNo for update;
  
  if (v_status=2) then
    v_result:=fn_bi_swaporder_wd(p_orderNo,2,null,null );
    
    if nvl(v_result,0) <>1 then --撤单失败
       rollback;
      return -7;
    end if;
  else--状态不对
     rollback;
     return -6;
  end if;
  
  ---1 验证交易商是否合法
  select count(1) into v_count from m_firm t where t.firmid=p_firmId;
  if v_count<>1 then
  rollback;
    return -1;
  end if;
  
  ---2 验证对手交易商是否合法
  select count(1) into v_count from m_firm t where t.firmid=p_o_firmId;
  if v_count<>1 then
    rollback;
    return -2;
  end if;
  
  if p_swapway=1 and (p_stockids is null or length(p_stockids )<1 ) then
    rollback;
    return -3;
  end if;

  if p_swapway=1 and (p_o_stockids is null or length(p_o_stockids )<1 ) then
    rollback;
    return -3;
  end if;

  ---4 验证发起方仓单是否可用，可用则冻结仓单
  v_sql:='select t.stockid  from bi_stock t where t.ownerfirm='''||p_firmId||''''
       ||'   and t.stockstatus=1 and t.stockid in('''|| replace(p_stockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND; 
       v_result:=fn_bi_frozenSwapBill(p_firmId ,'15'  ,v_stockId);
       if v_result<>1 then
          rollback;
          return -4;
       end if;
       v_stockids:=v_stockids||','||v_stockId;
  end loop;
  close v_item;
  
  if (p_stockids is not null and length(p_stockids )>0 )  then
    if( length(','||p_stockids) = length(v_stockids) ) then
        v_stockids:=p_stockids;
     else
       rollback;
        return -4; 
     end if;
  else
    v_stockids:=p_stockids;
  end if;

  ---4 当结算方式是资金结算且有附加资金，验证交易商资金是否充足
  if p_clearWay=1 and p_compensate>0 then
     --计算可用资金，并锁住财务资金
     v_A_Funds := FN_F_GetRealFunds(p_FirmID,1);
     if(v_A_Funds < p_compensate) then
        rollback;
        return -5;  --资金余额不足
     end if;
     --更新冻结资金,成交流水为 订单收交易商货款 15008
     v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID,p_compensate,'15');
  end if;

  --调用计算函数生成委托单号
  ---select FN_T_ComputeOrderNo(SEQ_BI_SwapStockOrders.nextval) into v_orderno from dual;

  update bi_swapstockorders t 
     set t.stockids=v_stockids ,t.compensate=nvl(p_compensate,0) ,t.modifytime=sysdate ,t.firmid=p_firmid ,t.swapway=p_swapway 
         ,t.clearway=p_clearWay ,t.o_firmid=p_o_firmid ,t.o_stockids=p_o_stockids ,t.o_compensate=nvl(p_o_compensate,0) 
         ,t.status=1 ,t.auditor=p_auditor ,t.remark=p_remark,t.wdkind=null
  where  t.orderno=p_orderNo;

  return p_orderNo;

  exception
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_BI_SwapReOrder',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

