CREATE function FN_T_CloseTrade20161129(
   p_A_OrderNo             number, --委托单号
   p_M_TradeNo             number, --撮合成交号
   p_Price                 number, --成交价
   p_Quantity              number, --成交数量
   p_M_TradeNo_Opp         number, --对方撮合成交号
   p_CommodityID           varchar2,
   p_FirmID                varchar2,
   p_TraderID              varchar2,
   p_bs_flag               number,
   p_status                number,
   p_orderQty              number, --委托数量
   p_orderTradeQty         number, --委托已成交数量
   p_CustomerID            varchar2,
   p_OrderType             number,
   p_closeMode             number,
   p_specPrice             number,
   p_timeFlag              number,
   p_CloseFlag             number,
   p_contractFactor        number,
   p_MarginPriceType       number, --计算成交保证金结算价类型 0:实时和闭市时都按开仓价；1:实时按昨结算价，闭市按当日结算价;2:盘中按订立价，闭市结算时按当日结算价;
   p_marginAlgr            number,
   p_marginRate_b          number,
   p_marginRate_s          number,
   p_marginAssure_b        number,
   p_marginAssure_s        number,
   p_feeAlgr               number,
   p_feeRate_b             number,
   p_feeRate_s             number,
   p_TodayCloseFeeRate_B   number,
   p_TodayCloseFeeRate_S   number,
   p_HistoryCloseFeeRate_B number,
   p_HistoryCloseFeeRate_S number,
   p_ForceCloseFeeAlgr     number,
   p_ForceCloseFeeRate_B   number,
   p_ForceCloseFeeRate_S   number,
   p_YesterBalancePrice    number,
   p_AddedTaxFactor        number, --增值税率系数=AddedTax/(1+AddedTax)
   p_GageMode              number,
   p_CloseAlgr             number,
   p_TradeDate             date,
   p_FirmID_opp            varchar2 --对手交易商ID
                                           ) return number
/****
   * 平仓成交回报
   * 1、注意不要提交commit，因为别的函数要调用它；
   * 返回值
   * 1 成功
   * -1 成交数量大于未成交数量
   * -2 成交数量大于冻结数量
   * -3 平仓成交数量大于持仓数量
   * -100 其它错误
  ****/
 as
  v_version           varchar2(10) := '1.0.2.2';
  v_price             number(15, 2);
  v_frozenQty         number(10);
  v_holdQty           number(10);
  v_a_tradeno_closed  number(15);
  v_Margin            number(15, 2) := 0; --应收保证金
  v_Assure            number(15, 2) := 0; --应收担保金
  v_Fee               number(15, 2) := 0; --应收费用
  v_Fee_one           number(15, 2); --应收费用
  v_A_TradeNo         number(15);
  v_A_HoldNo          number(15);
  v_id                number(15);
  v_tmp_bs_flag       number(2);
  v_TradeType         number(1);
  v_AtClearDate       date;
  v_HoldTime          date;
  v_MarginPrice       number(15, 2); --计算成交保证金的价格
  v_HoldFunds         number(15, 2) := 0; --平仓时应退持仓金额
  v_unCloseQty        number(10) := p_quantity; --未平数量，用于中间计算
  v_closeFL           number(15, 2) := 0;
  v_closeFL_one       number(15, 2); --单笔平仓盈亏，用于中间计算
  v_CloseAddedTax_one number(15, 2); --单笔平仓增值税
  v_margin_one        number(15, 2); --用于中间计算
  v_Assure_one        number(15, 2); --用于中间计算
  v_tradedAmount      number(10) := 0; --成交数量
  v_GageQty           number(10);
  v_GageQty_fsum      number(10);
  v_F_FrozenFunds     number(15, 2);
  type c_T_HoldPosition is ref cursor;
  v_T_HoldPosition c_T_HoldPosition;
  v_sql            varchar2(500);
  v_str            varchar2(200);
  v_orderby        varchar2(100);
  v_closeTodayHis  number(2); --平今仓还是历史仓(0平今仓；1平历史仓)
  v_num            number(10);
  v_holddaysLimit  number(1) := 0;
  v_holddays       number(10);
  v_numqty         number(10);
  v_A_OrderNo      number(10);
  v_overdat        number(10);
  v_bs_flag        number(2);
  v_contractFactor t_commodity.contractfactor%type;
  v_A_HoldNo_MS    t_holdposition.a_holdno%type;
  v_margin_one_ms  number(15, 2); --用于中间计算
  v_Assure_one_ms  number(15, 2); --用于中间计算
  v_margin_one_mb  number(15, 2); --用于中间计算
  v_Assure_one_mb  number(15, 2); --用于中间计算
  v_marginAlgr     number(2);
  v_marginRate_b   number(10, 4);
  v_marginRate_s   number(10, 4);
  v_marginAssure_b number(10, 4);
  v_marginAssure_s number(10, 4);
  v_Margin_ms      number(15, 2) := 0; --应收保证金
  v_Assure_ms      number(15, 2) := 0; --应收担保金
  v_openprice      t_quotation.openprice%type; --开盘价
  v_swapfee        number(15, 2) := 0; --add by lyf 20160126 调期费用
  v_a_overdat        number(10);        --add by yuansr 20161008 到期天数
  v_getmarginsql     varchar2(2000);    --持仓天数对应保证金阶段设置查询语句
  v_marginsetsql     varchar2(200);     --持仓天数对应保证金阶段查询语句
  v_h_margin_one  number(15, 2);        --用于中间计算历史持仓保证金
  v_h_Assure_one  number(15, 2);        --用于中间计算历史持仓担保金
  v_h_marginRate_b   number(10, 4);     --历史持仓保证金设置
  v_h_marginRate_s   number(10, 4);     --历史持仓保证金设置
  v_h_marginAssure_b number(10, 4);     --历史持仓保证金设置
  v_h_marginAssure_s number(10, 4);     --历史持仓保证金设置
  v_h_Margin_ms      number(15, 2) := 0; --历史持仓保证金设置
  v_h_Assure_ms      number(15, 2) := 0; --历史持仓保证金设置
begin
/*  insert into fangtest1
    (p_a_orderno, p_m_tradeno, p_price, p_quantity, p_m_tradeno_opp, p_commodityid, p_firmid, p_traderid, p_bs_flag, p_status, p_orderqty, p_ordertradeqty, p_customerid, p_ordertype, p_closemode, p_specprice, p_timeflag, p_closeflag, p_contractfactor, p_marginpricetype, p_marginalgr, p_marginrate_b, p_marginrate_s, p_marginassure_b, p_marginassure_s, p_feealgr, p_feerate_b, p_feerate_s, p_todayclosefeerate_b, p_todayclosefeerate_s, p_historyclosefeerate_b, p_historyclosefeerate_s, p_forceclosefeealgr, p_forceclosefeerate_b, p_forceclosefeerate_s, p_yesterbalanceprice, p_addedtaxfactor, p_gagemode, p_closealgr, p_tradedate, p_firmid_opp)
  values
    (p_a_orderno, p_m_tradeno, p_price, p_quantity, p_m_tradeno_opp, p_commodityid, p_firmid, p_traderid, p_bs_flag, p_status, p_orderqty, p_ordertradeqty, p_customerid, p_ordertype, p_closemode, p_specprice, p_timeflag, p_closeflag, p_contractfactor, p_marginpricetype, p_marginalgr, p_marginrate_b, p_marginrate_s, p_marginassure_b, p_marginassure_s, p_feealgr, p_feerate_b, p_feerate_s, p_todayclosefeerate_b, p_todayclosefeerate_s, p_historyclosefeerate_b, p_historyclosefeerate_s, p_forceclosefeealgr, p_forceclosefeerate_b, p_forceclosefeerate_s, p_yesterbalanceprice, p_addedtaxfactor, p_gagemode, p_closealgr, p_tradedate, p_firmid_opp);
 commit;*/
  select overdat into v_holddays from t_commodity where commodityid = p_CommodityID;
  if (p_TraderID is not null) then
    v_TradeType := 1; --有交易员为正常交易（开，平仓）
  else
    if (p_CloseFlag = 2) then
      v_TradeType := 3; --交易员为空且平仓标志为2表示市场强平
    else
      v_TradeType := 4; --否则有交易员的表示委托交易（开，平仓）
    end if;
  end if;

  if (p_bs_flag = 1) then
    --委托平仓的买卖标志
    v_tmp_bs_flag := 2; --相当于被平仓的买卖标志
  else
    v_tmp_bs_flag := 1;
  end if;
  select frozenqty  into v_frozenQty from T_CustomerHoldSum where CustomerID = p_CustomerID and CommodityID = p_CommodityID and bs_flag = v_tmp_bs_flag for update;
  if (v_frozenqty < p_quantity) then
    rollback;
    return -2;
  end if;
/* insert into fangtest2 values(p_closeMode,'p_closeMode');---1*/
  --指定平仓查询条件
  if (p_closeMode = 2) then
    --指定时间平仓
   /* insert into fangtest2 values(p_timeFlag,'p_timeFlag');---2*/
    if (p_timeFlag = 1) then
      --平今仓
      --从持仓明细表获得该交易客户当日该商品持仓合计
      v_str := ' and to_char(AtClearDate,''yyyy-MM-dd'')=''' || to_char(p_TradeDate, 'yyyy-MM-dd') || ''' ';
    elsif (p_timeFlag = 2) then
      --平历史仓
      --从持仓明细表获得该交易客户非当日该商品持仓合计
      v_str := ' and to_char(AtClearDate,''yyyy-MM-dd'')<>''' || to_char(p_TradeDate, 'yyyy-MM-dd') || ''' ';
    end if;
  elsif (p_closeMode = 3) then
    --指定价格平仓
    v_str := ' and Price =' || p_specPrice || ' ';
  end if;
  --根据平仓算法(0先开先平；1后开先平；2持仓均价平仓(不排序)选择排序条件
  --2009-08-04增加强平时按后开先平顺序
  if (p_TraderID is null and p_CloseFlag = 2) then
    -- add by lyf 20160529 增加浮动盈亏的计算在order by后面 ； v_tmp_bs_flag是持仓的买卖标志

    --v_orderby := ' order by a.A_HoldNo desc ';
    select holddayslimit into v_holddaysLimit from t_commodity where commodityid = p_CommodityID;
    if (v_holddaysLimit = 0) then
      --无持仓天数限制
      v_orderby := ' order by ('||p_price||'-price)*(a.HoldQty+a.GageQty)*'||p_contractFactor||',a.A_HoldNo desc ';
    else
      v_orderby := ' order by (price-'||p_price||')*(a.HoldQty+a.GageQty)*'||p_contractFactor||',a.A_HoldNo asc ';
    end if;
  else
    if (p_CloseAlgr = 0) then
      v_orderby := ' order by a.A_HoldNo ';
    elsif (p_CloseAlgr = 1) then
      v_orderby := ' order by a.A_HoldNo desc ';
    end if;
  end if;
  v_str := v_str || v_orderby;

  if (p_Quantity = p_orderQty - p_orderTradeQty) then
   /* insert into fangtest2 values(p_Quantity,'p_Quantity');---3*/
    --更新委托
    update T_Orders set tradeqty   = tradeqty + p_Quantity,Status = 3,UpdateTime = systimestamp(3) where A_orderNo = p_A_OrderNo;
  elsif (p_Quantity < p_orderQty - p_orderTradeQty) then
    /*insert into fangtest2 values(p_orderQty - p_orderTradeQty,'p_orderQty - p_orderTradeQty');---4*/
    --更新委托
    if (p_status = 6) then
      --状态为部分成交后撤单，如果部分成交回报在撤单回报之后，不用再更新状态了
      update T_Orders set tradeqty = tradeqty + p_Quantity, UpdateTime = systimestamp(3) where A_orderNo = p_A_OrderNo;
    else
      update T_Orders set tradeqty   = tradeqty + p_Quantity,Status = 2, UpdateTime = systimestamp(3) where A_orderNo = p_A_OrderNo;
    end if;
  else
    rollback;
    return - 1;
  end if;

  --不指定平仓平持仓记录时以持仓明细表为主，而指定平仓时以当日指定平仓冻结表为主
  if (p_closeMode = 1) then
    --不指定平仓
    --遍历持仓明细的数量并过滤掉指定平仓冻结的数量,此平仓没用到b.ID，因为b中没有它，所以用0替换
    v_sql := 'select a.overdat , a.a_holdno,a_tradeno,price,(a.HoldQty-nvl(b.FrozenQty,0)),GageQty,HoldTime,AtClearDate,nvl(b.FrozenQty,0),0 from T_holdposition a,(select A_HoldNo,nvl(sum(FrozenQty),0) FrozenQty from T_SpecFrozenHold group by A_HoldNo) b ' ||
             ' where (a.HoldQty+a.GageQty) > 0 and a.A_HoldNo=b.A_HoldNo(+) and nvl(b.FrozenQty,0)<a.HoldQty and CustomerID=''' ||
             p_CustomerID || ''' and CommodityID =''' || p_CommodityID ||
             ''' and bs_flag = ' || v_tmp_bs_flag || v_str;
  else
    --指定平仓
    v_sql := 'select a.overdat ,a.a_holdno,a_tradeno,price,HoldQty,GageQty,HoldTime,AtClearDate,nvl(b.FrozenQty,0),b.ID from T_holdposition a,T_SpecFrozenHold b ' ||
             ' where (a.HoldQty+a.GageQty) > 0 and b.A_HoldNo=a.A_HoldNo(+) and b.A_OrderNo= ' ||
             p_A_OrderNo || v_str;
  end if;
  open v_T_HoldPosition for v_sql;
  loop
    fetch v_T_HoldPosition
      into v_a_overdat ,v_a_holdno, v_a_tradeno_closed, v_price, v_holdqty, v_GageQty, v_HoldTime, v_AtClearDate, v_frozenQty, v_id;
    exit when v_T_HoldPosition%NOTFOUND;
    if (p_closeMode = 1) then
      --不指定平仓
      if (v_holdqty <= v_unCloseQty) then
        v_tradedAmount := v_holdqty;
      else
        v_tradedAmount := v_unCloseQty;
      end if;
    else
      --指定平仓
      if (v_frozenQty<=v_unCloseQty) then
        v_tradedAmount := v_frozenQty;
        delete from T_SpecFrozenHold where id=v_id;
        /*return -2;*/
      else
        v_tradedAmount := v_unCloseQty;
        update T_SpecFrozenHold  set FrozenQty = FrozenQty - v_tradedAmount where id = v_id;
      end if;
    end if;
    --判断是平今仓还是平历史仓
    if (trunc(p_TradeDate) = trunc(v_AtClearDate)) then
      v_closeTodayHis := 0;
    else
      v_closeTodayHis := 1;
    end if;
    /*insert into fangtest2 values(v_closeTodayHis,'v_closeTodayHis');---5*/
    --计算成交后应扣除的手续费
    if (v_TradeType = 3) then
      --强平
      v_Fee_one := FN_T_ComputeFeeByArgs(p_bs_flag,v_tradedAmount,p_Price,p_contractFactor,p_ForceCloseFeeAlgr,p_ForceCloseFeeRate_B,p_ForceCloseFeeRate_S);
    else
      --其它，如果平的是今天开的仓则按今开今平手续费计算
      if (v_closeTodayHis = 0) then
        --平今仓
        v_Fee_one := FN_T_ComputeFeeByArgs(p_bs_flag, v_tradedAmount,p_Price, p_contractFactor,p_feeAlgr,p_TodayCloseFeeRate_B,p_TodayCloseFeeRate_S);
      else
        --平历史仓
        v_Fee_one := FN_T_ComputeFeeByArgs(p_bs_flag,v_tradedAmount, p_Price, p_contractFactor,p_feeAlgr,p_HistoryCloseFeeRate_B,p_HistoryCloseFeeRate_S);
      end if;
    end if;
    if (v_Fee_one < 0) then
      Raise_application_error(-20030, 'computeFee error');
    end if;
    --计算应退保证金，根据设置选择开仓价还是昨结算价来算
    if (p_MarginPriceType = 1) then
      v_MarginPrice := p_YesterBalancePrice;
    elsif (p_MarginPriceType = 2) then
      if (v_closeTodayHis = 0) then
        --平今仓
        v_MarginPrice := v_price;
      else
        --平历史仓
        v_MarginPrice := p_YesterBalancePrice;
      end if;
    else
      -- default type is 0
      v_MarginPrice := v_price;
    end if;

    v_Margin_one := FN_T_ComputeMarginByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor, p_marginAlgr,p_marginRate_b,p_marginRate_s);
    
    if (v_closeTodayHis = 1) then --平历史仓，重新计算保证金 yuansr 2016 10 08 
        --根据持仓日期 获取对应阶段的交易保证金算法设置,计算保证金 
        select case when settledays1 is null or v_a_overdat is null
                    then 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s'
                    when settleDays1 is not null and v_a_overdat<=settleDays1 and (settleDays2 is null or v_a_overdat>settleDays2)
                    then 'marginitem1 ,marginitem1_s ,marginitemassure1 ,marginitemassure1_s'
                    when settleDays2 is not null and v_a_overdat<=settleDays2 and (settleDays3 is null or v_a_overdat>settleDays3)
                    then 'marginitem2 ,marginitem2_s ,marginitemassure2 ,marginitemassure2_s'
                    when settleDays3 is not null and v_a_overdat<=settleDays3 and (settleDays4 is null or v_a_overdat>settleDays4)
                    then 'marginitem3 ,marginitem3_s ,marginitemassure3 ,marginitemassure3_s'
                    when settleDays4 is not null and v_a_overdat<=settleDays4 and (settleDays5 is null or v_a_overdat>settleDays5)
                    then 'marginitem4 ,marginitem4_s ,marginitemassure4 ,marginitemassure4_s'
                    when settleDays5 is not null and v_a_overdat<=settleDays5
                    then 'marginitem5 ,marginitem5_s ,marginitemassure5 ,marginitemassure5_s'
               else 'marginrate_b,marginrate_s,marginAssure_b,marginAssure_s' end
          into v_marginsetsql
          from t_commodity
         where commodityid=p_CommodityID ;
        v_getmarginsql:='select '||v_marginsetsql||'  from t_commodity where commodityid='''||p_CommodityID||'''' ;
        --dbms_output.put_line(v_getmarginsql);
        execute immediate v_getmarginsql into v_h_marginRate_b,v_h_marginRate_s,v_h_marginAssure_b,v_h_marginAssure_s;
        begin
          --获取特户的交易担保金，保证金算法
          v_getmarginsql:=' select '||v_marginsetsql||'  from T_A_FirmMargin where FirmId='''||p_FirmID||''' and  commodityid='''||p_CommodityID||'''' ;
          execute immediate v_getmarginsql into v_h_marginRate_b,v_h_marginRate_s,v_h_marginAssure_b,v_h_marginAssure_s;
          exception
              when NO_DATA_FOUND then
                  null;
        end;
        v_Margin_one := FN_T_ComputeMarginByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor, p_marginAlgr,v_h_marginRate_b,v_h_marginRate_s);
    end if;
        
    if (v_Margin_one < 0) then
      Raise_application_error(-20040, 'computeMargin error');
    end if;
    --计算担保金
    v_Assure_one := FN_T_ComputeAssureByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor, p_marginAlgr, p_marginAssure_b,p_marginAssure_s);
    
    if (v_closeTodayHis = 1) then--平历史仓，重新计算担保金，依赖保证金获取的设置 yuansr 2016 10 08 
        --根据持仓日期 获取对应阶段的交易担保金算法设置,计算担保金
        v_Assure_one := FN_T_ComputeAssureByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor, p_marginAlgr, v_h_marginAssure_b,v_h_marginAssure_s);
    end if;
    
    if (v_Assure_one < 0) then
      Raise_application_error(-20040, 'computeAssure error');
    end if;
    --保证金应加上担保金
    v_Margin_one := v_Margin_one + v_Assure_one;
    --计算应退持仓金额
    v_HoldFunds := v_HoldFunds +v_tradedAmount * v_price * p_contractFactor;
    --计算平仓盈亏
    if (v_tmp_bs_flag = 1) then
      --v_tmp_bs_flag是持仓的买卖标志
      v_closeFL_one := v_tradedAmount * (p_price - v_price) *p_contractFactor; --税前盈亏
    else
      v_closeFL_one := v_tradedAmount * (v_price - p_price) *p_contractFactor; --税前盈亏
    end if;
    --计算平仓增值税,v_AddedTaxFactor增值税系数=AddedTax/(1+AddedTax)
    v_CloseAddedTax_one := round(v_closeFL_one * p_AddedTaxFactor, 2);
    v_closeFL_one       := v_closeFL_one - v_CloseAddedTax_one; --税后盈亏

   /* -- add by lyf 20160126 增加调期费用计算
    if (p_Firmid<>'63300555') then
      v_swapfee := FN_T_ComputeSwapFee(v_a_holdno,v_tradedAmount, p_bs_flag);
      if (v_swapfee < 0) then
        Raise_application_error(-20030, 'FN_T_ComputeSwapFee error');
      end if;
    end if;*/
    --调用计算函数修改成交单号 2011-2-15 by feijl
    select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_A_TradeNo from dual;
    --add by lyf 20160204 生成成交单子的时候要区分是平今仓还是平历史
    if (v_closeTodayHis = 0) then
      --平平今仓
      insert into T_Trade(a_tradeno,m_tradeno,a_orderno,a_tradeno_closed,tradetime,Firmid,CommodityID, bs_flag,ordertype,
         price,quantity,close_pl, tradefee,TradeType, HoldPrice, HoldTime,CustomerID,CloseAddedTax, M_TradeNo_Opp,AtClearDate,TradeAtClearDate,oppFirmid,swapfee)
      values(v_A_TradeNo,p_M_TradeNo,p_A_OrderNo,v_a_tradeno_closed,sysdate, p_Firmid, p_CommodityID,p_bs_flag,p_ordertype,
         p_price,v_tradedAmount,v_closeFL_one,v_Fee_one,v_TradeType,v_price, v_HoldTime, p_CustomerID, v_CloseAddedTax_one,p_M_TradeNo_Opp,v_AtClearDate,p_TradeDate,p_FirmID_opp, v_swapfee);
    else
       -- add by lyf 20160126 增加调期费用计算
      if (p_Firmid<>'63300555') then
        v_swapfee := FN_T_ComputeSwapFee(v_a_holdno,v_tradedAmount, p_bs_flag);
        /*if (v_swapfee < 0) then
          Raise_application_error(-20030, 'FN_T_ComputeSwapFee error');
        end if;*/
      end if;
      insert into T_Trade(a_tradeno,m_tradeno,a_orderno,a_tradeno_closed,tradetime,Firmid,CommodityID,bs_flag,ordertype,
         price,quantity,close_pl,tradefee,TradeType,HoldPrice, HoldTime,CustomerID,CloseAddedTax,M_TradeNo_Opp,AtClearDate,TradeAtClearDate,oppFirmid,swapfee)
      values
        (v_A_TradeNo, p_M_TradeNo,p_A_OrderNo,v_a_tradeno_closed,sysdate,p_Firmid,p_CommodityID,p_bs_flag, p_ordertype,p_price,v_tradedAmount,v_closeFL_one,v_Fee_one, v_TradeType,
        v_price,v_HoldTime,p_CustomerID,v_CloseAddedTax_one, p_M_TradeNo_Opp,v_AtClearDate, p_TradeDate,'63300555', v_swapfee);
    end if;
    insert into ff(firmid,commodityid, closetodayhis,createdate,atcleardate,bs_flag,A_OrderNo)
    values(p_firmid, p_CommodityID,v_closetodayhis,sysdate,v_AtClearDate,p_bs_flag,p_A_OrderNo);
    --更新持仓记录
    update T_holdposition
       set holdqty    = holdqty - v_tradedAmount,
           HoldMargin = HoldMargin - v_Margin_one,
           HoldAssure = HoldAssure - v_Assure_one
     where a_holdno = v_a_holdno;
    v_unCloseQty := v_unCloseQty - v_tradedAmount;

    v_Margin  := v_Margin + v_Margin_one;
    v_Assure  := v_Assure + v_Assure_one;
    v_Fee     := v_Fee + v_Fee_one + v_swapfee;
    v_closeFL := v_closeFL + v_closeFL_one;

    /*exit when v_unCloseQty=0;*/ -- modify by lyf 2015-12-17 放到做市商后面
    -- add by lyf 2015-12-13  增加做市商持仓明细
    /*select SEQ_T_DelayOrders.nextval into v_A_OrderNo from dual;*/
    if (v_closeTodayHis <> 0) then
      --平历史仓
      --获取特户的交易保证金，保证金算法
      begin
          /*select marginalgr,marginrate_b,marginrate_s,marginAssure_b,marginAssure_s
        into v_marginAlgr,v_marginRate_b,v_marginRate_s,v_marginAssure_b,v_marginAssure_s
          from T_A_FirmMargin
          where FirmID='63300555' and CommodityID=p_CommodityID;*/
          
          --根据持仓日期 获取对应阶段的 交易保证金、担保金算法设置 yuansr 2016 10 08 
          v_getmarginsql:='select '||v_marginsetsql||'  from T_A_FirmMargin where FirmID=''63300555'' and CommodityID='''||p_CommodityID||'''';
          --dbms_output.put_line(v_getmarginsql);
          execute immediate v_getmarginsql into v_h_marginRate_b,v_h_marginRate_s,v_h_marginAssure_b,v_h_marginAssure_s;
      exception
          when NO_DATA_FOUND then
              null;
      end;
      for th in (select * from T_holdposition where a_holdno = v_a_holdno) loop
        select overdat, contractFactor into v_overdat, v_contractFactor from t_commodity where commodityid = p_CommodityID;
        if v_overdat<0 then
           v_overdat:=0;
        end if;
        -- select openprice into v_openprice from t_quotation where commodityid=p_CommodityID;
        if th.bs_flag = 1 then
          v_bs_flag := 2;
          --计算保证金  t_a_firmmargin
          v_Margin_one_ms := FN_T_ComputeMarginByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr, v_marginRate_b,v_marginRate_s);
          if (v_Margin_one_ms < 0) then
            Raise_application_error(-20040, 'computeMargin error');
          end if;
          --计算担保金
          v_Assure_one_ms := FN_T_ComputeAssureByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr,v_marginAssure_b,v_marginAssure_s);
          if (v_Assure_one_ms < 0) then
            Raise_application_error(-20040, 'computeAssure error');
          end if;
          --保证金应加上担保金
          v_Margin_one_ms := v_Margin_one_ms + v_Assure_one_ms;
          
          --计算历史持仓阶段保证金  yuansr 2016 10 08
          v_h_Margin_one := FN_T_ComputeMarginByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr, v_h_marginRate_b,v_h_marginRate_s);
          if (v_h_Margin_one < 0) then
            Raise_application_error(-20040, 'computeH2Margin error');
          end if;
          --计算历史持仓阶段担保金
          v_h_Assure_one := FN_T_ComputeAssureByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr,v_h_marginAssure_b,v_h_marginAssure_s);
          if (v_h_Assure_one < 0) then
            Raise_application_error(-20040, 'computeH2Assure error');
          end if;
          --历史持仓阶段保证金应加历史持仓阶段上担保金
          v_h_Margin_one := v_h_Margin_one + v_h_Assure_one;
        else
          v_bs_flag := 1;
          --计算保证金  t_a_firmmargin
          v_Margin_one_mb := FN_T_ComputeMarginByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr,v_marginRate_b,v_marginRate_s);
          if (v_Margin_one_mb < 0) then
            Raise_application_error(-20040, 'computeMargin error');
          end if;
          --计算担保金
          v_Assure_one_mb := FN_T_ComputeAssureByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor, v_marginAlgr, v_marginAssure_b,v_marginAssure_s);
          if (v_Assure_one_mb < 0) then
            Raise_application_error(-20040, 'computeAssure error');
          end if;
          --保证金应加上担保金
          v_Margin_one_ms := v_Margin_one_mb + v_Assure_one_mb;
          v_Assure_one_ms := v_Assure_one_mb;
          
          --计算历史持仓阶段保证金  yuansr 2016 10 08
          v_h_Margin_one := FN_T_ComputeMarginByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr, v_h_marginRate_b,v_h_marginRate_s);
          if (v_h_Margin_one < 0) then
            Raise_application_error(-20040, 'computeH1Margin error');
          end if;
          --计算历史持仓阶段担保金
          v_h_Assure_one := FN_T_ComputeAssureByArgs(v_bs_flag,v_tradedAmount,v_MarginPrice, p_contractFactor,v_marginAlgr,v_h_marginAssure_b,v_h_marginAssure_s);
          if (v_h_Assure_one < 0) then
            Raise_application_error(-20040, 'computeH1Assure error');
          end if;
          --历史持仓阶段保证金应加历史持仓阶段上担保金
          v_h_Margin_one := v_h_Margin_one + v_h_Assure_one;
        end if;

        /* --计算保证金  t_a_firmmargin
          v_Margin_one_ms := FN_T_ComputeMarginByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor,p_marginAlgr,p_marginRate_b,p_marginRate_s);
          if(v_Margin_one_ms < 0) then
              Raise_application_error(-20040, 'computeMargin error');
          end if;
          --计算担保金
          v_Assure_one_ms := FN_T_ComputeAssureByArgs(v_tmp_bs_flag,v_tradedAmount,v_MarginPrice,p_contractFactor,p_marginAlgr,p_marginAssure_b,p_marginAssure_s);
          if(v_Assure_one_ms < 0) then
              Raise_application_error(-20040, 'computeAssure error');
          end if;
        --保证金应加上担保金
        v_Margin_one_ms := v_Margin_one_ms + v_Assure_one_ms;*/

        select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo_MS from dual;
        insert into t_holdposition(a_holdno,a_tradeno,customerid,commodityid,bs_flag,
           price,holdqty,openqty,holdtime,holdmargin, firmid,gageqty,holdassure,floatingloss,holdtype, atcleardate, deadline,remainday,overdat)
        values(v_A_HoldNo_MS,th.a_tradeno,'6330055500',p_CommodityID,th.bs_flag,
           ---th.price,v_tradedAmount, v_tradedAmount,th.holdtime,v_Margin_one_ms,'63300555',th.gageqty,v_Assure_one_ms,th.floatingloss,th.holdtype,th.atcleardate,th.deadline, th.remainday,th.overdat);
               ---历史持仓 使用按持仓天数对应阶段设置计算的保证金、担保金 yuansr 20161008
               th.price,v_tradedAmount, v_tradedAmount,th.holdtime,v_h_Margin_one,'63300555',th.gageqty,v_h_Assure_one,th.floatingloss,th.holdtype,th.atcleardate,th.deadline, th.remainday,th.overdat);
        --生成反向的做市商持仓明细
        select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval)  into v_A_HoldNo_MS from dual;
        insert into t_holdposition(a_holdno,a_tradeno,customerid,commodityid,bs_flag,price,holdqty,openqty,holdtime,holdmargin,firmid,gageqty,holdassure,floatingloss,holdtype,atcleardate,deadline,remainday,overdat)
        values(v_A_HoldNo_MS, th.a_tradeno,'6330055500',p_CommodityID, v_bs_flag,p_price,v_tradedAmount,v_tradedAmount,sysdate,v_Margin_one_ms,'63300555', th.gageqty, v_Assure_one_ms,th.floatingloss,th.holdtype,trunc(sysdate), th.deadline,th.remainday,v_overdat);

        select count(*) into v_num from t_customerholdsum where commodityid = p_CommodityID and firmid = '63300555' and bs_flag = v_bs_flag;
        if v_num > 0 then
          update T_CustomerHoldSum
             set holdQty    = holdQty + v_tradedAmount,
                 holdFunds  = holdFunds +th.price * v_tradedAmount * v_contractFactor,
                 HoldMargin = HoldMargin + v_Margin_one_ms,
                 HoldAssure = HoldAssure + v_Assure_one_ms,
                 evenprice  = (holdFunds +th.price * v_tradedAmount * v_contractFactor) /((holdQty + v_tradedAmount) * v_contractFactor)
           where CustomerID = '6330055500' and CommodityID = p_CommodityID and bs_flag = v_bs_flag;
        else
          insert into T_CustomerHoldSum (CustomerID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,FrozenQty,HoldMargin,HoldAssure, FirmID)
          values('6330055500',p_CommodityID,v_bs_flag,v_tradedAmount, th.price * v_tradedAmount * v_contractFactor,0,th.price,0,v_Margin_one_ms, v_Assure_one_ms,'63300555');
        end if;
        --2更新交易商持仓合计表
        select count(*) into v_num from T_FirmHoldSum where commodityid = p_CommodityID and firmid = '63300555' and bs_flag = v_bs_flag;
        if v_num > 0 then
          update T_FirmHoldSum
             set holdQty    = holdQty + v_tradedAmount,
                 holdFunds  = holdFunds +th.price * v_tradedAmount * v_contractFactor,
                 HoldMargin = HoldMargin + v_Margin_one_ms,
                 HoldAssure = HoldAssure + v_Assure_one_ms,
                 evenprice  = (holdFunds +th.price * v_tradedAmount * v_contractFactor) /((holdQty + v_tradedAmount) * v_contractFactor)
           where Firmid = '63300555' and CommodityID = p_CommodityID and bs_flag = v_bs_flag;
        else
          /*insert into T_FirmHoldSum(FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
          values('63300555',p_CommodityID, v_bs_flag,th.holdqty,th.price * v_tradedAmount * v_contractFactor,0, th.price, v_Margin_one_ms,  v_Assure_one_ms);*/
          --new by renzy 修改交易商合计和交易客户合计中持仓数量不一样问题
          insert into T_FirmHoldSum(FirmID,CommodityID,bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
          values('63300555',p_CommodityID, v_bs_flag,v_tradedAmount,th.price * v_tradedAmount * v_contractFactor,0, th.price, v_Margin_one_ms,  v_Assure_one_ms);
        end if;
        --3 更新交易客户持仓合计表
        select count(*) into v_num from t_customerholdsum where commodityid = p_CommodityID and firmid = '63300555' and bs_flag = th.bs_flag;
        if v_num > 0 then
          update T_CustomerHoldSum
             set holdQty    = holdQty + v_tradedAmount,
                 holdFunds  = holdFunds +th.price * v_tradedAmount * v_contractFactor,
                 HoldMargin = HoldMargin + v_h_Margin_one,---v_Margin_one_ms,---使用按持仓天数对应阶段的保证金yuansr 20161008
                 HoldAssure = HoldAssure + v_h_Assure_one,---v_Assure_one_ms,
                 evenprice  = (holdFunds +th.price * v_tradedAmount * v_contractFactor) /((holdQty + v_tradedAmount) * v_contractFactor)
           where CustomerID = '6330055500' and CommodityID = p_CommodityID and bs_flag = th.bs_flag;
        else
          insert into T_CustomerHoldSum(CustomerID,CommodityID, bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,FrozenQty, HoldMargin,HoldAssure,FirmID)
          values('6330055500',p_CommodityID,th.bs_flag,v_tradedAmount, th.price * v_tradedAmount * v_contractFactor, 0,th.price,0,v_h_Margin_one,v_h_Assure_one/*v_Margin_one_ms,v_Assure_one_ms,*/,'63300555');
        end if;
        --4 更新交易商持仓合计表
        select count(*) into v_num from T_FirmHoldSum where commodityid = p_CommodityID and firmid = '63300555' and bs_flag = th.bs_flag;
        if v_num > 0 then
          update T_FirmHoldSum
             set holdQty    = holdQty + v_tradedAmount,
                 holdFunds  = holdFunds + th.price * v_tradedAmount * v_contractFactor,
                 HoldMargin = HoldMargin + v_h_Margin_one,---v_Margin_one_ms,
                 HoldAssure = HoldAssure + v_h_Assure_one,---v_Assure_one_ms,---使用按持仓天数对应阶段设置的担保金 yuansr 20161008
                 evenprice  = (holdFunds +th.price * v_tradedAmount * v_contractFactor) /((holdQty + v_tradedAmount) * v_contractFactor)
           where Firmid = '63300555'
             and CommodityID = p_CommodityID
             and bs_flag = th.bs_flag;
        else
          insert into T_FirmHoldSum(FirmID,CommodityID, bs_flag,holdQty,holdFunds,FloatingLoss,evenprice,HoldMargin,HoldAssure)
          values('63300555',p_CommodityID, th.bs_flag,v_tradedAmount, th.price * v_tradedAmount * v_contractFactor,0,th.price,v_h_Margin_one,v_h_Assure_one/*v_Margin_one_ms,v_Assure_one_ms*/);
        end if;

        --客户调期转让后,做市商可用资金减去客户调期转让的盈亏金额   add by lyf 20160529
        v_F_FrozenFunds := FN_F_UpdateFundsFull('63300555','15004',v_closeFL_one,null,p_CommodityID,null,null);

        --增加做市商成交记录
        insert into otcertradelist(tradeno,otcer,commodityid,normalfirmid,tradeqty,price, bs_flag,holddays,tradetime)
        values(seq_t_otcertradelist.nextval,p_CommodityID,p_CommodityID, p_FirmID,p_Quantity, th.price,th.bs_flag,th.overdat,sysdate);
        insert into otcertradelist(tradeno,otcer,commodityid,normalfirmid,tradeqty,price,bs_flag,holddays, tradetime)
        values(seq_t_otcertradelist.nextval,p_CommodityID,p_CommodityID,p_FirmID,p_Quantity,p_Price,v_bs_flag,v_holddays,sysdate);
        v_Margin_ms := v_Margin_ms + v_Margin_one_ms;
        v_Assure_ms := v_Assure_ms + v_Assure_one_ms;
      end loop;
    end if;
    exit when v_unCloseQty = 0;
  end loop;
  close v_T_HoldPosition;
  if (v_unCloseQty > 0) then
    --成交数量大于持仓数量，出错
    rollback;
    return -3;
  end if;

  --减少交易客户，交易商的持仓合计信息2009-10-15
  v_num := FN_T_SubHoldSum(p_quantity, 0,v_Margin, v_Assure, p_CommodityID, p_contractFactor, v_tmp_bs_flag, p_FirmID, v_HoldFunds, p_CustomerID,  v_HoldFunds,  p_GageMode, p_quantity);

  --更新临时保证金和临时担保金
  update T_Firm set runtimemargin = runtimemargin - v_Margin, RuntimeAssure = RuntimeAssure - v_Assure where Firmid = p_FirmID;
  --更新冻结资金，释放个人部分的保证金
  v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID, - (v_Margin - v_Assure) + v_Fee - v_closeFL, '15');

  -- 更新做市商的资金
  --更新临时保证金和临时担保金
  /* update T_Firm
  set runtimemargin = runtimemargin - v_Margin_ms,
  RuntimeAssure = RuntimeAssure - v_Assure_ms
  where Firmid = '63300555';
  --更新冻结资金，释放个人部分的保证金
  v_F_FrozenFunds := FN_F_UpdateFrozenFunds('63300555',-(v_Margin_ms-v_Assure_ms)+v_Fee-v_closeFL,'15');*/ --add by lyf 20160108 做市商不扣保证金

  --增加做市商成交记录
  /* insert into otcertradelist
    (tradeno, otcer, normalfirmid, tradeqty, price, bs_flag, holddays, tradetime)
  values
    \*(seq_t_otcertradelist.nextval, 'otcer', p_FirmID, p_Quantity, p_Price, p_bs_flag, v_holddays, sysdate);*\
    (seq_t_otcertradelist.nextval, p_CommodityID, p_FirmID, p_Quantity, p_Price, p_bs_flag, v_holddays, sysdate);*/

  return 1;

end;
/

