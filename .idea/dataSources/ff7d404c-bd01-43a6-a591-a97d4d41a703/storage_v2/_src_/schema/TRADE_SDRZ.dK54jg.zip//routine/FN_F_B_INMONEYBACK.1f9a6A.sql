CREATE function FN_F_B_INMONEYBACK
(
  p_bankID varchar2,      --银行编号
  p_firmID varchar2,      --交易商代码
  p_amount number,        --发生额
  p_actionID number,      --资金流水号
  p_funID varchar2,       --银行流水号
  p_remark varchar2      --备注
) return number
/***
 * 入金回调
 * version 1.0.0.0 此方法公用
 *
 * 返回值：资金流水号
 ****/
is
  v_reNum number(10):=0;           -- 返回值 大于0 流水号   小于0 错误码
  v_count number(10);              -- 结果记录数
  v_actionID number(10);           -- 资金流水号
  v_dicIn varchar(8);            --入金摘要
  v_dicFee varchar(8);           --手续费摘要
  v_oprCode varchar(8);          --银行科目
  v_realfunds number(15,2);      --余额
begin
   begin
     select actionid into v_actionID from f_b_capitalinfo where type=0 and actionid=p_actionID ;
   exception when NO_DATA_FOUND then
     v_reNum := -1;  --流水不存在
     return v_reNum;
   end;
   begin
     select actionid into v_actionID from f_b_capitalinfo where funid=p_funID and bankid=p_bankID and type=0 and createdate=to_char(sysdate,'yyyy-MM-dd') ;
     if(v_actionID >1) then
       v_reNum := -2;  -- 银行流水已存在
       return v_reNum;
     end if;
   exception when NO_DATA_FOUND then
     v_reNum := -3;  --流水不存在
   end;
   select count(*) into v_count from f_b_capitalinfo where actionid=p_actionID and status=2;
   if(v_count>0) then
     for cap in (select id,type  from f_b_capitalinfo where actionid=p_actionID and status=2 for update)
     loop
       update f_b_capitalinfo set status=0,funid=p_funID,banktime=sysdate,funid2=p_funID where id=cap.id;
       select value into v_dicIN from f_b_dictionary where name = 'insummary';
       select value into v_oprCode from f_b_dictionary where type=1 and bankid=p_bankid;
       if(cap.type = 0) then
         v_realfunds := fn_f_updatefundsFull(p_firmID,v_dicIN,p_amount,v_actionid,v_oprCode,null,null);
       else
         select value into v_dicFee from f_b_dictionary where name = 'feesummary';
         v_realfunds := fn_f_updatefundsFull(p_firmID,v_dicFee,0,v_actionid,null,null,null);   --手续费计算暂时没实现记录为0
       end if;
     end loop;
   else
    v_reNum := -4; -- 流水已处理
    return v_reNum;
   end if;
  return p_actionID;
end;
/

