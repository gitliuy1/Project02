CREATE TYPE              "TYPE_BILL_STOCKID"                                          as object(
    Stockid  number(15),  --注册单号
    Quantity  number(15) --仓单数量
)
/

