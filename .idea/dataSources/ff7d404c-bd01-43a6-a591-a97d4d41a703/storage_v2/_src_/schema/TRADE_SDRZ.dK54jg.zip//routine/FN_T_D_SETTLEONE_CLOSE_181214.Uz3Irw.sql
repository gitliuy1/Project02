CREATE function FN_T_D_SettleOne_close_181214(  p_CommodityID varchar2, --商品代码
                                                    p_Price       number,   --交收价
                                                    p_BS_Flag     number,   --买卖标志
                                                    p_CustomerID  varchar2, --交易客户ID
                                                    p_HoldQty     number,   --交收持仓数量，即非抵顶数量
                                                    p_GageQty     number,   --交收抵顶数量，目前不支持抵顶交收
                                                    p_a_orderno   number,   --交收申报委托号
                                                    p_a_holdno    number    --持仓单号,非指定持仓 为null
                                                  ) return number
/****
   * 买卖单方向延期交收
   * 返回值 : 1=成功  ;
   * 修改 :所有交收申报 委托时均冻结对应持仓，从而使用冻结持仓进行交收;抵顶数可用于交收，优先使用持仓数(存在平仓回报失败风险) yuansr 2016 10 26
  ****/
 as
  v_version              varchar2(10) := '1.1.0.0';     ---交收申报委托冻结持仓明细，按冻结持仓进行交收
  v_ContractFactor       number(12, 2);                 ---商品合约因子
  v_FirmID               varchar2(32) ;                 ---交易商ID
  v_TradeDate            date;                          ---交易日
  v_NeutralFeeWay        number(2);
  v_GageMode             number(2);
  v_AddedTaxFactor       T_Commodity.AddedTaxFactor%type;--增值税率系数=AddedTax/(1+AddedTax)
  v_settlePriceType      number(2);                     ---价格类型
  --v_usedGageQty          number(10)   := 0;             ---占用抵顶数量

  v_Margin_one           number(15, 2) := 0;            ---一条记录的交易保证金
  v_Assure_one           number(15, 2) := 0;            ---一条记录的交易担保保证金
  v_SettleMargin_one     number(15, 2) := 0;            ---一条记录的交收保证金
  v_Payout_one           number(15, 2) := 0;            ---一条记录的货款
  v_Fee_one              number(15, 2) := 0;            ---一条记录的交收手续费
  v_closeFL_one          number(15, 2) := 0;            ---一条记录的交收盈亏
  v_CloseAddedTax_one    number(15, 2) := 0;            ---一条记录的交收盈亏增值税

  v_Margin               number(15, 2) := 0;            ---合计交易保证金
  v_Assure               number(15, 2) := 0;            ---合计交易担保保证金
  v_SettleMargin         number(15, 2) := 0;            ---合计交收保证金
  v_Payout               number(15, 2) := 0;            ---合计的货款
  v_Fee                  number(15, 2) := 0;            ---合计交收手续费
  v_closeFL              number(15, 2) := 0;            ---合计交收盈亏
  v_CloseAddedTax        number(15, 2) := 0;            ---合计交收盈亏增值税
               
  v_SettlePrice          number(15, 2);                 ---交收价
  v_FL_Price             number(15, 2);                 ---浮亏差价
  v_sh_ID                number(15);                    ---新建交收持仓单号
  v_unCloseQty           number(10)   := 0;             ---处理成交数量
  
  v_RuntimeMargin        number(15, 2);                 ---临时交易保证金
  v_F_FrozenFunds        number(15, 2);                 ---更新后冻结资金
  v_Balance              number(15, 2);
  v_ret                  number(4);                     ---返回值
  v_hold_tradeqty        number(10)   := 0;             ---持仓明细成交数量 yuansr 2016 11 24
  v_holdfunds            number(15, 2):= 0;             ---成交持仓金额合计 yuansr 2017 04 26
  v_frozengageqty        number(15) ;                   --单个交收数据（持仓）抵顶交收数量
  v_tradegageqty         number(15) ;                   --抵顶交收数量  


--- 新加变量 2018年12月10日liuyang
  v_M_TradeNo_Opp        number(15);                    --对方撮合成交号
  v_A_OrderNo            number(15);                    --委托单号
  v_A_TradeNo            number(15);                    --成交单号
  v_o_holdno             number(15);                    --成对的持仓单号
  v_o_firmid             number(15);                    --对手交易商                               
begin

  --1 、获取抵顶模式，保证金计算类型，增值税，合约因子
  select NeutralFeeWay, GageMode into  v_NeutralFeeWay, v_GageMode from T_A_Market;
  --根据交收申报类型来决定交收价格 add by  zhangjian 2011年12月13日11:04:51 start
  select Contractfactor, AddedTaxFactor，DelaySettlePriceType into v_ContractFactor, v_AddedTaxFactor，v_settlePriceType
    from T_Commodity where CommodityID = p_CommodityID;

  select TradeDate into v_TradeDate from T_SystemStatus;

  --根据平仓算法 不支持，下单时，已确定持仓
  /***************************--- 买 / 卖 单方向延期交收start ---********************************/
  v_Margin       := 0;
  v_Assure       := 0;
  v_SettleMargin := 0;
  v_Payout       := 0;
  v_Fee          := 0;
  v_closeFL      := 0;
  v_CloseAddedTax:= 0;
  v_unCloseQty   :=nvl(p_HoldQty,0)+nvl(p_GageQty,0);
  v_FirmID       :=null;
  v_frozengageqty:= 0 ;
  v_tradegageqty := 0 ;   
           
  for hold_S in ( select t1.a_holdno,t1.bs_flag,t1.frozenqty-t1.unfrozenqty+t1.frozengageqty-t1.unfrozengageqty as qty,t2.price
                         ,t2.holdqty,t2.gageqty,t2.holdtype,t2.holdmargin ,t2.holdassure  ,t2.overdat,t2.firmid,
                         t2.a_tradeholdno,t2.n_tradeno,t2.f_cleardate，t2.a_tradeno
                         ,t1.frozengageqty-t1.unfrozengageqty as frozengageqty
                    from t_s_orderfrozenhold t1,t_holdposition t2
                   where t2.overdat <=1 and t1.bs_flag=t2.bs_flag and t1.a_holdno=t2.a_holdno and t1.ordertype=0
                     and t1.frozenqty+t1.frozengageqty>t1.unfrozenqty+t1.unfrozengageqty 
                     and t1.BS_Flag = p_BS_Flag and t2.customerid=p_CustomerID and t1.a_orderno=p_a_Orderno
                     and (p_a_holdno is null or p_a_holdno=t1.a_holdno)
                     for update ---锁冻结表和持仓表
                )
  loop
      v_Margin_one       := 0;
      v_Assure_one       := 0;
      v_SettleMargin_one := 0;
      v_Payout_one       := 0;
      v_Fee_one          := 0;
      v_closeFL_one      := 0;
      v_CloseAddedTax_one:= 0;
      --v_usedGageQty      := 0;
      v_FirmID           :=hold_S.firmid;
      v_hold_tradeqty    := 0; ---此次交收数量（包含抵顶）
      v_frozengageqty    := hold_S.Frozengageqty;--此次交收抵顶数量 yuansr 2017 07 27
      
      if(hold_S.qty<=v_unCloseQty) then --未成交数大于等于 持仓冻结，持仓冻结全部用于成交
        v_hold_tradeqty:=hold_S.qty;
      else ----未成交数小于 持仓冻结，持仓冻结部分用于成交,未成交数 作为此次持仓成交数
        v_hold_tradeqty:=v_unCloseQty;
      end if;
      
      if(v_hold_tradeqty<hold_S.Frozengageqty) then
          v_frozengageqty:=v_hold_tradeqty;
      end if;
      
      /*if (v_hold_tradeqty>hold_S.holdqty) then--成交数大于持仓，使用抵顶补充，计算使用的抵顶数
        v_usedGageQty:=v_hold_tradeqty-hold_S.holdqty;
      end if;*/
      
      --v_usedGageQty:=nvl(hold_S.Gageqty,0)-v_frozengageqty;--抵顶数量 yuansr 2017 07 27
      
      if (v_hold_tradeqty-v_frozengageqty<hold_S.holdqty) then--成交数小于持仓，按成交数 计算保证金
        v_Margin_one   := hold_S.holdmargin * (v_hold_tradeqty-v_frozengageqty) / hold_S.holdqty;
        v_Assure_one   := hold_S.holdassure * (v_hold_tradeqty-v_frozengageqty) / hold_S.holdqty;
      elsif(v_hold_tradeqty<=hold_S.holdqty+hold_S.gageqty) then --成交数大于等于持仓,小于持仓加抵顶,释放所有保证金
        v_Margin_one   := hold_S.holdmargin ;
        v_Assure_one   := hold_S.holdassure ;
      else--冻结数大于于 持仓+抵顶 异常
        Raise_application_error(-20041, v_hold_tradeqty||'>'||hold_S.holdqty ||'+'||hold_S.gageqty||' error');
      end if;

      --计算交收保证金
      if (v_settlePriceType = 0) then   --按委托申报价交收
         v_SettlePrice := p_Price;
      else                              --按订立价交收
         v_SettlePrice := hold_S.price;
      end if;
    
      --交收保证金 不计抵顶部分
      v_SettleMargin_one := FN_T_ComputeSettleMargin(hold_S.firmid,p_CommodityID,p_BS_Flag,v_hold_tradeqty-v_frozengageqty
                                                     ,v_SettlePrice);
      if (v_SettleMargin_one < 0) then
        Raise_application_error(-20042, 'ComputeSettleMargin error');
      end if;
 
      --货款
      if (p_BS_Flag = 1) then
        v_Payout_one := FN_T_ComputePayout(hold_S.firmid, p_CommodityID,p_BS_Flag, v_hold_tradeqty,v_SettlePrice);
        if (v_Payout_one < 0) then
          Raise_application_error(-20043, 'computePayout error');
        end if;
      end if;
      --手续费
      if (hold_S.HoldType = 2 and v_NeutralFeeWay = 0) then
        v_Fee_one := 0;
      else
        v_Fee_one := FN_T_ComputeSettleFee(hold_S.Firmid,p_CommodityID,  p_BS_Flag,v_hold_tradeqty , v_SettlePrice);
      end if;
      if (v_Fee_one < 0) then
        Raise_application_error(-20044, 'computeSettleFee error');
      end if;
      --浮亏
      if (p_BS_Flag = 1) then     --买浮亏差价=交收价-订立价 2016 12 01 yuansr
         v_FL_Price :=v_SettlePrice-hold_S.price ;
      else                        --卖浮亏差价=订立价-交收价
         v_FL_Price := hold_S.price-v_SettlePrice  ;
      end if;
     
      v_closeFL_one := v_hold_tradeqty * v_FL_Price * v_contractFactor;    --税前盈亏              
      v_CloseAddedTax_one := round(v_closeFL_one * v_AddedTaxFactor, 2);--计算交收增值税,v_AddedTaxFactor增值税系数=AddedTax/(1+AddedTax)
      v_closeFL_one := v_closeFL_one - v_CloseAddedTax_one;             --税后盈亏
      
      v_holdfunds    := v_holdfunds+v_hold_tradeqty * hold_S.price * v_contractFactor;--成交持仓金额合计 yuansr 2017 04 26
      v_Margin       := v_Margin+v_Margin_one;
      v_Assure       := v_Assure+v_Assure_one;
      v_SettleMargin := v_SettleMargin+v_SettleMargin_one;
      v_Payout       := v_Payout+v_Payout_one;
      v_Fee          := v_Fee+v_Fee_one;
      v_closeFL      := v_closeFL+v_closeFL_one;
      v_CloseAddedTax:= v_CloseAddedTax+v_CloseAddedTax_one;
      --将当前持仓记录和交收费用插入交收持仓明细表，并更新持仓数量和抵顶数量为实际交收的数量
      select SEQ_T_SettleHoldPosition.nextval into v_sh_ID from dual;
      --按字段名插入交收持仓明细表
      insert into t_settleholdposition ( id,  settleprocessdate,  a_holdno,  a_tradeno,  customerid,  commodityid,  bs_flag,  price
                                         ,holdqty ,  openqty,     holdtime,  holdmargin,  firmid,  gageqty,  holdassure
                                         ,floatingloss ,settlemargin , payout  ,settlefee,  settle_pl,  settleaddedtax,  settleprice
                                         ,settletype   ,holdtype,         atcleardate,     a_orderno )
      select v_sh_ID, v_TradeDate, a_holdno, a_tradeno, customerid, commodityid, bs_flag, price
             , v_hold_tradeqty-v_frozengageqty, openqty, holdtime, v_Margin_one, firmid, v_frozengageqty, v_Assure_one
             , floatingloss, v_SettleMargin_one, v_Payout_one, v_Fee_one, v_closeFL_one, v_CloseAddedTax_one, v_SettlePrice
             , 1 , holdtype, atcleardate,0
        from t_holdposition               where A_HoldNo = hold_S.a_Holdno;

      --update T_SettleHoldPosition  set HoldQty = v_hold_tradeqty-v_frozengageqty ,gageqty=gageqty-v_frozengageqty where ID = v_sh_ID;
      /*dbms_output.put_line('v_tradedAmount  1   --  >>  '||v_tradedAmount);*/
      --更新持仓记录
      update T_holdposition
         set holdqty = holdqty - v_hold_tradeqty+v_frozengageqty ,GageQty = GageQty - v_frozengageqty 
             ,HoldAssure = HoldAssure - v_Assure_one       ,HoldMargin = HoldMargin - v_Margin_one
       where a_holdno = hold_S.a_Holdno;
       
        ------------------------------------------------添加交易转交收记录委托和成交信息 2018年12月10日 liuyang start---------------------------------------------------------
      --获取成对持仓数据
      select t.a_holdno,t.firmid
      into v_o_holdno,v_o_firmid
      from t_holdposition t
      where t.f_cleardate=hold_S.f_Cleardate  and t.n_tradeno=hold_S.n_tradeno 
      and t.a_tradeholdno=hold_S.a_tradeholdno and t.holdqty != 0 and t.a_holdno != hold_S.a_Holdno;
      
      --获取撮合成交号
       SELECT max(t.m_tradeno) into v_M_TradeNo_Opp FROM t_trade t;
       v_M_TradeNo_Opp := v_M_TradeNo_Opp+1;
      --调用计算函数修改委托单号 
      select FN_T_ComputeOrderNo(SEQ_T_Orders.nextval) into v_A_OrderNo from dual;
      insert into T_Orders
        (       a_orderno,  a_orderno_w,   CommodityID,   Firmid,    traderid,   bs_flag,   ordertype, status, quantity, price, closemode, specprice,       timeflag,tradeqty, frozenfunds, unfrozenfunds, ordertime, withdrawtime, ordererip, signature,closeFlag,   CustomerID,         ConsignerID,specialOrderFlag)
        select v_A_OrderNo ,null,          commodityid,   Firmid,    null,      Bs_Flag,     2,          1,   holdqty,  price,   null,        null,          null,     0,        0,              0,         sysdate,      null,       null,     null,    null,       Firmid||'00', null,         0
      from t_holdposition t where t.a_holdno=hold_S.a_Holdno;
      
      --- 添加原持仓成交
      --成交单号,在计算调期费用后在生成
      select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_A_TradeNo from dual;
      insert into T_Trade (a_tradeno,   m_tradeno,  a_orderno,    a_tradeno_closed,tradetime,   Firmid,   CommodityID,  bs_flag, ordertype,  price,    quantity, close_pl, tradefee,   TradeType,HoldPrice, HoldTime,  CustomerID,         CloseAddedTax,       M_TradeNo_Opp,      AtClearDate,   TradeAtClearDate,  oppFirmid,      swapfee)
      select              v_A_TradeNo,v_M_TradeNo_Opp, v_A_OrderNo,hold_S.a_tradeno,sysdate,     Firmid,   commodityid,  Bs_Flag,   2,          price,      holdqty,  0,         0,           1,        price,   HoldTime,  Firmid||'00',        0,                v_M_TradeNo_Opp,      AtClearDate,    AtClearDate,v_o_firmid,       0
      from t_holdposition t where t.a_holdno=hold_S.a_Holdno; 
      
      --调用计算函数修改委托单号 
      select FN_T_ComputeOrderNo(SEQ_T_Orders.nextval) into v_A_OrderNo from dual;
      -- 插入成对的委托数据
      insert into T_Orders
        (       a_orderno,  a_orderno_w,   CommodityID,   Firmid,    traderid,   bs_flag,   ordertype, status, quantity, price, closemode, specprice,       timeflag,tradeqty, frozenfunds, unfrozenfunds, ordertime, withdrawtime, ordererip, signature,closeFlag,   CustomerID,         ConsignerID,specialOrderFlag)
        select v_A_OrderNo ,null,          commodityid,   Firmid,    null,      Bs_Flag,     2,          1,   holdqty,  price,   null,        null,          null,     0,        0,              0,         sysdate,      null,       null,     null,    null,       Firmid||'00', null,         0
      from t_holdposition t where t.a_holdno=v_o_holdno;
      
      select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_A_TradeNo from dual;
      ---插入成对的成交数据
      insert into T_Trade (a_tradeno,   m_tradeno,  a_orderno,    a_tradeno_closed,tradetime,   Firmid,   CommodityID,  bs_flag, ordertype,  price,    quantity, close_pl, tradefee,   TradeType,HoldPrice, HoldTime,  CustomerID,         CloseAddedTax,       M_TradeNo_Opp,      AtClearDate,   TradeAtClearDate,  oppFirmid,      swapfee)
                 select  v_A_TradeNo,v_M_TradeNo_Opp, v_A_OrderNo,hold_S.a_tradeno,sysdate,     Firmid,   commodityid,  Bs_Flag,   2,          price,      holdqty,  0,         0,           1,        price,   HoldTime,  Firmid||'00',        0,                v_M_TradeNo_Opp,      AtClearDate,    AtClearDate,      hold_S.Firmid,       0
      from t_holdposition t where t.a_holdno=v_o_holdno;  
      
      ------------------------------------------------添加交易转交收记录委托和成交信息 2018年12月10日 liuyang end --------------------------------------------------------- 
       
       
      v_unCloseQty     := v_unCloseQty - v_hold_tradeqty;
      v_tradegageqty   := v_tradegageqty+v_frozengageqty;
      if v_hold_tradeqty=hold_S.qty then ---冻结持仓全部成交，删除冻结记录
        delete from T_S_OrderFrozenHold  where ordertype=0 and a_orderno=p_a_orderno and a_holdno=hold_S.a_holdno ;--完成交收的冻结记录 直接删除
      else ---冻结持仓部分成交，更新冻结记录，解冻成交数量
        update T_S_OrderFrozenHold t set t.unfrozenqty=t.unfrozenqty+v_hold_tradeqty - v_frozengageqty  
               ,t.unfrozengageqty=t.unfrozengageqty+v_frozengageqty
         where ordertype=0 and a_orderno=p_a_orderno and a_holdno=hold_S.a_holdno;
      end if;
      exit when v_unCloseQty = 0;
  end loop;

  if(v_unCloseQty<>0)then
      Raise_application_error(-20045, 't_s_orderfrozenhold frozen error');
  elsif v_FirmID is null then --委托为0直接返回
       return 1;
  end if;       

 /***************************--- 买 / 卖 单方向延期交收 end ---********************************/ 

  --更新交易客户持仓合计
  --v_ret := FN_T_D_ChgCustHoldByQty(p_CustomerID,  p_CommodityID,  p_BS_Flag,   p_HoldQty+p_GageQty);
  --使用合计值直接更新交易客户持仓合计和交易商持仓合计信息 yuansr 2017 04 26
  v_ret := FN_T_D_ChgCustFirmHoldBySum( p_CustomerID ,v_FirmID ,p_CommodityID ,v_ContractFactor ,p_BS_Flag ,nvl(p_HoldQty,0)-v_tradegageqty
                                        ,v_tradegageqty ,v_holdfunds ,v_Margin ,  v_Assure , v_GageMode );
  --释放交易保证金
  --v_RuntimeMargin := FN_T_D_ChgFirmMarginByQty(v_FirmID, p_CommodityID,  p_BS_Flag,   p_HoldQty+p_GageQty);
  update T_Firm 
     set runtimemargin = runtimemargin - v_Margin,RuntimeAssure = RuntimeAssure - v_Assure
   where Firmid = v_FirmID;
  v_RuntimeMargin := v_Margin-v_Assure; ----开仓中保证金包已含担保金 yuansr 2017 11 28

  v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_FirmID, -v_RuntimeMargin,'15');
  --更新交易商持仓合计
  --v_ret := FN_T_D_ChgFirmHoldByQty(v_FirmID ,p_CommodityID, p_BS_Flag, p_HoldQty, v_GageMode);
  --扣除交收货款，交收手续费，付交收盈利或收交收亏损,交收保证金 ，并写流水
  v_Balance := FN_F_UpdateFundsFull( v_FirmID,  '15008', v_Payout, null, p_CommodityID, null, null );
  --注意这里不能按最低交收手续费收取，因为实时撮合，实时更新明细持仓，所以按实际手续费收取
  v_Balance := FN_F_UpdateFundsFull(v_FirmID,  '15010', v_Fee, null,  p_CommodityID, null, null);
  if (v_CloseFL >= 0) then
    v_Balance := FN_F_UpdateFundsFull(v_FirmID, '15011', v_CloseFL, null, p_CommodityID, v_CloseAddedTax, null);
  else
    v_Balance := FN_F_UpdateFundsFull(v_FirmID, '15012', -v_CloseFL, null,p_CommodityID,-v_CloseAddedTax, null);
  end if;
  update T_Firm
     set RuntimeSettleMargin = RuntimeSettleMargin + v_SettleMargin
   where FirmID = v_FirmID;
  v_Balance := FN_F_UpdateFundsFull(v_FirmID,  '15013',  v_SettleMargin,  null, p_CommodityID,  null,  null );
  return 1;

end;
/

