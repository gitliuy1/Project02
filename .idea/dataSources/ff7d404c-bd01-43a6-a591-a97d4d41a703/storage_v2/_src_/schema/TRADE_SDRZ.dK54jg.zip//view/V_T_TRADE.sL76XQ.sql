CREATE VIEW V_T_TRADE AS
  select Q.A_TRADENO,
       Q.A_ORDERNO,
       Q.TRADETIME,
       Q.CUSTOMERID,
       Q.COMMODITYID,
       Q.BS_FLAG,
       case
         when Q.ORDERTYPE = 1 then
          '订立'
         else
          case
            when Q.timeflag = 1 then
             '转让'
            when Q.timeflag = 2 then
             '调期转让'
            else
             '转让'
          end
       end ORDERTYPE,
       Q.PRICE,
       Q.QUANTITY,
       Q.CLOSE_PL,
       Q.TRADEFEE,
       Q.SWAPFEE,
       Q.TRADETYPE,
       Q.HOLDPRICE,
       Q.HOLDTIME,
       Q.FIRMID,
       Q.CLOSEADDEDTAX,
       Q.FIRMNAME,
       Q.OPPCUSTOMERID,
       Q.TIMEFLAG,
       Q.OPPCUSTOMERNAME
  from (select a.*, m.name FirmName, a.oppFirmId oppCustomerID, o.timeflag ,P.name OPPCUSTOMERNAME
          from T_Trade a, M_firm m, t_orders o ,M_firm P
         where m.firmID = a.firmID and a.oppfirmid=p.firmid
           and a.a_orderno = o.a_orderno
         order by a.firmID, a.a_orderno) Q
/

