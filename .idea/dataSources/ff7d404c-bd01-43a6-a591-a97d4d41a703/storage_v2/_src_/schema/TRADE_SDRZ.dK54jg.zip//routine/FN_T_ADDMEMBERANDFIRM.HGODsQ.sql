CREATE function fn_t_addMemberAndFirm
(    p_FirmID     varchar2,   --交易商ID
     p_MemberID   varchar2    --会员ID
) return number
as
     v_num number(15);   --返回码
     v_errorcode number;
     v_errormsg  varchar2(200);
begin

insert into i_memberandfirm from i_memberandfirm@dblink_trade_api;
update i_memberandfirm im set im.memberid = p_MemberID ;

commit;
    return 1;
exception
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    return -100;
end;
/

