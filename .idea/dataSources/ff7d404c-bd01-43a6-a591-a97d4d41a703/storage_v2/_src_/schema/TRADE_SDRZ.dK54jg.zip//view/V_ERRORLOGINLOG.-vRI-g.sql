CREATE VIEW V_ERRORLOGINLOG AS
  select trader.traderid as "TRADERID",trader.userid as "USERID",logs.counts as "COUNTS",logs.loginDate as "LOGINDATE" from (select traderid,count(*) counts,trunc(loginDate) loginDate from m_errorloginlog group by traderid,trunc(loginDate)) logs,m_trader trader where trader.traderid = logs.traderid
/

