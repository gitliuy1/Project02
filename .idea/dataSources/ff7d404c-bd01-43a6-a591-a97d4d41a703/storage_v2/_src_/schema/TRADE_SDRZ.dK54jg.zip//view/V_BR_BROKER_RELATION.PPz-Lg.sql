CREATE VIEW V_BR_BROKER_RELATION AS
  select b.brokercount,nvl(c.signbrokercount, 0) signbrokercount,a.brokerid,a.password,a.name,a.telephone,a.mobile,a.email
       ,a.address,a.note,a.firmid,a.areaid,a.membertype,a.timelimit,a.marketmanager,trunc(a.modifytime) modifydate ,a.modifytime
       ,a.brokerlevel,a.steplistid,a.parentid,a.setaltermanid,a.takeeffectdate,a.cleardate
  from (  (select t.brokerid,t.password,t.name,t.telephone,t.mobile,t.email,
                  t.address,t.note,t.firmid,t.areaid,t.membertype,t.timelimit,
                  t.marketmanager,t.modifytime,br.brokerlevel,br.steplistid,br.parentid,
                  br.setaltermanid,br.takeeffectdate,br.cleardate
             from br_broker t join br_broker_relation br on br.brokerid = t.brokerid
           ) a inner join
           (select brokerid,count(firmid) brokercount
              from ( select t.firmid,t.brokerid from br_firmandbroker t )a
             group by brokerid
           )b on  a.brokerid=b.brokerid left join
           (select se.brokerid,count(fb.firmid) signbrokercount
              from f_b_firmidandaccount fb,(select t.firmid,t.brokerid from br_firmandbroker t) se
             where se.firmid=fb.firmid  and fb.isopen=1
             group by se.brokerid
           )c  on a.brokerid=c.brokerid
        )
/

