CREATE function FN_T_test1 return number

as
    v_version varchar2(10):='1.0.2.1';
    v_A_TradeNo varchar2(16);
    v_count number(5);

begin
    for v_inedx in 1..1000 loop
        select FN_T_ComputeTradeNo(SEQ_T_Trade.nextval) into v_A_TradeNo from dual;
        insert into test (a_tradeno,tradetime) values(v_A_TradeNo,sysdate);
        insert into test2 (a_tradeno,tradetime) values(v_A_TradeNo,systimestamp);
        commit;
    end loop;
    return -100;
end;
/

