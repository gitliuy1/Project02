CREATE function FN_T_UpdateTradeByArgs(
    v_CommodityID varchar2,
  v_contractFactor T_Commodity.contractfactor%type,
  v_MarginPriceType         number,     --计算成交保证金结算价类型 0:实时和闭市时都按开仓价；1:实时按昨结算价，闭市按当日结算价
    v_AddedTaxFactor T_Commodity.AddedTaxFactor%type,--增值税率系数=AddedTax/(1+AddedTax)
    v_YesterBalancePrice    number,
    v_GageMode number,--抵顶模式，分0全抵顶和1半抵顶，半抵顶时要计算浮亏
    v_CloseAlgr        number,    --平仓算法(0先开先平；1后开先平；2持仓均价平仓)
    v_TradeDate date,
    v_Quantity  number,  --成交数量
    v_Price          number,--成交价格

    v_OrderNo  number,
    v_FirmID     varchar2,
    v_TraderID       varchar2,
    v_bs_flag        number,
    v_status         number,
    v_orderQty       number,
    v_orderPrice          number,
    v_orderTradeQty       number,
    v_frozenfunds    number,
    v_unfrozenfunds  number,
  v_CustomerID        varchar2,
  v_OrderType      number,
    v_closeMode      number,
    v_specPrice      number,
    v_timeFlag       number,
    v_CloseFlag      number,
    v_BillTradeType number,   --仓单交易类型 0：正常默认；  1：卖仓单；    3：抵顶转让

    v_marginAlgr_m         number,
    v_marginRate_b_m         number,
    v_marginRate_s_m         number,
    v_marginAssure_b_m         number,
    v_marginAssure_s_m         number,
    v_feeAlgr_m       number,
    v_feeRate_b_m         number,
    v_feeRate_s_m         number,
    v_TodayCloseFeeRate_B_m         number,
    v_TodayCloseFeeRate_S_m         number,
    v_HistoryCloseFeeRate_B_m         number,
    v_HistoryCloseFeeRate_S_m         number,
    v_ForceCloseFeeAlgr_m       number,
    v_ForceCloseFeeRate_B_m         number,
    v_ForceCloseFeeRate_S_m         number,
    v_M_TradeNo_m  number,  --撮合成交号


    v_OrderNo_o  number,  --另一方委托单号
  v_FirmID_o     varchar2,
  v_TraderID_o       varchar2,
    v_bs_flag_o        number,
    v_status_o         number,
    v_orderQty_o       number,
    v_orderPrice_o          number,
    v_orderTradeQty_o       number,
    v_frozenfunds_o    number,
    v_unfrozenfunds_o  number,
  v_CustomerID_o        varchar2,
  v_OrderType_o      number,
    v_closeMode_o      number,
    v_specPrice_o      number,
    v_timeFlag_o       number,
    v_CloseFlag_o      number,
    v_BillTradeType_o number,   --仓单交易类型 0：正常默认；  1：卖仓单；    3：抵顶转让

    v_marginAlgr_o         number,
    v_marginRate_b_o         number,
    v_marginRate_s_o         number,
    v_marginAssure_b_o         number,
    v_marginAssure_s_o         number,
    v_feeAlgr_o       number,
    v_feeRate_b_o         number,
    v_feeRate_s_o         number,
    v_TodayCloseFeeRate_B_o         number,
    v_TodayCloseFeeRate_S_o         number,
    v_HistoryCloseFeeRate_B_o         number,
    v_HistoryCloseFeeRate_S_o         number,
    v_ForceCloseFeeAlgr_o       number,
    v_ForceCloseFeeRate_B_o         number,
    v_ForceCloseFeeRate_S_o         number,
    v_M_TradeNo_o  number  --另一方撮合成交号
) return number
/****
 * 根据参数更新双方成交处理
 * 返回值
 * 1 成功
 * -1 成交数量大于未成交数量
 * -2 成交数量大于冻结数量
 * -3 平仓成交数量大于持仓数量
 * -100 其它错误
****/
as
    v_ret            number(4);
begin
    if(v_OrderType = 1) then --开仓
        if(v_BillTradeType=1) then --卖仓单
             v_ret := FN_T_SellBillTrade(v_OrderNo,v_M_TradeNo_m,v_Price,v_Quantity,v_M_TradeNo_o,v_CommodityID,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderPrice,v_orderTradeQty,v_frozenfunds,v_unfrozenfunds,v_CustomerID,v_OrderType,v_contractFactor,v_MarginPriceType,v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_YesterBalancePrice,v_GageMode,v_TradeDate,v_FirmID_o);
        else
             v_ret := FN_T_OpenTrade(v_OrderNo,v_M_TradeNo_m,v_Price,v_Quantity,v_M_TradeNo_o,v_CommodityID,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderPrice,v_orderTradeQty,v_frozenfunds,v_unfrozenfunds,v_CustomerID,v_OrderType,v_contractFactor,v_MarginPriceType,v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_YesterBalancePrice,v_GageMode,v_TradeDate,v_FirmID_o);
        end if;
    elsif(v_OrderType = 2) then  --平仓
        if(v_BillTradeType=2) then --抵顶转让
             v_ret := FN_T_GageCloseTrade(v_OrderNo,v_M_TradeNo_m,v_Price,v_Quantity,v_M_TradeNo_o,v_CommodityID,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderTradeQty,v_CustomerID,v_OrderType,v_closeMode,v_specPrice,v_timeFlag,v_CloseFlag,v_contractFactor,v_MarginPriceType,v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m,v_YesterBalancePrice,v_AddedTaxFactor,v_GageMode,v_CloseAlgr,v_TradeDate,v_FirmID_o);
        else
             v_ret := FN_T_CloseTrade(v_OrderNo,v_M_TradeNo_m,v_Price,v_Quantity,v_M_TradeNo_o,v_CommodityID,v_FirmID,v_TraderID,v_bs_flag,v_status,v_orderQty,v_orderTradeQty,v_CustomerID,v_OrderType,v_closeMode,v_specPrice,v_timeFlag,v_CloseFlag,v_contractFactor,v_MarginPriceType,v_marginAlgr_m,v_marginRate_b_m,v_marginRate_s_m,v_marginAssure_b_m,v_marginAssure_s_m,v_feeAlgr_m,v_feeRate_b_m,v_feeRate_s_m,v_TodayCloseFeeRate_B_m,v_TodayCloseFeeRate_S_m,v_HistoryCloseFeeRate_B_m,v_HistoryCloseFeeRate_S_m,v_ForceCloseFeeAlgr_m,v_ForceCloseFeeRate_B_m,v_ForceCloseFeeRate_S_m,v_YesterBalancePrice,v_AddedTaxFactor,v_GageMode,v_CloseAlgr,v_TradeDate,v_FirmID_o);
        end if;
    end if;
  --成功后更新另一方成交
  if(v_ret = 1) then
      if(v_OrderType_o = 1) then --开仓
           if(v_BillTradeType_o=1) then --卖仓单
               v_ret := FN_T_SellBillTrade(v_OrderNo_o,v_M_TradeNo_o,v_Price,v_Quantity,v_M_TradeNo_m,v_CommodityID,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderPrice_o,v_orderTradeQty_o,v_frozenfunds_o,v_unfrozenfunds_o,v_CustomerID_o,v_OrderType_o,v_contractFactor,v_MarginPriceType,v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_YesterBalancePrice,v_GageMode,v_TradeDate,v_FirmID);
           else
               v_ret := FN_T_OpenTrade(v_OrderNo_o,v_M_TradeNo_o,v_Price,v_Quantity,v_M_TradeNo_m,v_CommodityID,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderPrice_o,v_orderTradeQty_o,v_frozenfunds_o,v_unfrozenfunds_o,v_CustomerID_o,v_OrderType_o,v_contractFactor,v_MarginPriceType,v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_YesterBalancePrice,v_GageMode,v_TradeDate,v_FirmID);
           end if;
    elsif(v_OrderType_o = 2) then  --平仓
       if(v_BillTradeType_o=2) then --抵顶转让
         v_ret := FN_T_GageCloseTrade(v_OrderNo_o,v_M_TradeNo_o,v_Price,v_Quantity,v_M_TradeNo_m,v_CommodityID,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderTradeQty_o,v_CustomerID_o,v_OrderType_o,v_closeMode_o,v_specPrice_o,v_timeFlag_o,v_CloseFlag_o,v_contractFactor,v_MarginPriceType,v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o,v_YesterBalancePrice,v_AddedTaxFactor,v_GageMode,v_CloseAlgr,v_TradeDate,v_FirmID);
       else
         v_ret := FN_T_CloseTrade(v_OrderNo_o,v_M_TradeNo_o,v_Price,v_Quantity,v_M_TradeNo_m,v_CommodityID,v_FirmID_o,v_TraderID_o,v_bs_flag_o,v_status_o,v_orderQty_o,v_orderTradeQty_o,v_CustomerID_o,v_OrderType_o,v_closeMode_o,v_specPrice_o,v_timeFlag_o,v_CloseFlag_o,v_contractFactor,v_MarginPriceType,v_marginAlgr_o,v_marginRate_b_o,v_marginRate_s_o,v_marginAssure_b_o,v_marginAssure_s_o,v_feeAlgr_o,v_feeRate_b_o,v_feeRate_s_o,v_TodayCloseFeeRate_B_o,v_TodayCloseFeeRate_S_o,v_HistoryCloseFeeRate_B_o,v_HistoryCloseFeeRate_S_o,v_ForceCloseFeeAlgr_o,v_ForceCloseFeeRate_B_o,v_ForceCloseFeeRate_S_o,v_YesterBalancePrice,v_AddedTaxFactor,v_GageMode,v_CloseAlgr,v_TradeDate,v_FirmID);
       end if;
    end if;
  end if;
  return v_ret;
end;
/

