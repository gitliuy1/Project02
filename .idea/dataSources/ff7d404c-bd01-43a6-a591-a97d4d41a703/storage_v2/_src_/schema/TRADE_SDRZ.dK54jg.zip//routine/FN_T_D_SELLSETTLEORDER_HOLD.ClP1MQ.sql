CREATE function FN_T_D_SellSettleOrder_hold(  p_FirmID           varchar2, --交易商ID
                                                         p_TraderID         varchar2, --交易员ID
                                                         p_CommodityID      varchar2, --商品ID
                                                         p_Quantity         number,   --数量
                                                         p_Price            number,   --委托价格，行情结算价
                                                         p_CustomerID       varchar2, --交易客户ID
                                                         p_ConsignerID      varchar2, --代为委托员ID
                                                         p_DelayQuoShowType number,   --延期行情显示类型，0：交收申报结束和中立仓申报结束显示； 
                                                                                      ---1：实时显示；
                                                         p_DelayNeedBill    number,   --延期交收是否需要仓单，0：不需要； 1：需要；
                                                         p_delayMoney       number,   --申报金额
                                                         p_a_holdno         number,   --add by lyf 20160801 指定持仓单号
                                                         p_aholdFlag        number,    --add by lyf 20160801 是否指定持仓单号交收     ‘1’否  ， ‘2’是
                                                         p_txFirmId         varchar2   --特许服务商ID
                                                         ,p_preStockids     varchar2   --意向仓单 yuansr 2017 07 07
                                                       ) return number
/****
   * add by lyf 20160801
   * 卖交收申报委托
   * 根据配置修改申报数量判断，用净订货量还是单边总持仓判断 by chenxc 2011-09-20
   * 返回值
   * >0  成功提交，并返回委托单号
   * -2  资金余额不足
   * -31  持仓不足
   * -32  仓单数量不足
   * -33  意向仓单不可用
   * -99  不存在相关数据
   * -100 其它错误
   *  修改： 委托完成后，冻结持仓合计后，持仓明细可用数量为持仓数量减去冻结数量(平仓委托冻结和申报委托冻结) 
   *        参照交易平仓 冻结持仓明细（直接更新持仓明细——会影响均价计算），抵顶数量，可用于交收申报  yuansr 2016 10 20
  ****/
 as
  v_version                 varchar2(10) := '1.0.2.3';
  v_HoldSum                 number(10) := 0;               --卖方持仓合计数量
  v_SettleMargin_SSum       number(15, 2) := 0;            --卖方交收保证金汇总
  v_TradeMargin_S           number(15, 2);                 --卖方交易保证金
  v_TradeMargin_SSum        number(15, 2) := 0;            --卖方交易保证金汇总
  v_F_Funds                 number(15, 2) := 0;            --应冻结资金
  v_A_Funds                 number(15, 2);                 --可用资金
  v_F_FrozenFunds           number(15, 2);                 --财务冻结资金
  v_ret                     number(4);
  v_A_OrderNo               number(15);                    --委托单号
  v_errorcode               number;
  v_errormsg                varchar2(200);
  v_DelaySettlePriceType    number(10);                    --交收申报交收类型 0：按结算价交收申报 ， 1：按订立价交收  -- add  by zhangjian
  v_price                   number(15, 6);                 -- 交收申报价格
  v_tempQty                 number(15) := 0;               --中间变量
  v_orderSumLogNo           number(15) := 0;               --委托下单日志合计数据 ID；
  v_breedid                 varchar2(12);
  v_billQty                 number(12):=0;
  v_A_OrderNo_L             number(15);                     --临时委托单号
  v_holdEvenPrice           number(15,6);                   --持仓均价,订立均价
  v_Overdat                 number(10);                     -- 到期天数
  v_contractfactor          number(12,2);                   --合约因子 用于计算仓单手数 yuansr 2017 06 30
  type c_item is ref cursor;                                --增加意向仓单处理 yuansr 2017 07 07
  v_item             	      c_item;
  v_result                  number(2);
  v_stockId                 bi_stock.stockid%type;
  v_stockids                T_DelayOrders.Stockids%type :='';
  v_sql                     varchar2(1000);
  v_gageqty                 number(15) ;                --抵顶数量
  v_frozengageqty           number(15) ;                --抵顶交收数量
  v_purposeGageQty          number(15);                 --意向仓单抵顶数量
  v_purposebillQty          number(15) ;                --意向仓单数量
begin
  --1、检查持仓并冻结持仓
  begin
     select nvl(a.gageqty+a.HoldQty-nvl(b.FrozenQty,0)-nvl(c.FrozenQty,0) , 0) ,price,overdat,nvl(a.gageqty,0)-nvl(c.frozengageqty,0)   
       into v_HoldSum,v_price,v_Overdat ,v_gageqty
      from t_holdposition a
           ,(select A_HoldNo,sum(frozenqty) frozenqty from T_SpecFrozenHold where a_holdno = p_a_holdno group by A_HoldNo) b 
           ,(select A_HoldNo,sum(frozenqty - unfrozenqty + frozengageqty - unfrozengageqty ) FrozenQty 
                    ,sum(frozengageqty - unfrozengageqty) frozengageqty  
               from T_S_OrderFrozenHold where bs_flag = 2 and a_holdno = p_a_holdno  group by A_HoldNo
           ) c---有效冻结=冻结-解冻
     where a.A_HoldNo=b.A_HoldNo(+) and a.A_HoldNo=c.A_HoldNo(+)
       and a.CustomerID = p_CustomerID and a.CommodityID = p_CommodityID and a.bs_flag = 2 and a.a_holdno = p_a_holdno
       for update of a.a_holdno;
  exception
    when NO_DATA_FOUND then
      rollback;
      return - 31; --持仓不足
  end;
  if (v_HoldSum < p_Quantity) then
      rollback;
      return - 31; --持仓不足
  end if;
  
  ---抵顶持仓优先用于交收，计算用于交收的抵顶数量 yuansr 2017 07 27
  v_frozengageqty:=0;
  if(v_gageqty>p_Quantity) then
  	 v_frozengageqty:=p_Quantity;
  else
     v_frozengageqty:=v_gageqty;
  end if;

  --创建临时委托代号
  select SEQ_T_S_OrderFrozenHold.nextval into v_A_OrderNo_L from dual;
  --2 、添加冻结持仓记录，计算交易保证金、货款、交收保证金 add by yuansr 2016 10 20
  insert into T_S_OrderFrozenHold( a_orderno  ,a_holdno   ,bs_flag   ,qty   ,frozenqty     ,unfrozenqty ,Frozengageqty )
  values ( v_A_OrderNo_L  ,p_a_holdno    ,2   ,p_Quantity-v_frozengageqty   ,p_Quantity-v_frozengageqty   ,0 ,v_frozengageqty    );
  v_holdEvenPrice:=v_price;--指定持仓，持仓价即冻结持仓的均价
  v_price:= p_delayMoney;-- modify by lyf 20160810 修改申报时候冻结保证金用申报金额来计算
  --计算交收保证金 modify by lyf 20160810 修改交收保证金计算价格去交收申请价格
  v_SettleMargin_SSum  := FN_T_ComputeSettleMargin_ZSS(p_FirmID,   p_CommodityID, 2,   p_Quantity,  v_price);
  --交易保证金必须使用计算交易保证金的交易保证金——只有计算所得才是对应阶段的交易保证金 yuansr 2016 10 25
  v_TradeMargin_S  := FN_T_ComputeMargin_ZSSPlus(p_FirmID,  p_CommodityID, 2,v_Overdat,p_Quantity, v_price);
  v_TradeMargin_SSum := v_TradeMargin_S;
    
  --3 、根据交收申报价格类型 判断如何冻结资金。0：按结算价交收 ；1：按订立价交收  mod by zhangjian
  v_price := p_delayMoney;--v_price:=p_Price;   modify by lyf 20160810 修改申报时候冻结保证金用申报金额来计算
  select DelaySettlePriceType  ,contractfactor  ,breedid 
    into v_DelaySettlePriceType  ,v_contractfactor  ,v_breedid ---合约因子 用于计算仓单手数 yuansr 2017 06 30
    from t_commodity where commodityid=p_CommodityID;
  if(v_DelaySettlePriceType=1) and v_holdEvenPrice>0 then -- 如果是按订立价交收
    v_price:=v_holdEvenPrice;
  end if;

  v_F_Funds := v_SettleMargin_SSum - v_TradeMargin_SSum;
  --计算可用资金，并锁住财务资金
  v_A_Funds := FN_F_GetRealFunds(p_FirmID, 1);

  --插入延期委托合计表日志   --add by zhangjian  2012年3月2日
  select SEQ_T_D_OrderSumLog.nextval into v_orderSumLogNo from dual;
  insert into T_D_DelayOrderSumLog
  values ( v_orderSumLogNo, p_firmid, 2, p_CommodityID, v_price, p_Quantity, v_SettleMargin_SSum, v_TradeMargin_SSum, 0, v_A_Funds
           ,v_F_Funds, Sysdate, p_a_holdno||'-指定交收-'||p_aholdFlag );

  if (v_A_Funds < v_F_Funds) then
    rollback;
    return - 2; --资金余额不足
  end if;
  --4 、更新交易客户持仓合计的冻结数量
  update T_CustomerHoldSum
     set frozenQty = frozenQty + p_Quantity
   where CustomerID = p_CustomerID   and CommodityID = p_CommodityID
     and bs_flag = 2;
  --5 、根据参数是否需要检查并冻结仓单
  if (p_DelayNeedBill = 1) then
    v_ret := FN_T_D_CheckAndFrozenBill(p_FirmID, p_CommodityID, p_Quantity);
    if (v_ret = -1) then
      rollback;
      return - 32; --仓单数量不足
    end if;
  end if;

  --start add by lyf 20160802 判断该交收申请人是否有可用仓单
  --select breedid into v_breedid from t_commodity where commodityid=p_CommodityID;
  --查找意向仓单中抵顶仓单的数量
  select nvl(sum(s.quantity),0) into v_purposeGageQty from bi_stock s
   where IsInSplitArray(s.stockid,p_preStockids, ',') = 1
     and s.stockid = (select so.stockid from bi_stockoperation so where so.isgage = 1 and so.stockid = s.stockid);

  if v_frozengageqty*v_contractfactor < nvl(v_purposeGageQty,0) then
    rollback;
    return -33;  --意向仓单不可用（意向仓单中的抵顶仓单数，大于交收申报中的抵顶持仓）
  end if;

  begin
    --查看可用仓单数量
    select nvl(a.quantity, 0) - nvl(b.frozen, 0) into v_billQty
      from (select sum(quantity) quantity, breedid, ownerfirm from bi_stock s
             where not exists (select stockid from BI_StockOperation so  where so.stockID = s.stockid) 
               and s.stockstatus = 1 
               --and IsInSplitArray(s.stockid,p_preStockids,',')=1 --意向仓单 yuansr 2017 08 07
               group by breedid, ownerfirm
           ) a,
           (select nvl(sum(frozen), 0) frozen, firmid, breedid from br_billQtyFrozen 
             where firmid = p_FirmID  group by breedid, firmid 
           ) b
     where b.breedid(+) = a.breedid and b.firmid(+) = a.ownerfirm 
       and a.ownerfirm = p_FirmID and a.breedid = v_breedid;

    if p_Quantity*v_contractfactor>nvl(v_billQty,0)+ nvl(v_purposeGageQty,0) then
       rollback;
       return -32;  --仓单数量不足（可用仓单数量与意向仓单中的抵顶仓单数 和 不够交收）
    end if;
  exception
    when NO_DATA_FOUND then
      --没有可用仓单时，看是否全部使用的抵顶仓单
      if p_Quantity*v_contractfactor < nvl(v_purposeGageQty,0) then
        rollback;
        return -32;  --仓单数量不足（意向仓单中的抵顶仓单数，不足交收数量）
      end if;
  end;

  --单独验证意向仓单数量 2017-8-30 hanqr
  begin
    select nvl(sum(quantity),0) quantity into v_purposebillQty from bi_stock s 
        where not exists (select stockid from BI_StockOperation so  where so.stockID = s.stockid and so.isgage <> 1) and s.stockstatus = 1 
        and IsInSplitArray(s.stockid,p_preStockids,',')=1; 

    if v_purposebillQty <= 0 then
        rollback;
        return -33;  --意向仓单不可用
    elsif v_purposebillQty-(p_Quantity*v_contractfactor)<0 then
        rollback;
        return -33;  --意向仓单不可用
    end if;
  exception
  when NO_DATA_FOUND then
       rollback;
       return -33;  --意向仓单不可用
        
  end;
  
  --6 、更新冻结资金
  v_F_FrozenFunds := FN_F_UpdateFrozenFunds(p_FirmID, v_F_Funds, '15');
  -->>======================================================================
  --7 、插入延期委托表，并返回委托单号
  select SEQ_T_DelayOrders.nextval into v_A_OrderNo from dual;

  insert into T_DelayOrders ( a_orderno,CommodityID, CustomerID, traderid, bs_flag, DelayOrderType, status, quantity, price, tradeqty, frozenfunds
                              ,unfrozenfunds,ordertime, withdrawtime, ordererip, signature, FirmID, ConsignerID, delayMoney, a_holdno, aHoldFlag,Txfirmid )
  values ( v_A_OrderNo,     p_CommodityID,     p_CustomerID,     p_TraderID,     2,     1,     1,     p_Quantity,     v_price,     0,     v_F_Funds
           ,    0,     sysdate,     null,     null,     null,     p_FirmID,     p_ConsignerID,     p_delayMoney,   p_a_holdno,     p_aholdFlag, p_txFirmId  );
  --7 、更新 交收申报委托持仓关系表 ：使用委托单号替换 临时委托代号
  update T_S_OrderFrozenHold t set t.a_orderno=v_A_OrderNo  where t.a_orderno=v_A_OrderNo_L;
  -- add by lyf 20160804 增加冻结仓单
  select breedid into v_breedid from t_commodity where commodityid=p_CommodityID;
  -- 意向仓单会添加业务表bi_stockoperation，计算可用数量时会排除掉，不需要再次冻结
  --insert into br_billQtyFrozen values(v_A_OrderNo,p_TraderID,p_Quantity*v_contractfactor-v_purposeGageQty,p_CommodityID,v_breedid,sysdate,'');
  --行情实时显示则要更新行情
  if (p_DelayQuoShowType = 1) then
    update T_DelayQuotation
       set SellSettleQty = SellSettleQty + p_Quantity, CreateTime = sysdate
     where CommodityID = p_CommodityID;
  end if;

  ---8 验证是否有指定意向仓单，有则冻结、记录指定意向仓单 yuansr 2017 07 07
  v_sql:='select t.stockid  from bi_stock t where t.ownerfirm='''||p_FirmID||''''
       ||'   and t.stockstatus=1 and t.stockid in('''|| replace(p_preStockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND; 
       --冻结意向仓单
       --v_result:=fn_bi_frozenSwapBill(p_FirmID ,'15'  ,v_stockId);
       v_result:=FN_BI_FrozenPurposeBill(p_FirmID ,'15'  ,v_stockId);
       --记录意向仓单
       insert into T_D_PurposeBill (a_orderno, stockid, status, kind ) values ( v_A_OrderNo ,v_stockId,1,1);
       if v_result<>1 then
          rollback;
          return -33;
       end if;
       v_stockids:=v_stockids||','||v_stockId;
  end loop;
  close v_item;

  if (p_preStockids is not null and length(p_preStockids )>0 )  then
    if( length(','||p_preStockids) = length(v_stockids) ) then
        v_stockids:=p_preStockids;
     else
       rollback;
        return -33; 
     end if;
  else
    v_stockids:=p_preStockids;
  end if;
  ---委托表记录意向仓单 yuansr 2017 07 07
  update T_DelayOrders t set t.stockids=v_stockids where t.a_orderno=v_A_OrderNo;
 
  commit;
  return v_A_OrderNo;
exception
  when NO_DATA_FOUND then
    rollback;
    return - 99; --不存在相关数据
  when others then
    v_errorcode := sqlcode;
    v_errormsg  := sqlerrm;
    rollback;
    insert into T_DBLog
      (err_date, name_proc, err_code, err_msg)
    values
      (sysdate, 'FN_T_D_SellSettleOrder_hold', v_errorcode, v_errormsg);
    commit;
    return - 100;
end;
/

