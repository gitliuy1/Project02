CREATE VIEW V_C_CUSTOMERFUNDS AS
  select q."FIRMID",q."FIRMNAME",q."NOWLEAVEBALANCE",q."RUNTIMEFL",q."RUNTIMEMARGIN",q."RUNTIMEASSURE",q."LASTBALANCE",q."CLEARFL",q."CLEARMARGIN",q."CLEARASSURE",q."TRADEFEE",q."SWAPFEE",q."MAXOVERDRAFT",q."CLOSE_PL",q."BALANCE",q."PL",q."RUNTIMESETTLEMARGIN",q."H_TODAYBALANCE",q."H_RUNTIMEMARGIN",q."H_RUNTIMESETTLEMARGIN",q."H_RUNTIMEFL",q."H_PL",q."H_CLOSE_PL",q."H_TRADEFEE",
       (BALANCE + CLEARMARGIN - CLEARASSURE + CLEARFL + PL +
       RUNTIMESETTLEMARGIN + CLOSE_PL - TRADEFEE) benefit,
       (H_TODAYBALANCE + H_RUNTIMEMARGIN + H_RUNTIMESETTLEMARGIN +
       H_RUNTIMEFL + H_PL + H_CLOSE_PL - H_TRADEFEE) lastBenefit
  from (select FIRMID,
               FIRMNAME,
               NOWLEAVEBALANCE,
               RUNTIMEFL,
               RUNTIMEMARGIN,
               RUNTIMEASSURE,
               LASTBALANCE,
               CLEARFL,
               CLEARMARGIN,
               CLEARASSURE,
               TRADEFEE,
               SWAPFEE,
               MAXOVERDRAFT,
               CLOSE_PL,
               BALANCE,
               PL,
               RUNTIMESETTLEMARGIN,
               H_TODAYBALANCE,
               H_RUNTIMEMARGIN,
               H_RUNTIMESETTLEMARGIN,
               H_RUNTIMEFL,
               H_PL,
               H_CLOSE_PL,
               H_TRADEFEE
          from (select a.*,
                       f.balance,
                       f.frozenfunds,
                       f.lastbalance,
                       m.name FirmName,
                       nvl(tt.TradeFee, 0) TradeFee,
                       nvl(tt.swapfee, 0) swapfee,
                       nvl(nvl(balance, 0) + nvl((-1) * FrozenFunds, 0), 0) nowLeaveBalance,
                       nvl(d.close_PL, 0) close_PL,
                       nvl(tfh.PL, 0) PL,
                       ha.todaybalance h_todaybalance,
                       hb.runtimemargin h_runtimemargin,
                       hb.runtimesettlemargin h_runtimesettlemargin,
                       hb.runtimefl h_runtimefl,
                       nvl(htfh.h_PL, 0) h_PL,
                       nvl(hd.h_close_PL, 0) h_close_PL,
                       nvl(htt.h_TradeFee, 0) h_TradeFee
                  from T_Firm a,
                       (select nvl(sum(t.TradeFee), 0) TradeFee,
                               t.firmID firmID,
                               nvl(sum(t.swapfee), 0) swapfee
                          from T_Trade t
                         group by firmID) tt,
                         (select nvl(sum(t.TradeFee), 0) h_TradeFee,
                               t.firmID firmID
                          from T_h_Trade t where t.cleardate = (select max(t.b_date) from F_FirmBalance t where t.b_date < trunc(sysdate))
                         group by firmID) htt,
                       F_FirmFunds f,
                       M_firm m,
                       (select firmID, nvl(sum(Close_PL), 0) close_PL
                          from T_Trade
                         group by firmID) d,
                         (select firmID, nvl(sum(Close_PL), 0) h_close_PL
                          from T_h_Trade t where t.cleardate = (select max(t.b_date) from F_FirmBalance t where t.b_date < trunc(sysdate))
                         group by firmID) hd,
                       (select firmID, nvl(sum(floatingloss), 0) PL
                          from t_Firmholdsum
                         group by firmID) tfh,
                         (select firmID, nvl(sum(floatingloss), 0) h_PL
                          from t_h_Firmholdsum t where t.cleardate = (select max(t.b_date) from F_FirmBalance t where t.b_date < trunc(sysdate))
                         group by firmID) htfh,
                         (select * from F_FirmBalance t where t.b_date=(select max(t.b_date) from F_FirmBalance t where t.b_date < trunc(sysdate))) ha,
                         (select * from t_h_firm t where t.cleardate=(select max(t.b_date) from F_FirmBalance t where t.b_date < trunc(sysdate))) hb
                 where a.FirmID = tt.FirmID(+)
                   and a.FirmID = htt.FirmID(+)
                   and a.FirmID = f.FirmID
                   and m.firmID = a.firmID
                   and a.firmid = d.firmID(+)
                   and a.firmid = hd.firmID(+)
                   and a.firmid = tfh.firmId(+)
                   and a.firmid = htfh.firmId(+)
                   and a.firmid = ha.firmid(+)
                   and a.firmid = hb.firmid(+)
                 order by nowLeaveBalance ASC)) q
/

