CREATE VIEW V_OP_MEMBER AS
  select m.brokerid memberno,m.name name,m.address addr,m.mobile phone,c.postcode postcode,
m.email email,c.createtime createtime,c.contactman contactman,p.operationcenterid operationCenterId,o.name operationcenter,o.parentid parentid,o.type type
from br_broker m
left join m_firm c on c.firmid=m.firmid
left join op_member p on m.brokerid=p.memberno
left join op_operationcenter o on p.operationcenterid=o.operationcenterid
where m.membertype=0
/

