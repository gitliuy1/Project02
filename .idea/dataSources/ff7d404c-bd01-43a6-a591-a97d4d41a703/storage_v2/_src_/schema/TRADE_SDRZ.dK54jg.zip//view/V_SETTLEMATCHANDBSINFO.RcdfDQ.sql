CREATE VIEW V_SETTLEMATCHANDBSINFO AS
  select t."MATCHID",
       t."COMMODITYID",
       t."CONTRACTFACTOR",
       t."QUANTITY",
       t."HL_AMOUNT",
       t."STATUS",
       t."RESULT",
       t."SETTLETYPE",
       t."FIRMID_B",
       t."BUYPRICE",
       t."BUYPAYOUT_REF",
       t."BUYPAYOUT",
       t."BUYMARGIN",
       t."TAKEPENALTY_B",
       t."PAYPENALTY_B",
       t."SETTLEPL_B",
       t."FIRMID_S",
       t."SELLPRICE",
       t."SELLINCOME_REF",
       t."SELLINCOME",
       t."SELLMARGIN",
       t."TAKEPENALTY_S",
       t."PAYPENALTY_S",
       t."SETTLEPL_S",
       t."CREATETIME",
       t."MODIFYTIME",
       t."SETTLEDATE",
       t."MODIFIER",
       t."ISTRANSFER",
       mfb.name           name_b,
       mfb.contactman     contactman_b,
       mfb.mobile         mobile_b,
       mfs.name           name_s,
       mfs.contactman     contactman_s,
       mfs.mobile         mobile_s
  from T_SETTLEMATCH t, m_firm mfb, m_firm mfs
 where t.firmid_b != t.firmid_s
   and t.firmid_b = mfb.firmid
   and t.firmid_s = mfs.firmid
/

