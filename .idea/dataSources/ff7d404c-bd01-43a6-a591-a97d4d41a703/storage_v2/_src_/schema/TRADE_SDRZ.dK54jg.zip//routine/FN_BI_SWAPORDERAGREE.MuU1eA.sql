CREATE function FN_BI_SwapOrderAgree(  p_orderno      number         ---委托号
                                                  ,p_auditor      varchar2       ---操作人，委托人，合同拟定人
                                                  ,p_remark       varchar2       ---备注
)
return number as
/****
 * 功能：确认交易商同意串换委托 yuansr 2017 06 16
 * 返回值:  1 =成功; -1=委托当前状态，不可确认 ;-2=委托对手交易商非法 ;-3=未指定串换仓单;-4=发起方仓单不可用;-5=发起方资金不足
 *          -100=其它错误
****/
  v_result           number(2);
  v_count            number(6);
  v_stockids         BI_SWAPSTOCKORDERS.STOCKIDS%type :=''; ---串换仓单
  v_errorcode        number;
  v_errormsg         varchar2(200);
  v_F_FrozenFunds    F_FIRMBALANCE.LASTBALANCE%type;
  v_A_Funds          number(15,2);   --可用资金

  v_status           BI_SWAPSTOCKORDERS.STATUS%type:=0;
  v_o_firmid         BI_SWAPSTOCKORDERS.FIRMID%type;
  v_o_stockids       BI_SWAPSTOCKORDERS.STOCKIDS%type;
  v_o_compensate     BI_SWAPSTOCKORDERS.COMPENSATE%type;

  v_sql              varchar2(500);
  type c_item is ref cursor;
  v_item             c_item;
  v_stockId          bi_stock.stockid%type;
  v_clearway         BI_SWAPSTOCKORDERS.CLEARWAY%type;
begin

  ---1 验证交易商是否合法
  select t.status ,t.o_firmid ,t.o_stockids ,t.o_compensate ,t.clearway 
    into v_status ,v_o_firmid ,v_o_stockids ,v_o_compensate ,v_clearway
    from bi_swapstockorders t
   where t.orderno=p_orderno for update ;

  ---2 验证对手交易商是否合法
  if v_status <> 1  then
    rollback;
    return -1;
  end if;

  ---3 确认处理
  --确认交易商仓单冻结处理
  v_sql:='select t.stockid  from bi_stock t where t.ownerfirm='''||v_o_firmid||''''
       ||'   and t.stockstatus=1 and t.stockid in('''|| replace(v_o_stockids,',',''',''') ||''')  for update ';
  open v_item for v_sql;
  loop
       fetch v_item into v_stockId ;
        exit when v_item%NOTFOUND; 
       v_result:=fn_bi_frozenSwapBill(v_o_firmid ,'15'  ,v_stockId);
       if v_result<>1 then
          rollback;
          return -4;
       end if;
       v_stockids:=v_stockids||','||v_stockId;
  end loop;
  close v_item;

  if (v_o_stockids is not null and length(v_o_stockids )>0 )  then
    if( length(','||v_o_stockids) = length(v_stockids) ) then
        v_stockids:=v_o_stockids;
     else
       rollback;
        return -4; 
     end if;
  else
    v_stockids:=v_o_stockids;
  end if;

  --确认交易商附加资金冻结处理
  if v_clearway =1 and v_o_compensate>0 then --当结算方式是资金结算且有附加资金
     --计算可用资金，并锁住财务资金
     v_A_Funds := FN_F_GetRealFunds(v_o_firmid,1);
     if(v_A_Funds < v_o_compensate) then
        rollback;
        return -5;  --资金余额不足
     end if;
     --更新冻结资金
     v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_o_firmid,v_o_compensate,'15');
  end if;

  --更新委托状态
  update bi_swapstockorders t set t.status = 3 ,t.remark=t.remark||p_remark
   where t.orderno=p_orderno;

  return 1;

  exception
    when others then
    v_errorcode:=sqlcode;
    v_errormsg :=sqlerrm;
    rollback;
    insert into T_DBLog(err_date,name_proc,err_code,err_msg)
    values(sysdate,'FN_BI_SwapOrderAgree',v_errorcode,v_errormsg);
    commit;
    return -100;
end;
/

