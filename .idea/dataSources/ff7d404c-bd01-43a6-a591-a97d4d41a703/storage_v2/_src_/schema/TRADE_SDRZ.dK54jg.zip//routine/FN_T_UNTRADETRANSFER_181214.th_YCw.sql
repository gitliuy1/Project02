CREATE function FN_T_UnTradeTransfer_181214(
      p_ID            number,         --非交易过户表ID
      p_CommodityID   varchar2,       --商品代码
      p_BS_Flag       number,         --买卖标志
      p_bCustomerID   varchar2,       --接收方交易客户ID
      p_sCustomerID   varchar2,       --过户方交易客户ID
      p_quantity      number          --过户数量

) return number
/****
 * 非交易过户
 * 返回值 : 1 =成功 ;  -1 =可平仓持仓数量不足 ; -5 =交易状态不为闭市 ; -15 =没有找到对应的持仓记录
 * 修改：单笔持仓 可用持仓数 扣除交收申报委托 冻结数,申报可用抵顶，交易不可用抵顶 2016 10 27 yuansr；
 *       交易保证金 按持仓到期天数 (所处阶段对应设置) 计算       yuansr 2016 10 30
****/
as
	   v_version               varchar2(10):='1.0.2.1';
     v_status                number(2);
     v_CommodityID           varchar2(16);
     v_CustomerID            varchar2(40);
     v_FirmID                varchar2(32);
     v_FirmID_b              varchar2(32);
     v_HoldQty               number;
     v_HoldSumQty            number(10);
     v_frozenQty             number(10);
     v_Margin                number(15,2):=0;
     v_Margin_one            number(15,2):=0;
	   v_Assure                number(15,2):=0;
	   v_Assure_one            number(15,2):=0;
     v_BS_Flag               number(2);
     v_Price                 number(15,2);
     v_ContractFactor        number(12,2);
     v_MarginPriceType       number(1);
     v_MarginPrice           number(15,2);  --计算成交保证金的价格
	   v_HoldFunds             number(15,2):=0;  --平仓时应退持仓金额，不包括抵顶的
	   v_CustomerHoldFunds     number(15,2):=0;  --平仓时应退持仓金额，包括抵顶的
     v_TradeDate             date;
	   v_A_HoldNo              number(15);
	   v_GageQty               number(10);
	   v_unCloseQty            number(10):=p_quantity; --未平数量，用于中间计算
	   --v_unCloseQtyGage        number(10):=p_GageQty; --未平数量，用于中间计算
	   v_tradedAmount          number(10):=0;  --成交数量
	   v_tradedAmountGage      number(10):=0;  --成交数量
	   v_F_FrozenFunds         number(15,2);
	   v_AtClearDate           date;
	   v_HoldTime              date;
	   --v_tmp_bs_flag           number(2);
  	 type c_HoldPosition is ref cursor;
  	 v_HoldPosition c_HoldPosition;
  	 v_sql                   varchar2(1200);
  	 v_closeTodayHis         number(2);    --平今仓还是历史仓(0平今仓；1平历史仓)
  	 v_YesterBalancePrice    number(15,2);
  	 v_num                   number(10);
     v_Overdat               number(10);         -- 到期天数
     v_cOverdat              number(10);        -- 新持仓到期天数
begin

     select status into v_status from t_systemstatus;
     if(v_status != 1) then --不等于闭市状态
         rollback;
         return -5;--只有闭市状态下才进行做非交易过户
     end if;

		 v_CustomerID := p_sCustomerID;  --过户方交易客户ID
	   v_CommodityID := p_CommodityID;
     v_BS_Flag := p_BS_Flag;
     /*if(v_BS_Flag=1) then  --持仓的买卖标志
         v_tmp_bs_flag:=2; --开仓的买卖标志
     else
         v_tmp_bs_flag:=1;
     end if;*/
     --锁住交易客户持仓合计，以防止并发更新
     begin
       select HoldQty,FrozenQty,GageQty
         into v_HoldSumQty, v_frozenQty, v_GageQty
         from T_CustomerHoldSum
        where CustomerID = v_CustomerID
          and CommodityID = v_CommodityID
          and bs_flag = v_BS_Flag for update;
     exception
         when NO_DATA_FOUND then
  	     return -15;--没有找到对应的持仓记录
     end;

     if(p_quantity > v_frozenQty) then--过户数量已冻结
         rollback;
         return -1;--可过户持仓数量不足
     end if;

     select Contractfactor,MarginPriceType,LastPrice,overdat 
       into v_ContractFactor,v_MarginPriceType,v_YesterBalancePrice,v_cOverdat
       from T_Commodity where CommodityID=v_CommodityID;

     select TradeDate into v_TradeDate from T_SystemStatus;
     ---应交收抵顶业务影响，抵顶冻结单独记录，当前冻结为非抵顶部分持仓 yuansr 2017 09 02
     v_sql := --'select a.a_holdno ,a.overdat,FirmID,price,case when nvl(c.FrozenQty,0)<=nvl(a.gageqty,0) then a.holdqty-nvl(b.FrozenQty,0) '
            --||                       '          else nvl(a.holdqty,0)+nvl(a.gageqty,0)-nvl(c.FrozenQty,0)-nvl(b.FrozenQty,0) end   '
            '  select a.a_holdno ,a.overdat ,FirmID ,price ,nvl(a.holdqty,0)-nvl(c.FrozenQty,0)-nvl(b.FrozenQty,0) '
            ||'       ,GageQty,HoldTime,AtClearDate,nvl(b.FrozenQty,0) '
            ||'  from T_holdposition a,(select A_HoldNo,nvl(sum(FrozenQty),0) FrozenQty from T_SpecFrozenHold group by A_HoldNo) b ' 
            ||   '    ,(select A_HoldNo,bs_flag cbs_flag ,nvl( sum(FrozenQty-unfrozenqty ),0) FrozenQty from t_s_orderfrozenhold group by A_HoldNo,bs_flag) c '
            ||' where (a.HoldQty+a.GageQty) > 0 and a.A_HoldNo=c.A_HoldNo(+) and a.bs_flag=c.cbs_flag(+) and a.A_HoldNo=b.A_HoldNo(+) '
            ||'   and CustomerID=''' || v_CustomerID || ''' and CommodityID =''' || v_CommodityID || ''' and bs_flag = ' || v_BS_Flag || ' order by a.A_HoldNo ';

	   --遍历持仓明细的数量并过滤掉指定平仓冻结的数量
     open v_HoldPosition for v_sql;
         loop
             fetch v_HoldPosition into v_a_holdno,v_Overdat ,v_FirmID, v_price, v_holdqty ,v_GageQty,v_HoldTime,v_AtClearDate,v_frozenQty;
                exit when v_HoldPosition%NOTFOUND;
                --如果此笔持仓全部被指定平仓冻结且没有抵顶则指向下一条记录
                if(v_holdqty <> 0) then
	                  v_tradedAmount:=0;
	                  v_tradedAmountGage:=0;
	                  v_Margin_one:=0;
	                  v_Assure_one:=0;

                    --判断是平今仓还是平历史仓
        				    if(trunc(v_TradeDate) = trunc(v_AtClearDate)) then
        				        v_closeTodayHis := 0;
        				    else
        				    	  v_closeTodayHis := 1;
        				    end if;

        	          --1、计算应退款项
        	          if(v_holdqty > 0) then
        		            if(v_holdqty<=v_unCloseQty) then
        		                v_tradedAmount:=v_holdqty;
        		            else
        		                v_tradedAmount:=v_unCloseQty;
        		            end if;

                        --计算应退保证金价格，根据设置选择开仓价还是昨结算价来算
        						    if(v_MarginPriceType = 1) then
        					          v_MarginPrice := v_YesterBalancePrice;
        					      elsif(v_MarginPriceType = 2) then
        							      --判断是平今仓还是平历史仓
        							      if(v_closeTodayHis = 0) then  --平今仓
        								        v_MarginPrice := v_price;
        							      else  --平历史仓
        						            v_MarginPrice := v_YesterBalancePrice;
        						        end if;
        						    else  -- default type is 0
        							      v_MarginPrice := v_price;
        						    end if;

                        --计算应退保证金
        		            v_Margin_one := FN_T_ComputeMarginPlus(v_FirmID,v_CommodityID,v_BS_Flag,v_Overdat,v_tradedAmount,v_MarginPrice);
        		            if(v_Margin_one < 0) then
        		                Raise_application_error(-20040, 'computeMargin error');
        		            end if;
        				        --计算担保金
        				        v_Assure_one := FN_T_ComputeAssurePlus(v_FirmID,v_CommodityID,v_BS_Flag ,v_Overdat,v_tradedAmount,v_MarginPrice);
        				        if(v_Assure_one < 0) then
        				            Raise_application_error(-20041, 'computeAssure error');
        				        end if;
        				        --保证金应加上担保金
        				        v_Margin_one := v_Margin_one + v_Assure_one;
        		            v_Margin:=v_Margin + v_Margin_one;
        		            v_Assure:=v_Assure + v_Assure_one;
        			          --计算应退持仓金额，不包括抵顶的
        			          v_HoldFunds := v_HoldFunds + v_tradedAmount*v_price*v_ContractFactor;
                    end if;

  	                --二级客户合计金额
  	                v_CustomerHoldFunds := v_CustomerHoldFunds + v_tradedAmount*v_price*v_ContractFactor;

	                  --更新持仓记录(过户方)
                    update T_holdposition
                       set holdqty = holdqty - v_tradedAmount,
                           HoldMargin=HoldMargin-v_Margin_one,
                           HoldAssure=HoldAssure-v_Assure_one
                     where a_holdno = v_a_holdno;

                     --获取过户方交易商
                     select FirmID into v_FirmID_b from T_Customer where CustomerID = p_bCustomerID;
                     --更新持仓记录（接收方）
                     --select FN_T_ComputeHoldNo(SEQ_T_HoldPosition.nextval) into v_A_HoldNo_s from dual;
                     ---经客户（邮件）确认持仓时间与过户前持仓时间一致,到期天数也一样 yuansr 2016 11 11 
                     insert into T_Holdposition
                         (a_holdno,                   a_tradeno, CommodityID,   CustomerID,    bs_flag,       price,         holdqty,        openqty
                         	,overdat   ,holdtime, HoldMargin,   HoldAssure,   Firmid,     FloatingLoss, AtClearDate )
                     values
                         (SEQ_T_HoldPosition.nextval, -1,        p_CommodityID, p_bCustomerID, v_BS_Flag, v_MarginPrice, v_tradedAmount, v_tradedAmount
                         ,v_Overdat    ,v_HoldTime /*sysdate*/   ,  v_Margin_one, v_Assure_one, v_FirmID_b, 0,            v_TradeDate);

                     --更新交易客户持仓合计表（接收方）
                     select count(*) into v_num from T_CustomerHoldSum
                      where CustomerID = p_bCustomerID
                        and CommodityID = p_CommodityID
                        and bs_flag = v_BS_Flag;
                     if(v_num >0) then
                         update T_CustomerHoldSum
                            set holdQty = holdQty + v_tradedAmount,
                                holdFunds = holdFunds + v_Margin_one,
                                HoldMargin = HoldMargin + v_Margin_one,
                                HoldAssure = HoldAssure + v_Assure_one,
                                evenprice = (holdFunds + v_Margin_one)/((holdQty + GageQty + v_tradedAmount)*v_ContractFactor)
                          where CustomerID = p_bCustomerID
                            and CommodityID = p_CommodityID
                            and bs_flag = v_BS_Flag;
                     else
                         insert into T_CustomerHoldSum
                             (CustomerID,    CommodityID,   bs_flag,       holdQty,        holdFunds,    FloatingLoss, evenprice,     FrozenQty, HoldMargin,   HoldAssure,   FirmID)
                         values
                             (p_bCustomerID, p_CommodityID, v_BS_Flag, v_tradedAmount, v_Margin_one, 0,            v_MarginPrice, 0,         v_Margin_one, v_Assure_one, v_FirmID_b);
                     end if;

                    --更新买方交易商持仓合计表（接收方）
                    select count(*) into v_num from T_FirmHoldSum
                    where Firmid = v_FirmID_b
                      and CommodityID = p_CommodityID
                      and bs_flag = v_BS_Flag;
                    if(v_num >0) then
                        update T_FirmHoldSum
                           set holdQty = holdQty + v_tradedAmount,
                               holdFunds = holdFunds + v_Margin_one,
                               HoldMargin = HoldMargin + v_Margin_one,
                               HoldAssure = HoldAssure + v_Assure_one,
                               evenprice = (holdFunds + v_Margin_one)/((holdQty + v_tradedAmount + GageQty)*v_ContractFactor)
                         where Firmid = v_FirmID_b
                           and CommodityID = p_CommodityID
                           and bs_flag = v_BS_Flag;
                    else
                      insert into T_FirmHoldSum
                        (FirmID,     CommodityID,   bs_flag,       holdQty,        holdFunds,    FloatingLoss, evenprice,     HoldMargin,   HoldAssure)
                      values
                        (v_FirmID_b, p_CommodityID, v_BS_Flag, v_tradedAmount, v_Margin_one, 0,            v_MarginPrice, v_Margin_one, v_Assure_one);
                    end if;

                    --更新临时保证金和临时担保金（接收方）
                    update T_Firm
                       set runtimemargin = runtimemargin + v_Margin_one,
            		           RuntimeAssure = RuntimeAssure + v_Assure_one
                     where Firmid = v_FirmID_b;

                    --更新冻结资金，释放个人部分的保证金（接收方）
		                v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_FirmID_b,v_Margin_one-v_Assure_one,'15');

	                   --每次减少过户数量
                     v_unCloseQty:=v_unCloseQty - v_tradedAmount;

                end if;
                exit when v_unCloseQty=0;
            end loop;
        close v_HoldPosition;

        if(v_unCloseQty>0) then --平仓持仓数量大于可平仓持仓数量
            rollback;
            return -1;
        end if;

        --减少交易客户，交易商的持仓合计信息(过户方)
        v_num := FN_T_SubHoldSum(p_quantity,0,v_Margin,v_Assure,v_CommodityID,v_ContractFactor,v_BS_Flag,v_FirmID,v_HoldFunds,v_CustomerID,v_CustomerHoldFunds,0,p_quantity);

        --更新临时保证金和临时担保金（过户方）
        update T_Firm
           set runtimemargin = runtimemargin - v_Margin,
		           RuntimeAssure = RuntimeAssure - v_Assure
         where Firmid = v_FirmID;

        --更新冻结资金，释放个人部分的保证金（过户方）
		    v_F_FrozenFunds := FN_F_UpdateFrozenFunds(v_FirmID,-(v_Margin-v_Assure),'15');

        --更新持仓冻结表
        delete T_Holdfrozen where Operation = to_char(p_ID) and frozentype = 2;

        --更新非交易过户表审核状态
        update T_UnTradeTransfer set Status=1,modifytime=sysdate where Transferid = p_ID;

    return 1;

end;
/

